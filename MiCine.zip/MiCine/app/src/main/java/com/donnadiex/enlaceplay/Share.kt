package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Subscription(val url: String, val name: String, val lastSync: Long, val count: Int)

/**
 * Lista compartida:
 *  - Tú publicas tus links (con portadas y datos ya buscados) en un Gist SECRETO de GitHub.
 *  - Tu conocido pega ese link en su app; cada vez que la abre, se agrega lo nuevo y se quita lo que borraste.
 * Solo se comparten links de internet (los archivos de tu celular no le servirían a nadie más).
 */
object Share {

    private const val FILE = "micine-lista.json"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    // ============== Exportar ==============
    fun exportList(ctx: Context): JSONObject {
        val arr = JSONArray()
        Catalog.titles().forEach { t ->
            val files = Catalog.filesOf(t.id).filter { !Local.isLocal(it.url) && it.source.isEmpty() && it.deadSince == 0L }
            if (files.isEmpty()) return@forEach
            val fa = JSONArray()
            files.forEach { f ->
                fa.put(JSONObject().put("url", f.url).put("s", f.season).put("e", f.episode).put("file", f.fileName)
                    .put("q", f.quality).put("name", f.epName).put("ov", f.epOverview).put("still", f.still ?: "")
                    .put("dur", f.durationMs))
            }
            arr.put(JSONObject()
                .put("kind", t.kind.name).put("name", t.name).put("year", t.year).put("ext", t.ext).put("anime", t.anime)
                .put("poster", t.poster ?: "").put("backdrop", t.backdrop ?: "").put("overview", t.overview)
                .put("genres", JSONArray(t.genres)).put("rating", t.rating).put("status", t.status)
                .put("origin", t.origin).put("network", t.network).put("tint", t.tint)
                .put("seasonsN", t.totalSeasons).put("episodesN", t.totalEpisodes)
                .put("seasons", JSONArray().also { a ->
                    t.seasons.forEach { (n, s) -> a.put(JSONObject().put("n", n).put("p", s.poster ?: "").put("o", s.overview).put("y", s.year).put("name", s.name)) }
                })
                .put("cast", JSONArray().also { a -> t.cast.forEach { c -> a.put(JSONObject().put("n", c.name).put("r", c.role).put("p", c.photo ?: "")) } })
                .put("files", fa))
        }
        return JSONObject().put("micine", 1).put("name", listName(ctx)).put("updated", System.currentTimeMillis()).put("titles", arr)
    }

    fun listName(ctx: Context) = prefs(ctx).getString("lista_nombre", "Mi Cine")!!
    fun setListName(ctx: Context, n: String) = prefs(ctx).edit().putString("lista_nombre", n).apply()

    // ============== Publicar en GitHub Gist ==============
    fun token(ctx: Context) = prefs(ctx).getString("gh_token", "")!!.trim()
    fun setToken(ctx: Context, t: String) = prefs(ctx).edit().putString("gh_token", t.trim()).apply()
    fun gistId(ctx: Context) = prefs(ctx).getString("gist_id", "")!!
    fun publicUrl(ctx: Context): String? = prefs(ctx).getString("gist_raw", null)
    fun autoPublish(ctx: Context) = prefs(ctx).getBoolean("auto_publicar", true)
    fun setAutoPublish(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("auto_publicar", on).apply()

    private fun github(method: String, path: String, token: String, body: JSONObject?): JSONObject {
        val c = URL("https://api.github.com$path").openConnection() as HttpURLConnection
        // Android acepta PATCH; si algún celular no, se manda como POST con el encabezado de reemplazo.
        runCatching { c.requestMethod = method }.onFailure {
            c.requestMethod = "POST"
            c.setRequestProperty("X-HTTP-Method-Override", method)
        }
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("User-Agent", USER_AGENT)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        try {
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 401) error("El token de GitHub no es válido o expiró")
            if (code == 404) error("GitHub no encontró la lista (¿el token tiene permiso de Gist?)")
            if (code !in 200..299) error("GitHub respondió $code")
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    /** Sube la lista. La primera vez crea un Gist secreto; después solo lo actualiza. */
    fun publish(ctx: Context): String {
        val tk = token(ctx).ifBlank { error("Primero pega tu token de GitHub") }
        val content = exportList(ctx).toString()
        val files = JSONObject().put(FILE, JSONObject().put("content", content))
        val id = gistId(ctx)
        val res = if (id.isBlank()) {
            github("POST", "/gists", tk, JSONObject().put("description", "Lista de Mi Cine").put("public", false).put("files", files))
        } else {
            runCatching { github("PATCH", "/gists/$id", tk, JSONObject().put("files", files)) }.getOrElse {
                // Si borraron el Gist, se crea uno nuevo
                github("POST", "/gists", tk, JSONObject().put("description", "Lista de Mi Cine").put("public", false).put("files", files))
            }
        }
        val newId = res.getString("id")
        val login = res.optJSONObject("owner")?.optString("login") ?: ""
        val raw = "https://gist.githubusercontent.com/$login/$newId/raw/$FILE"
        prefs(ctx).edit().putString("gist_id", newId).putString("gist_raw", raw)
            .putInt("publicado_hash_datos", dataHash(ctx)).putLong("publicado_en", System.currentTimeMillis()).apply()
        return raw
    }

    private fun dataHash(ctx: Context): Int = exportList(ctx).also { it.remove("updated") }.toString().hashCode()

    fun lastPublished(ctx: Context) = prefs(ctx).getLong("publicado_en", 0)

    /** Publica solo si cambió algo desde la última vez (se llama al abrir la app y al agregar links). */
    fun publishIfChanged(ctx: Context): Boolean {
        if (!autoPublish(ctx) || token(ctx).isBlank() || gistId(ctx).isBlank()) return false
        if (dataHash(ctx) == prefs(ctx).getInt("publicado_hash_datos", 0)) return false
        publish(ctx)
        return true
    }

    // ============== Suscribirse ==============
    fun subscriptions(ctx: Context): List<Subscription> = runCatching {
        val a = JSONArray(prefs(ctx).getString("suscripciones", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map {
            Subscription(it.getString("url"), it.optString("name"), it.optLong("sync"), it.optInt("n"))
        }
    }.getOrDefault(emptyList())

    private fun saveSubs(ctx: Context, list: List<Subscription>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("url", it.url).put("name", it.name).put("sync", it.lastSync).put("n", it.count)) }
        prefs(ctx).edit().putString("suscripciones", a.toString()).apply()
    }

    /** Acepta el link del Gist en cualquier forma y lo convierte en el link directo al archivo. */
    fun normalize(input: String): String {
        val u = input.trim()
        Regex("https?://gist\\.github\\.com/([^/\\s]+)/([0-9a-f]+)").find(u)?.let {
            return "https://gist.githubusercontent.com/${it.groupValues[1]}/${it.groupValues[2]}/raw/$FILE"
        }
        Regex("https?://gist\\.githubusercontent\\.com/([^/\\s]+)/([0-9a-f]+)").find(u)?.let {
            return "https://gist.githubusercontent.com/${it.groupValues[1]}/${it.groupValues[2]}/raw/$FILE"
        }
        return u
    }

    fun removeSubscription(ctx: Context, url: String, deleteContent: Boolean) {
        saveSubs(ctx, subscriptions(ctx).filter { it.url != url })
        if (deleteContent) {
            Catalog.allFiles().filter { it.source == url }.forEach { Catalog.deleteFile(it.id) }
            Catalog.save()
        }
    }

    private fun download(url: String): JSONObject {
        val sep = if (url.contains('?')) '&' else '?'
        val c = URL("$url${sep}t=${System.currentTimeMillis() / 60000}").openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.useCaches = false
        try {
            if (c.responseCode !in 200..299) error("La lista respondió ${c.responseCode}")
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            if (!o.has("titles")) error("Ese link no es una lista de Mi Cine")
            return o
        } finally {
            c.disconnect()
        }
    }

    /** Agrega lo nuevo y quita lo que ya no está en la lista. Devuelve (agregados, quitados). */
    fun sync(ctx: Context, rawUrl: String): Pair<Int, Int> {
        val url = normalize(rawUrl)
        val o = download(url)
        val r = apply(o, url)
        val subs = subscriptions(ctx).toMutableList()
        val name = o.optString("name").ifBlank { "Lista compartida" }
        val count = Catalog.allFiles().count { it.source == url }
        val i = subs.indexOfFirst { it.url == url }
        val s = Subscription(url, name, System.currentTimeMillis(), count)
        if (i >= 0) subs[i] = s else subs.add(s)
        saveSubs(ctx, subs)
        return r
    }

    /** Importa una lista desde un archivo (una sola vez; queda como tuya). */
    fun importFile(text: String): Int = apply(JSONObject(text), "").first

    private fun apply(o: JSONObject, source: String): Pair<Int, Int> {
        val arr = o.optJSONArray("titles") ?: JSONArray()
        val seen = mutableSetOf<String>()
        var added = 0
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val kind = runCatching { Kind.valueOf(j.optString("kind")) }.getOrDefault(Kind.SERIES)
            val name = j.optString("name")
            val ext = j.optString("ext")
            val t = Catalog.titles().firstOrNull { ext.isNotBlank() && it.ext == ext && it.kind == kind }
                ?: Catalog.findTitle(kind, NameParser.key(name))
                ?: Title(kind = kind, name = name).also { nt ->
                    nt.year = j.optInt("year"); nt.ext = ext; nt.anime = j.optBoolean("anime")
                    nt.poster = j.optString("poster").ifBlank { null }; nt.backdrop = j.optString("backdrop").ifBlank { null }
                    nt.overview = j.optString("overview"); nt.rating = j.optDouble("rating", 0.0); nt.status = j.optString("status")
                    nt.origin = j.optString("origin"); nt.network = j.optString("network"); nt.tint = j.optInt("tint")
                    nt.totalSeasons = j.optInt("seasonsN"); nt.totalEpisodes = j.optInt("episodesN")
                    nt.genres = j.optJSONArray("genres")?.let { g -> (0 until g.length()).map { g.getString(it) } } ?: emptyList()
                    nt.seasons = (j.optJSONArray("seasons") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { a.getJSONObject(it) }.associate { s ->
                            s.optInt("n") to SeasonInfo(s.optString("p").ifBlank { null }, s.optString("o"), s.optInt("y"), s.optString("name"))
                        }
                    }
                    nt.cast = (j.optJSONArray("cast") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { a.getJSONObject(it) }.map { c -> CastMember(c.optString("n"), c.optString("r"), c.optString("p").ifBlank { null }) }
                    }
                    Catalog.addTitle(nt)
                }
            val fa = j.optJSONArray("files") ?: JSONArray()
            for (k in 0 until fa.length()) {
                val f = fa.getJSONObject(k)
                val u = f.optString("url")
                if (u.isBlank()) continue
                seen += u
                if (Catalog.fileByUrl(u) != null) continue
                Catalog.addFile(MediaFile(
                    titleId = t.id, season = f.optInt("s"), episode = f.optInt("e"), url = u,
                    fileName = f.optString("file"), quality = f.optString("q"), epName = f.optString("name"),
                    epOverview = f.optString("ov"), still = f.optString("still").ifBlank { null },
                    durationMs = f.optLong("dur"), source = source
                ))
                added++
            }
        }
        var removed = 0
        if (source.isNotBlank()) {
            Catalog.allFiles().filter { it.source == source && it.url !in seen }.forEach { Catalog.deleteFile(it.id); removed++ }
        }
        Catalog.save()
        return added to removed
    }

    /** Sincroniza todas las listas (al abrir la app, máximo cada 3 horas). */
    fun syncAll(ctx: Context, force: Boolean = false): Pair<Int, Int> {
        var a = 0
        var r = 0
        val now = System.currentTimeMillis()
        subscriptions(ctx).filter { force || now - it.lastSync > 3 * 60 * 60 * 1000L }.forEach { s ->
            runCatching { sync(ctx, s.url) }.onSuccess { a += it.first; r += it.second }
                .onFailure { CrashLog.note("Sincronizar lista ${s.url}", it) }
        }
        return a to r
    }
}
