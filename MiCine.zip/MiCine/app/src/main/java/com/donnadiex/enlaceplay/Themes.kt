package com.donnadiex.enlaceplay

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface

/** Cómo se acomoda la pantalla de inicio. */
enum class HomeStyle { ROWS, FANART, WALL, LIST, MAGAZINE }

/** Cómo se navega entre secciones. */
enum class NavStyle { TOP_TABS, SIDE_RAIL, BOTTOM_BAR, PILLS }

/** Cómo se ve la ficha de una serie o película. */
enum class DetailStyle { POSTER, BANNER }

/** Cómo se ven las listas completas (Series, Películas, Mi lista, búsqueda). */
enum class GridStyle { POSTERS, LANDSCAPE, WALL, ROWS, INDEX }

class UiTheme(
    val id: String,
    val name: String,
    val description: String,
    val inspiredBy: String,
    val bg: Int,
    val card: Int,
    val card2: Int,
    val line: Int,
    val accent: Int,
    val onAccent: Int,
    val text: Int,
    val muted: Int,
    val dim: Int,
    val light: Boolean,
    val font: Typeface,
    val titleFont: Typeface,
    val radius: Float,          // dp de las esquinas
    val home: HomeStyle,
    val nav: NavStyle,
    val detail: DetailStyle,
    val grid: GridStyle,
    val logo: String,
    val upperTitles: Boolean = false,
    val letterSpacing: Float = 0f
)

object Themes {

    private fun c(s: String) = Color.parseColor(s)
    private fun tf(family: String, style: Int = Typeface.NORMAL) = Typeface.create(family, style)

    val all: List<UiTheme> = listOf(
        UiTheme(
            id = "cine", name = "Cine", inspiredBy = "Estilo Netflix",
            description = "Portada gigante, filas que se deslizan de lado y pestañas arriba.",
            bg = c("#000000"), card = c("#141414"), card2 = c("#1F1F1F"), line = c("#2A2A2A"),
            accent = c("#E50914"), onAccent = c("#FFFFFF"),
            text = c("#FFFFFF"), muted = c("#A3A3A3"), dim = c("#6B6B6B"), light = false,
            font = tf("sans-serif"), titleFont = tf("sans-serif", Typeface.BOLD), radius = 8f,
            home = HomeStyle.ROWS, nav = NavStyle.TOP_TABS, detail = DetailStyle.POSTER, grid = GridStyle.POSTERS,
            logo = "MI CINE"
        ),
        UiTheme(
            id = "estuario", name = "Estuario", inspiredBy = "Estilo Kodi",
            description = "Menú lateral con iconos, imágenes panorámicas (fanart) y ficha con banner.",
            bg = c("#0E1620"), card = c("#16222E"), card2 = c("#1F2E3C"), line = c("#26384A"),
            accent = c("#12A0C7"), onAccent = c("#FFFFFF"),
            text = c("#EAF2F8"), muted = c("#93A7B8"), dim = c("#5E7385"), light = false,
            font = tf("sans-serif-light"), titleFont = tf("sans-serif-medium"), radius = 4f,
            home = HomeStyle.FANART, nav = NavStyle.SIDE_RAIL, detail = DetailStyle.BANNER, grid = GridStyle.LANDSCAPE,
            logo = "Mi Cine"
        ),
        UiTheme(
            id = "muro", name = "Muro", inspiredBy = "Pared de pósters",
            description = "Pósters de borde a borde sin espacios, letra condensada y barra de navegación abajo.",
            bg = c("#0B0A10"), card = c("#16141F"), card2 = c("#211E2E"), line = c("#2C2840"),
            accent = c("#A98BFF"), onAccent = c("#120F1C"),
            text = c("#F3F0FF"), muted = c("#A49FBC"), dim = c("#6A6585"), light = false,
            font = tf("sans-serif-condensed"), titleFont = tf("sans-serif-condensed", Typeface.BOLD), radius = 0f,
            home = HomeStyle.WALL, nav = NavStyle.BOTTOM_BAR, detail = DetailStyle.POSTER, grid = GridStyle.WALL,
            logo = "MI CINE", upperTitles = true, letterSpacing = 0.06f
        ),
        UiTheme(
            id = "lista", name = "Ficha técnica", inspiredBy = "Vista de información",
            description = "Lista detallada: póster pequeño, año, géneros, calificación y sinopsis en cada fila.",
            bg = c("#1A1917"), card = c("#24221F"), card2 = c("#2F2C28"), line = c("#3A3631"),
            accent = c("#F2A33A"), onAccent = c("#1A1206"),
            text = c("#F5EFE6"), muted = c("#B8AE9F"), dim = c("#7D7568"), light = false,
            font = tf("sans-serif"), titleFont = tf("sans-serif-medium"), radius = 12f,
            home = HomeStyle.LIST, nav = NavStyle.PILLS, detail = DetailStyle.BANNER, grid = GridStyle.ROWS,
            logo = "mi cine"
        ),
        UiTheme(
            id = "papel", name = "Papel", inspiredBy = "Revista impresa",
            description = "Tema claro tipo revista: letra con serifas, portada editorial e índice numerado.",
            bg = c("#F3EEE4"), card = c("#FBF8F2"), card2 = c("#E8E1D3"), line = c("#D6CCBA"),
            accent = c("#B0362A"), onAccent = c("#FFFFFF"),
            text = c("#1E1A15"), muted = c("#5F574B"), dim = c("#8F8676"), light = true,
            font = tf("serif"), titleFont = tf("serif", Typeface.BOLD), radius = 2f,
            home = HomeStyle.MAGAZINE, nav = NavStyle.TOP_TABS, detail = DetailStyle.BANNER, grid = GridStyle.INDEX,
            logo = "Mi Cine"
        )
    )

    @Volatile
    var cur: UiTheme = all.first()
        private set

    fun load(ctx: Context) {
        val id = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("tema", "cine")
        cur = all.firstOrNull { it.id == id } ?: all.first()
    }

    fun set(ctx: Context, id: String) {
        ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putString("tema", id).apply()
        load(ctx)
    }
}

/** Colores del tema activo (todas las pantallas los leen de aquí). */
object Col {
    val BG: Int get() = Themes.cur.bg
    val CARD: Int get() = Themes.cur.card
    val CARD2: Int get() = Themes.cur.card2
    val LINE: Int get() = Themes.cur.line
    val RED: Int get() = Themes.cur.accent          // "acento" del tema (se llama RED por historia)
    val ON_ACCENT: Int get() = Themes.cur.onAccent
    val TEXT: Int get() = Themes.cur.text
    val MUTED: Int get() = Themes.cur.muted
    val DIM: Int get() = Themes.cur.dim
    val SOFT: Int get() = blend(Themes.cur.text, Themes.cur.bg, 0.15f)
    val ACCENT_SOFT: Int get() = (Themes.cur.accent and 0x00FFFFFF) or 0x33000000

    fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }
}
