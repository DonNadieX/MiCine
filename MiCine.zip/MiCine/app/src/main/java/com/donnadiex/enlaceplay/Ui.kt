package com.donnadiex.enlaceplay

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.io.File

/** Colores estilo cine (negro + rojo). */
object Col {
    val BG = Color.parseColor("#000000")
    val CARD = Color.parseColor("#141414")
    val CARD2 = Color.parseColor("#1F1F1F")
    val LINE = Color.parseColor("#2A2A2A")
    val RED = Color.parseColor("#E50914")
    val TEXT = Color.parseColor("#FFFFFF")
    val MUTED = Color.parseColor("#A3A3A3")
    val DIM = Color.parseColor("#6B6B6B")
}

/** Base de todas las pantallas: catálogo listo y tareas que se cancelan al salir. */
abstract class BaseActivity : Activity() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Catalog.init(applicationContext)
        window.statusBarColor = Col.BG
        window.navigationBarColor = Col.BG
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
val Context.screenW: Int get() = resources.displayMetrics.widthPixels

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = radius
    if (stroke > 0) setStroke(stroke, strokeColor)
}

fun Context.txt(
    s: CharSequence,
    size: Float = 14f,
    color: Int = Col.TEXT,
    bold: Boolean = false,
    lines: Int = 0
): TextView = TextView(this).apply {
    text = s
    textSize = size
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
    if (lines > 0) {
        maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
    }
}

fun Context.vbox(pad: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    if (pad > 0) setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

fun View.margins(l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): View {
    val p = layoutParams as? ViewGroup.MarginLayoutParams ?: ViewGroup.MarginLayoutParams(MATCH, WRAP)
    val c = context
    p.setMargins(c.dp(l), c.dp(t), c.dp(r), c.dp(b))
    layoutParams = p
    return this
}

/** Botón tipo píldora: rojo relleno o con borde. */
fun Context.pill(label: String, filled: Boolean, icon: Int = 0, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    textSize = 15f
    typeface = Typeface.DEFAULT_BOLD
    gravity = Gravity.CENTER
    setTextColor(if (filled) Col.TEXT else Col.TEXT)
    background = if (filled) rounded(Col.RED, dpf(6f)) else rounded(Col.CARD2, dpf(6f))
    setPadding(dp(16), dp(11), dp(16), dp(11))
    if (icon != 0) {
        val d = resources.getDrawable(icon, theme)
        d.setBounds(0, 0, dp(20), dp(20))
        setCompoundDrawables(d, null, null, null)
        compoundDrawablePadding = dp(8)
    }
    isClickable = true
    setOnClickListener { onClick() }
}

/** Etiqueta pequeña con borde (año, género, temporadas…). */
fun Context.chip(label: String, highlight: Boolean = false): TextView = TextView(this).apply {
    text = label
    textSize = 13f
    setTextColor(Col.TEXT)
    background = if (highlight) rounded(Color.parseColor("#3A0A0D"), dpf(8f), dp(1), Col.RED)
    else rounded(Color.TRANSPARENT, dpf(8f), dp(1), Col.LINE)
    setPadding(dp(12), dp(6), dp(12), dp(6))
}

/** Fila que se desliza de lado con chips. */
fun Context.chipRow(items: List<TextView>): HorizontalScrollView = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false
    val row = hbox()
    items.forEachIndexed { i, v -> row.addView(v, lp(WRAP, WRAP).apply { if (i > 0) leftMargin = dp(8) }) }
    addView(row)
}

fun Context.iconButton(res: Int, size: Int = 44, tint: Int = Col.TEXT, onClick: () -> Unit): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    val p = dp(10)
    setPadding(p, p, p, p)
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    isClickable = true
    background = rounded(Color.TRANSPARENT, dpf(size / 2f))
    setOnClickListener { onClick() }
}

/** Carga una imagen de internet (o de un archivo local) con caché. */
fun ImageView.show(url: String?, fallbackFile: String? = null) {
    scaleType = ImageView.ScaleType.CENTER_CROP
    when {
        !url.isNullOrBlank() -> load(url) { crossfade(true) }
        fallbackFile != null && File(fallbackFile).exists() -> load(File(fallbackFile)) { crossfade(true) }
        else -> setImageDrawable(null)
    }
}

/** Degradado negro desde abajo, para que el texto se lea sobre la imagen. */
fun fadeBottom(): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Col.BG, Color.parseColor("#99000000"), Color.TRANSPARENT))

/** Tarjeta de portada (2:3) con nombre debajo, como en Netflix. */
fun Context.posterCard(t: Title, widthDp: Int, onClick: () -> Unit): LinearLayout {
    val w = dp(widthDp)
    val box = vbox()
    val frame = FrameLayout(this).apply { background = rounded(Col.CARD, dpf(8f)); clipToOutline = true }
    val img = ImageView(this)
    frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    if (t.poster.isNullOrBlank()) {
        val cover = Catalog.filesOf(t.id).firstOrNull { it.coverPath != null }?.coverPath
        if (cover != null) img.show(null, cover)
        frame.addView(txt(t.name, 13f, Col.TEXT, true, 4).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            if (cover != null) setBackgroundColor(Color.parseColor("#88000000"))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
    } else img.show(t.poster)
    val badgeTxt = if (t.kind == Kind.SERIES) "SERIE" else Catalog.filesOf(t.id).firstOrNull { it.quality.isNotBlank() }?.quality?.uppercase()
    if (!badgeTxt.isNullOrBlank()) {
        frame.addView(txt(badgeTxt, 10f, Col.TEXT, true).apply {
            background = rounded(if (t.kind == Kind.SERIES) Col.RED else Color.parseColor("#CC000000"), dpf(4f))
            setPadding(dp(5), dp(1), dp(5), dp(1))
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { setMargins(dp(5), dp(5), 0, 0) })
    }
    box.addView(frame, LinearLayout.LayoutParams(w, (w * 1.5f).toInt()))
    box.addView(txt(t.name + if (t.year > 0) " (${t.year})" else "", 12f, Col.MUTED, false, 2).apply {
        gravity = Gravity.CENTER_HORIZONTAL
    }, LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dp(6) })
    box.isClickable = true
    box.setOnClickListener { onClick() }
    return box
}

/** Barra de progreso fina (roja sobre gris). */
fun Context.progressBar(fraction: Float, heightDp: Int = 3): FrameLayout = FrameLayout(this).apply {
    setBackgroundColor(Color.parseColor("#55FFFFFF"))
    val bar = View(context).apply { setBackgroundColor(Col.RED) }
    addView(bar, FrameLayout.LayoutParams(0, MATCH))
    layoutParams = LinearLayout.LayoutParams(MATCH, dp(heightDp))
    post { bar.layoutParams = FrameLayout.LayoutParams((width * fraction).toInt(), MATCH) }
}

fun Context.sectionTitle(s: String): TextView = txt(s, 18f, Col.TEXT, true).apply {
    setPadding(dp(14), dp(18), dp(14), dp(8))
}

/** Fila horizontal deslizable de cualquier vista. */
fun Context.hRow(views: List<View>, gapDp: Int = 8): HorizontalScrollView = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false
    clipToPadding = false
    setPadding(dp(14), 0, dp(14), 0)
    val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
    views.forEachIndexed { i, v ->
        val p = (v.layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(WRAP, WRAP)
        if (i > 0) p.leftMargin = dp(gapDp)
        row.addView(v, p)
    }
    addView(row)
}

/** Rayita roja debajo de la pestaña seleccionada. */
fun Context.underline(insetDp: Int = 10): android.graphics.drawable.LayerDrawable =
    android.graphics.drawable.LayerDrawable(
        arrayOf(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT), android.graphics.drawable.ColorDrawable(Col.RED))
    ).apply {
        setLayerGravity(1, Gravity.BOTTOM or Gravity.FILL_HORIZONTAL)
        setLayerHeight(1, dp(3))
        setLayerInsetLeft(1, dp(insetDp))
        setLayerInsetRight(1, dp(insetDp))
    }
