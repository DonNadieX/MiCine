package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.FrameLayout
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : BaseActivity() {

    companion object {
        /** Dónde estabas en Ajustes antes de redibujar. */
        private var keepY = 0
    }

    private val REQ_EXPORT = 11
    private val REQ_IMPORT = 12
    private lateinit var keyStatus: TextView
    private lateinit var refreshStatus: TextView
    private lateinit var localCard: LinearLayout
    private lateinit var maintStatus: TextView
    private val REQ_TREE = 13
    private val REQ_EXPORT_LIST = 14
    private val REQ_IMPORT_LIST = 15

    private var settingsScroll: ScrollView? = null

    /** Al cambiar una opción la pantalla se redibuja, pero se queda donde estabas (antes regresaba arriba). */
    override fun recreate() {
        keepY = settingsScroll?.scrollY ?: 0
        super.recreate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), dp(2)) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        top.addView(heading("Ajustes", 20f), lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this)
        settingsScroll = scroll
        if (keepY > 0) { val y = keepY; keepY = 0; scroll.post { scroll.scrollTo(0, y) } }
        val body = vbox(16).apply { val cp = columnPad(); if (cp > 0) setPadding(cp, dp(16), cp, dp(16)) }

        // --- Proyector / TV ---
        body.addView(header("Proyector y TV"))
        body.addView(tvCard())
        body.addView(header("Celular y proyector sin internet"))
        body.addView(lanCard())

        // --- Temas ---
        body.addView(header("Apariencia"))
        body.addView(txt("Cada tema cambia la forma de navegar, la pantalla de inicio, las tarjetas, la letra y los colores.", 13f, Col.MUTED)
            .apply { setPadding(dp(4), 0, 0, dp(10)) })
        body.addView(themePicker())

        // --- TMDB ---
        body.addView(header("Portadas y sinopsis"))
        val card = card()
        card.addView(txt("Sin hacer nada, la app ya baja portadas y sinopsis gratis: series desde TVmaze (textos en inglés) y películas desde iTunes México (en español).", 13f, Col.TEXT)
            .apply { setLineSpacing(0f, 1.2f) })
        card.addView(txt("Opcional: con una clave de TMDB todo sale en español y con más datos. Si la dejas vacía, se usan las fuentes gratis.", 13f, Col.MUTED)
            .apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
        card.addView(txt(
            "Cómo sacar la clave de TMDB (opcional):\n" +
                "1. Crea una cuenta gratis en themoviedb.org\n" +
                "2. Entra a Ajustes → API y solicita una clave (uso personal)\n" +
                "3. Copia la \"Clave API\" o el \"Token de lectura\" y pégala aquí",
            13f, Col.SOFT
        ).apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
        card.addView(linkText("Abrir la página de TMDB") {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/settings/api"))) }
        })
        val keyEdit = EditText(this).apply {
            hint = "Clave de TMDB (opcional)"
            setHintTextColor(Col.DIM)
            setTextColor(Col.TEXT)
            textSize = 13f
            setSingleLine()
            background = rounded(Col.CARD2, r().coerceAtLeast(dpf(4f)), dp(1), Col.LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setText(Tmdb.key(this@SettingsActivity))
        }
        card.addView(keyEdit, lp().apply { topMargin = dp(12) })
        card.addView(pill("Guardar y probar", true) {
            Tmdb.setKey(this, keyEdit.text.toString())
            if (keyEdit.text.isBlank()) {
                keyStatus.setTextColor(Col.MUTED)
                keyStatus.text = "Sin clave: se usan TVmaze e iTunes (gratis)."
                return@pill
            }
            keyStatus.text = "Probando…"
            scope.launch {
                val err = withContext(Dispatchers.IO) { Tmdb.test(this@SettingsActivity) }
                keyStatus.setTextColor(if (err == null) Col.TEXT else Col.RED)
                keyStatus.text = err?.let { "No funcionó: $it" } ?: "Clave correcta. Ya puedes actualizar los datos del catálogo."
            }
        }, lp().apply { topMargin = dp(10) })
        keyStatus = txt(if (Tmdb.hasKey(this)) "Usando TMDB." else "Sin clave: se usan TVmaze e iTunes (gratis).", 13f, Col.MUTED).apply { setPadding(0, dp(8), 0, 0) }
        card.addView(keyStatus)
        body.addView(card)

        // --- Actualizar ---
        body.addView(header("Catálogo"))
        val c2 = card()
        c2.addView(pill("Actualizar portadas y datos de todo", false) { refreshAll() }, lp())
        refreshStatus = txt("Busca portadas y sinopsis de los títulos que no las tengan, y los nombres de episodios nuevos.", 12f, Col.MUTED)
            .apply { setPadding(0, dp(8), 0, 0) }
        c2.addView(refreshStatus)
        body.addView(c2)

        // --- Contenido local ---
        body.addView(header("Carpetas locales y USB"))
        localCard = card()
        body.addView(localCard)
        renderLocal()

        // --- Reproducción ---
        body.addView(header("Reproducción"))
        val cp = card()
        cp.addView(txt("Reproductor:", 13f, Col.TEXT))
        val curE = Players.engine(this)
        val hasVlc = Players.vlcAppInstalled(this)
        Engine.values().forEach { e ->
            val row = hbox().apply {
                setPadding(0, dp(10), 0, dp(4))
                setOnClickListener {
                    if (e == Engine.VLC_APP && !hasVlc) {
                        android.widget.Toast.makeText(this@SettingsActivity, "Primero instala la app VLC en este aparato.", android.widget.Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    Players.setEngine(this@SettingsActivity, e); recreate()
                }
            }
            row.addView(android.widget.RadioButton(this).apply {
                isChecked = e == curE; isClickable = false
                buttonTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            })
            val c = vbox()
            c.addView(txt(e.label, 14f, Col.TEXT, true))
            c.addView(txt(e.desc + if (e == Engine.VLC_APP && !hasVlc) " (No está instalada.)" else "", 12f, Col.MUTED))
            row.addView(c, lp(0, WRAP, 1f))
            cp.addView(row)
        }
        cp.addView(View(this), lp(MATCH, dp(14)))
        val introOn = Players.skipIntroEnabled(this)
        val secs = listOf(30, 45, 60, 75, 85, 90, 105, 120)
        cp.addView(pill(if (introOn) "Saltar intro: ${Players.introSec(this)} s ▾" else "Saltar intro: apagado ▾", false) {
            val opts = listOf("Apagado") + secs.map { "$it segundos" }
            val sel = if (!Players.skipIntroEnabled(this)) 0 else secs.indexOf(Players.introSec(this)) + 1
            AlertDialog.Builder(this, dialogTheme()).setTitle("Saltar intro")
                .setSingleChoiceItems(opts.toTypedArray(), sel) { d, w ->
                    if (w == 0) Players.setSkipIntro(this, false) else { Players.setSkipIntro(this, true); Players.setIntroSec(this, secs[w - 1]) }
                    d.dismiss(); recreate()
                }.setNegativeButton("Cerrar", null).show()
        }, lp())
        cp.addView(txt("En series aparece el botón \"Saltar intro\" al empezar cada capítulo. Toca para elegir cuánto salta.", 12f, Col.MUTED).apply { setPadding(0, dp(4), 0, dp(8)) })
        if (!Tv.on && android.os.Build.VERSION.SDK_INT >= 26) {
            val pipOn = Players.pipEnabled(this)
            cp.addView(pill(if (pipOn) "Ventana flotante: activada" else "Ventana flotante: apagada", false) {
                Players.setPip(this, !pipOn); recreate()
            }, lp())
            cp.addView(txt("Si sales con el botón de Inicio mientras ves algo, el video sigue en una ventanita. También tienes el botón de ventanita dentro del reproductor.", 12f, Col.MUTED).apply { setPadding(0, dp(4), 0, dp(8)) })
        }
        cp.addView(View(this), lp(MATCH, dp(8)))
        cp.addView(txt("Búfer (cuánto video se guarda por adelantado):", 13f, Col.TEXT))
        val cur = Players.bufferMode(this)
        BufferMode.values().forEach { m ->
            val row = hbox().apply {
                setPadding(0, dp(10), 0, dp(4))
                setOnClickListener { Players.setBufferMode(this@SettingsActivity, m); recreate() }
            }
            row.addView(android.widget.RadioButton(this).apply {
                isChecked = m == cur; isClickable = false
                buttonTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            })
            val c = vbox()
            c.addView(txt(m.label, 14f, Col.TEXT, true))
            c.addView(txt(m.desc, 12f, Col.MUTED))
            row.addView(c, lp(0, WRAP, 1f))
            cp.addView(row)
        }
        body.addView(cp)

        // --- Mantenimiento ---
        body.addView(header("Mantenimiento"))
        val cm = card()
        maintStatus = txt("", 12f, Col.MUTED)
        cm.addView(maintStatus)
        updateMaintStatus()
        cm.addView(pill("Limpiar biblioteca", false) { cleanLibrary() }, lp().apply { topMargin = dp(12) })
        cm.addView(txt("Reacomoda capítulos sueltos en su serie, quita duplicados, archivos que borraste o moviste (solo en memorias conectadas) y revisa links caídos. Esto también se hace solo al abrir la app.", 11f, Col.DIM)
            .apply { setPadding(0, dp(4), 0, 0) })
        cm.addView(pill("Borrar caché de imágenes", false) {
            ImageCache.clear(this)
            toast("Caché borrada. Los pósters se vuelven a descargar al verlos.")
            updateMaintStatus()
        }, lp().apply { topMargin = dp(12) })
        val limits = listOf(100, 250, 500, 1000)
        val lrow = hbox().apply { setPadding(0, dp(10), 0, 0) }
        lrow.addView(txt("Límite de caché:", 12f, Col.MUTED), lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        limits.forEach { mb ->
            lrow.addView(chip(if (mb >= 1000) "1 GB" else "$mb MB", ImageCache.limitMb(this) == mb).apply {
                setOnClickListener { ImageCache.setLimitMb(this@SettingsActivity, mb); toast("Se aplica al reiniciar la app"); recreate() }
            }, lp(WRAP, WRAP).apply { rightMargin = dp(6) })
        }
        cm.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(lrow) })
        val baks = Catalog.backupInfo(this)
        if (baks.isNotEmpty()) {
            cm.addView(txt("Copias automáticas del catálogo (se hacen solas, una por día):", 12f, Col.TEXT).apply { setPadding(0, dp(16), 0, dp(4)) })
            val fmt = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.US)
            baks.forEach { (name, time) ->
                cm.addView(linkText("Restaurar copia del ${fmt.format(java.util.Date(time))}") {
                    android.app.AlertDialog.Builder(this, dialogTheme())
                        .setTitle("¿Restaurar esta copia?")
                        .setMessage("Tu catálogo actual se reemplaza por el de esa fecha.")
                        .setPositiveButton("Restaurar") { _, _ ->
                            toast(if (Catalog.restoreBackup(this, name)) "Copia restaurada" else "Esa copia está dañada")
                        }
                        .setNegativeButton("Cancelar", null).show()
                })
            }
        }
        body.addView(cm)

        // --- Errores ---
        val log = CrashLog.read()
        if (log != null) {
            body.addView(header("Último error"))
            val ce = card()
            ce.addView(txt(log.lines().take(4).joinToString("\n"), 12f, Col.MUTED).apply { typeface = android.graphics.Typeface.MONOSPACE })
            val er = hbox().apply { setPadding(0, dp(10), 0, 0) }
            er.addView(pill("Copiar para enviar", true) {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("error", log))
                toast("Copiado. Pégalo en tu chat con Claude.")
            }, lp(0, WRAP, 1f))
            er.addView(pill("Borrar", false) { CrashLog.clear(); recreate() }, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
            ce.addView(er)
            body.addView(ce)
        }

        // --- Compartir ---
        body.addView(header("Compartir mi lista"))
        shareCard = card()
        body.addView(shareCard)
        renderShare()

        body.addView(header("Mi bot de Telegram"))
        body.addView(botCard())

        body.addView(header("Listas que sigo"))
        subsCard = card()
        body.addView(subsCard)
        renderSubs()

        body.addView(header("Actualizaciones de la app"))
        body.addView(updatesCard())

        // --- Respaldo ---
        body.addView(header("Respaldo"))
        val c3 = card()
        c3.addView(txt("Guarda todo tu catálogo (links, progreso, portadas) en un archivo, para no perderlo o pasarlo a otro celular.", 13f, Col.MUTED))
        c3.addView(pill("Exportar respaldo", false) {
            val name = "mi_cine_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json"
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT)
        }, lp().apply { topMargin = dp(12) })
        c3.addView(pill("Importar respaldo", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*"), REQ_IMPORT)
        }, lp().apply { topMargin = dp(10) })
        body.addView(c3)

        // --- Borrar ---
        body.addView(header("Zona de peligro"))
        val c4 = card()
        c4.addView(pill("Borrar todo el catálogo", false) {
            AlertDialog.Builder(this, dialogTheme())
                .setTitle("¿Borrar todo?")
                .setMessage("Se quitan todos los links y el progreso. Exporta un respaldo antes si lo quieres conservar.")
                .setPositiveButton("Borrar todo") { _, _ -> Catalog.clearAll(); toast("Catálogo vacío") }
                .setNegativeButton("Cancelar", null).show()
        }.apply { setTextColor(Col.RED) }, lp())
        body.addView(c4)

        val stats = Catalog.titles()
        body.addView(txt("${stats.count { it.kind == Kind.SERIES }} series · ${stats.count { it.kind == Kind.MOVIE }} películas",
            12f, Col.DIM).apply { setPadding(dp(4), dp(20), 0, 0) })

        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun refreshAll() {
        val list = Catalog.titles()
        // Sigue aunque salgas de esta pantalla o de la app (verás una notificación).
        askNotifications()
        MetaWork.enqueue(this, list.map { it.id })
        val work = MetaWork.start(this)
        scope.launch {
            while (work.isActive) {
                refreshStatus.text = "${MetaWork.done} / ${MetaWork.total} · ${MetaWork.current}\nPuedes salir: seguirá buscando en segundo plano."
                kotlinx.coroutines.delay(500)
            }
            refreshStatus.setTextColor(Col.TEXT)
            refreshStatus.text = "Listo: ${list.count { Catalog.title(it.id)?.ext?.isNotBlank() == true }} de ${list.size} títulos con datos."
        }
    }

    @Deprecated("API de Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_TREE -> {
                Local.addFolder(this, uri)
                renderLocal()
                scanNow()
            }
            REQ_EXPORT_LIST -> runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(Share.exportList(this).toString(1).toByteArray()) }
                toast("Lista guardada")
            }.onFailure { toast("No se pudo guardar: ${it.message}") }
            REQ_IMPORT_LIST -> runCatching {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                toast("Agregados ${Share.importFile(text)} archivos de la lista")
            }.onFailure { toast("Ese archivo no es una lista de Mi Cine") }
            REQ_EXPORT -> runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(Catalog.exportJson().toByteArray()) }
                toast("Respaldo guardado")
            }.onFailure { toast("No se pudo guardar: ${it.message}") }
            REQ_IMPORT -> runCatching {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val n = Catalog.importJson(text)
                toast("Importados $n archivos nuevos")
            }.onFailure { toast("Archivo no válido: ${it.message}") }
        }
    }

    // ---------------- Temas ----------------
    private fun themePicker(): View {
        val sv = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = hbox().apply { gravity = Gravity.TOP }
        Themes.all.forEach { t ->
            val on = t.id == Themes.cur.id
            val box = vbox().apply {
                setPadding(dp(8), dp(8), dp(8), dp(10))
                background = rounded(Col.CARD, dpf(10f), dp(if (on) 2 else 1), if (on) Col.RED else Col.LINE)
                setOnClickListener {
                    if (!on) { Themes.set(this@SettingsActivity, t.id); recreate() }
                }
            }
            box.addView(miniPreview(t), LinearLayout.LayoutParams(dp(150), dp(112)))
            box.addView(txt(t.name, 15f, Col.TEXT, true).apply { setPadding(0, dp(8), 0, 0) })
            box.addView(txt(t.inspiredBy, 11f, Col.RED, true))
            box.addView(txt(t.description, 11f, Col.MUTED, false, 4).apply { setPadding(0, dp(3), 0, 0) },
                LinearLayout.LayoutParams(dp(150), WRAP))
            if (on) box.addView(txt("✓ En uso", 11f, Col.RED, true).apply { setPadding(0, dp(6), 0, 0) })
            row.addView(box, lp(WRAP, WRAP).apply { rightMargin = dp(10) })
        }
        sv.addView(row)
        return sv
    }

    /** Dibujito del acomodo de cada tema, con sus propios colores. */
    private fun miniPreview(t: UiTheme): View {
        val f = FrameLayout(this).apply { background = rounded(t.bg, dpf(6f), dp(1), t.line); clipToOutline = true }
        fun block(color: Int, x: Int, y: Int, w: Int, h: Int, rad: Float = t.radius / 3f) {
            f.addView(View(this).apply { background = rounded(color, dpf(rad)) },
                FrameLayout.LayoutParams(dp(w), dp(h)).apply { leftMargin = dp(x); topMargin = dp(y) })
        }
        when (t.home) {
            HomeStyle.ROWS -> {
                block(t.accent, 8, 6, 30, 5)
                block(t.card2, 8, 16, 134, 46)
                block(t.accent, 50, 50, 50, 8, 2f)
                for (i in 0 until 5) block(t.card2, 8 + i * 28, 70, 24, 36)
            }
            HomeStyle.FANART -> {
                block(t.card, 0, 0, 22, 112, 0f)
                for (i in 0 until 4) block(if (i == 0) t.accent else t.muted, 7, 14 + i * 16, 8, 8, 2f)
                block(t.card2, 28, 6, 116, 50)
                block(t.text, 34, 40, 40, 5)
                for (i in 0 until 2) block(t.card2, 28 + i * 60, 64, 56, 32)
                block(t.muted, 28, 100, 40, 4)
            }
            HomeStyle.WALL -> {
                block(t.accent, 6, 6, 34, 16, 0f)
                block(t.muted, 44, 12, 50, 4, 0f)
                for (r in 0 until 2) for (c in 0 until 3) block(if ((r + c) % 2 == 0) t.card2 else t.line, c * 50, 28 + r * 42, 50, 42, 0f)
                block(t.card, 0, 102, 150, 10, 0f)
                for (i in 0 until 4) block(if (i == 0) t.accent else t.muted, 14 + i * 36, 105, 8, 4, 0f)
            }
            HomeStyle.LIST -> {
                for (i in 0 until 4) block(if (i == 0) t.accent else t.card2, 8 + i * 34, 6, 30, 9, 5f)
                for (r in 0 until 3) {
                    block(t.card, 6, 22 + r * 30, 138, 26, 4f)
                    block(t.card2, 10, 25 + r * 30, 14, 20, 2f)
                    block(t.text, 30, 27 + r * 30, 60, 4)
                    block(t.accent, 30, 34 + r * 30, 40, 3)
                    block(t.muted, 30, 40 + r * 30, 90, 3)
                }
            }
            HomeStyle.SALAS -> {
                block(t.accent, 8, 6, 30, 5)
                block(t.card2, 8, 16, 134, 30)
                val salas = listOf("#F5A524", "#5EA2F5", "#F06AAA")
                salas.forEachIndexed { i, h ->
                    val col = android.graphics.Color.parseColor(h)
                    block(Col.blend(col, t.bg, 0.6f), 8, 52 + i * 20, 134, 17, 4f)
                    block(col, 12, 56 + i * 20, 26, 4, 1f)
                    for (k in 0 until 3) block(col, 92 + k * 16, 55 + i * 20, 12, 11, 2f)
                }
            }
            HomeStyle.MAGAZINE -> {
                block(t.text, 40, 6, 70, 8, 0f)
                block(t.text, 8, 18, 134, 2, 0f)
                block(t.card2, 8, 24, 52, 50, 0f)
                block(t.accent, 66, 26, 28, 3, 0f)
                block(t.text, 66, 32, 70, 7, 0f)
                for (i in 0 until 4) block(t.muted, 66, 44 + i * 7, 72, 3, 0f)
                for (i in 0 until 3) {
                    block(t.accent, 8, 82 + i * 9, 10, 6, 0f)
                    block(t.text, 22, 83 + i * 9, 90, 4, 0f)
                }
            }
        }
        return f
    }

    // ---------------- Carpetas locales ----------------
    private lateinit var localStatus: TextView

    private fun renderLocal() {
        localCard.removeAllViews()
        localCard.addView(txt("Carpetas del celular, tarjeta SD o memoria USB (OTG) donde la app busca videos.", 13f, Col.MUTED)
            .apply { setLineSpacing(0f, 1.2f) })
        val list = Local.folders(this)
        if (list.isEmpty()) localCard.addView(txt("Aún no agregas carpetas.", 13f, Col.DIM).apply { setPadding(0, dp(10), 0, 0) })
        list.forEach { u ->
            val info = Local.folderInfo(this, u)
            val ok = Local.isFolderAvailable(this, u)
            val row = hbox().apply { setPadding(0, dp(10), 0, 0) }
            row.addView(ImageView(this).apply {
                setImageResource(if (info.removable) R.drawable.ic_usb else R.drawable.ic_folder)
                setColorFilter(if (ok) Col.RED else Col.DIM)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            val c = vbox().apply { setPadding(dp(10), 0, 0, 0) }
            c.addView(txt(info.name, 13f, Col.TEXT, true, 2))
            c.addView(txt(if (ok) "Conectada" else "No conectada ahora", 11f, if (ok) Col.MUTED else Col.RED))
            row.addView(c, lp(0, WRAP, 1f))
            row.addView(iconButton(R.drawable.ic_close, 40, Col.MUTED) {
                android.app.AlertDialog.Builder(this, dialogTheme())
                    .setTitle("¿Dejar de usar esta carpeta?")
                    .setMessage("Los videos que ya agregaste se quedan en tu catálogo. Solo deja de buscar nuevos ahí.")
                    .setPositiveButton("Quitar") { _, _ -> Local.removeFolder(this, u); renderLocal() }
                    .setNegativeButton("Cancelar", null).show()
            })
            localCard.addView(row)
        }
        // Todos los videos del aparato y USB (recomendado en proyector)
        localCard.addView(txt("O sin elegir carpetas: busca todos los videos del aparato y de memorias USB/SD (no incluye cámara ni WhatsApp).", 12f, Col.DIM)
            .apply { setPadding(0, dp(12), 0, 0) })
        localCard.addView(pill("Buscar todos los videos (aparato y USB)", false, R.drawable.ic_usb) { mediaScanNow() }, lp().apply { topMargin = dp(8) })
        if (MediaScan.autoEnabled(this)) localCard.addView(txt("✓ Se buscan videos nuevos cada vez que abres la app", 12f, Col.MUTED).apply { setPadding(0, dp(4), 0, 0) })
        val b = hbox().apply { setPadding(0, dp(14), 0, 0) }
        b.addView(pill("Agregar carpeta", true, R.drawable.ic_add) {
            runCatching { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_TREE) }
                .onFailure { toast("Este aparato no tiene selector de carpetas: usa \"Buscar todos los videos\"") }
        }, lp(0, WRAP, 1f))
        if (list.isNotEmpty()) b.addView(pill("Buscar nuevos", false, R.drawable.ic_refresh) { scanNow() }, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        localCard.addView(b)
        val auto = hbox().apply {
            setPadding(0, dp(12), 0, 0)
            setOnClickListener { Local.setAutoScan(this@SettingsActivity, !Local.autoScanEnabled(this@SettingsActivity)); renderLocal() }
        }
        auto.addView(android.widget.CheckBox(this).apply {
            isChecked = Local.autoScanEnabled(this@SettingsActivity); isClickable = false
            buttonTintList = android.content.res.ColorStateList.valueOf(Col.RED)
        })
        auto.addView(txt("Buscar archivos nuevos cada vez que abro la app", 13f, Col.TEXT), lp(0, WRAP, 1f))
        localCard.addView(auto)
        localStatus = txt("", 12f, Col.MUTED).apply { setPadding(0, dp(8), 0, 0) }
        localCard.addView(localStatus)
    }

    private val REQ_MEDIA = 16

    private fun mediaScanNow() {
        if (!MediaScan.hasPermission(this)) { MediaScan.requestPermission(this, REQ_MEDIA); return }
        localStatus.text = "Buscando videos en el aparato y USB…"
        scope.launch {
            val r = runCatching { MediaScan.scan(applicationContext) { d, t, m -> localStatus.text = "$d / $t · $m" } }
            MediaScan.setAuto(applicationContext, true)
            localStatus.text = r.fold({ n -> if (n == 0) "No hay videos nuevos." else "Listo: $n videos agregados." }, { "Error: ${it.message}" })
            renderLocalKeepStatus()
        }
    }

    @Deprecated("API de Activity")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MEDIA) {
            if (MediaScan.hasPermission(this)) mediaScanNow() else toast("Sin permiso no puedo ver los videos del aparato")
        }
    }

    // ---------------- Proyector / TV ----------------
    private var receiver: Link.Receiver? = null

    private fun tvCard(): View {
        val c = card()
        c.addView(txt(if (Tv.on) "Modo proyector ACTIVO: menú lateral, letras grandes y todo se maneja con las flechas del control."
            else "El modo proyector adapta la app a pantalla grande y control remoto (flechas + OK).", 13f, Col.MUTED).apply { setLineSpacing(0f, 1.2f) })
        val row = hbox().apply { setPadding(0, dp(10), 0, 0) }
        Tv.Mode.values().forEach { m ->
            row.addView(chip(m.label, Tv.mode(this) == m).apply {
                isClickable = true
                setOnClickListener {
                    if (Tv.mode(this@SettingsActivity) == m) return@setOnClickListener
                    Tv.setMode(this@SettingsActivity, m)
                    toast("Reiniciando para aplicar…")
                    restartApp()
                }
            }, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        c.addView(row)
        c.addView(txt("Automático: se activa en Android TV, en aparatos sin pantalla táctil o cuando detecta el control remoto.", 11f, Col.DIM).apply { setPadding(0, dp(6), 0, 0) })

        // Recibir (en el proyector) / Enviar (desde el celular)
        val b = hbox().apply { setPadding(0, dp(14), 0, 0) }
        b.addView(pill("Recibir desde mi celular", Tv.on, R.drawable.ic_tv) { receiveDialog() }, lp(0, WRAP, 1f))
        b.addView(pill("Enviar a mi proyector", !Tv.on) { sendDialog() }, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        c.addView(b)
        c.addView(txt("Pasa tus links, listas, clave de TMDB y tema del celular al proyector por tu Wi-Fi, sin escribir nada con el control.", 11f, Col.DIM).apply { setPadding(0, dp(6), 0, 0) })
        return c
    }

    /** Mi Cine Bot: lo que subas a tu canal privado aparece solo aquí. */
    private fun botCard(): View {
        val c = card()
        val cur = TgBot.url(this)
        c.addView(txt(if (cur == null) "Conecta tu bot: en Telegram escríbele /app y pega aquí el link que te da. Todo lo que subas a tu canal aparecerá solo en Mi Cine."
            else "Conectado ✓ · ${TgBot.lastCount(this)} videos en tu canal" + (if (TgBot.lastSync(this) > 0) " · revisado " + android.text.format.DateUtils.getRelativeTimeSpanString(TgBot.lastSync(this)) else ""),
            13f, Col.MUTED).apply { setLineSpacing(0f, 1.2f) })
        val edit = field(cur ?: "", "https://….koyeb.app/lista?k=…").apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        c.addView(edit, lp().apply { topMargin = dp(10) })
        val st = txt("", 12f, Col.MUTED).apply { setPadding(0, dp(6), 0, 0) }
        val row = hbox().apply { setPadding(0, dp(8), 0, 0) }
        row.addView(pill(if (cur == null) "Conectar" else "Actualizar ahora", true) {
            val u = edit.text.toString().trim()
            if (!TgBot.isValid(u)) { st.setTextColor(Col.RED); st.text = "Ese no parece el link del bot. En Telegram escríbele /app y cópialo completo."; return@pill }
            TgBot.setUrl(this, u)
            st.setTextColor(Col.MUTED); st.text = "Conectando con el bot (si estaba dormido tarda unos segundos)…"
            askNotifications()
            scope.launch {
                val r = runCatching { TgBot.sync(applicationContext) { d, t, m -> st.text = "$d / $t · $m" } }
                r.onSuccess { n -> st.setTextColor(Col.TEXT); st.text = if (n > 0) "✓ $n videos nuevos agregados" else "✓ Todo al día" }
                    .onFailure { st.setTextColor(Col.RED); st.text = it.message ?: "No se pudo conectar" }
            }
        }, lp(0, WRAP, 1f))
        if (cur != null) row.addView(pill("Desconectar", false) { TgBot.setUrl(this, null); recreate() }, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        c.addView(row)
        c.addView(st)
        return c
    }

    /** Compartir la biblioteca del celular / buscarla desde el proyector (como BubbleUPnP). */
    private fun lanCard(): View {
        val c = card()
        c.addView(txt("Ve en el proyector los videos de tu celular sin internet: activa el punto de acceso del celular, conecta el proyector a esa red y listo. No gasta datos.", 13f, Col.MUTED).apply { setLineSpacing(0f, 1.2f) })
        // En el celular
        val sharing = ShareService.on
        c.addView(pill(if (sharing) "Compartiendo mi biblioteca ✓ (tocar para apagar)" else "Compartir mi biblioteca", !Tv.on && !sharing, R.drawable.ic_movie) {
            if (ShareService.on) ShareService.stop(this) else { askNotifications(); ShareService.start(this) }
            android.os.Handler(mainLooper).postDelayed({ recreate() }, 500)
        }, lp().apply { topMargin = dp(12) })
        if (sharing) c.addView(txt("IP de este aparato: ${LibraryShare.ips().joinToString(", ")}  ·  También aparece como \"Mi Cine\" en VLC, BubbleUPnP o tu Smart TV (Red local / DLNA).", 11f, Col.DIM).apply { setPadding(0, dp(6), 0, 0) })
        c.addView(pill("Control remoto del proyector", false, R.drawable.ic_tv) {
            startActivity(Intent(this, RemoteActivity::class.java))
        }, lp().apply { topMargin = dp(8) })
        // En el proyector
        val dev = RemoteLib.savedName(this)
        c.addView(pill(if (dev != null) "Actualizar desde mi celular ($dev)" else "Buscar mi celular", Tv.on, R.drawable.ic_refresh) { findPhone() },
            lp().apply { topMargin = dp(8) })
        if (dev != null) c.addView(linkText("Olvidar este celular (quita sus videos del proyector)") {
            AlertDialog.Builder(this, dialogTheme()).setTitle("¿Olvidar $dev?")
                .setMessage("Se quitan del proyector los videos que vienen de ese celular. Tus otros videos no se tocan.")
                .setPositiveButton("Olvidar") { _, _ -> RemoteLib.forget(this); recreate() }
                .setNegativeButton("Cancelar", null).show()
        })
        return c
    }

    private fun findPhone() {
        val st = txt("Buscando tu celular en la red…", 15f, Col.TEXT).apply { setPadding(dp(24), dp(20), dp(24), dp(8)) }
        val dlg = AlertDialog.Builder(this, dialogTheme()).setTitle("Mi celular").setView(st)
            .setNegativeButton("Cerrar", null).create()
        dlg.setOnDismissListener { recreate() }
        dlg.show()
        scope.launch {
            val h = RemoteLib.discover(applicationContext)
            if (h == null) {
                st.setTextColor(Col.RED)
                st.text = "No encontré tu celular.\n\n1) En el celular: Ajustes → \"Compartir mi biblioteca\".\n2) Conecta este aparato a la red (punto de acceso) del celular.\n3) Vuelve a intentar."
                return@launch
            }
            RemoteLib.connect(applicationContext, h)
            st.text = "Encontré: ${h.name}\nCopiando tu catálogo…"
            val r = runCatching { RemoteLib.sync(applicationContext, h) { msg -> runOnUiThread { st.text = "Encontré: ${h.name}\n$msg" } } }
            r.onSuccess {
                RemoteLib.ensureLoop(applicationContext)
                st.text = "✓ Conectado a ${h.name}\n${it.files} videos nuevos" + (if (it.titles > 0) " · ${it.titles} títulos" else "") +
                    (if (it.removed > 0) " · ${it.removed} quitados" else "") + "\n\nYa puedes cerrar. Desde el celular también puedes mandar qué ver."
            }.onFailure { st.setTextColor(Col.RED); st.text = "No se pudo copiar: ${it.message}" }
        }
    }

    private fun receiveDialog() {
        val ip = Link.localIp()
        if (ip == null) { toast("Conecta este aparato a tu Wi-Fi primero"); return }
        val pin = Link.newPin()
        val box = vbox(20).apply { gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(txt("En tu celular abre Mi Cine → Ajustes → \"Enviar a mi proyector\" y escribe:", 15f, Col.TEXT).apply { gravity = Gravity.CENTER })
        box.addView(txt("Dirección", 13f, Col.MUTED).apply { setPadding(0, dp(16), 0, 0) })
        box.addView(txt(ip, 34f, Col.RED, true))
        box.addView(txt("Código", 13f, Col.MUTED).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(txt(pin, 34f, Col.TEXT, true).apply { letterSpacing = 0.3f })
        val st = txt("Esperando al celular…", 13f, Col.MUTED).apply { setPadding(0, dp(14), 0, 0); gravity = Gravity.CENTER }
        box.addView(st)
        val dlg = AlertDialog.Builder(this, dialogTheme()).setTitle("Recibir desde mi celular").setView(box)
            .setNegativeButton("Cerrar", null).create()
        val r = Link.Receiver(applicationContext, pin) { msg ->
            runOnUiThread {
                st.setTextColor(Col.TEXT); st.text = "✓ $msg"
                toast(msg)
            }
        }
        receiver = r
        dlg.setOnDismissListener { r.stop(); receiver = null; recreate() }
        dlg.show()
        scope.launch {
            val res = withContext(Dispatchers.IO) { runCatching { r.run() } }
            res.onFailure { st.setTextColor(Col.RED); st.text = "No se pudo abrir la recepción: ${it.message}" }
        }
    }

    private fun sendDialog() {
        val box = vbox(18)
        box.addView(txt("En el proyector abre Mi Cine → Ajustes → \"Recibir desde mi celular\". Escribe aquí la dirección y el código que aparecen:", 13f, Col.TEXT))
        val ipEdit = field(getSharedPreferences("ajustes", MODE_PRIVATE).getString("ip_proyector", "")!!, "Dirección (ej. 192.168.1.23)").apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val pinEdit = field("", "Código de 4 números").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(ipEdit, lp().apply { topMargin = dp(10) })
        box.addView(pinEdit, lp().apply { topMargin = dp(8) })
        fun check(label: String, on: Boolean) = android.widget.CheckBox(this).apply {
            text = label; isChecked = on; setTextColor(Col.TEXT)
            buttonTintList = android.content.res.ColorStateList.valueOf(Col.RED)
        }
        val cCat = check("Mis links (con portadas y datos)", true)
        val cList = check("Mis listas compartidas (se actualizan solas)", true)
        val cKey = check("Mi clave de TMDB", Tmdb.hasKey(this))
        val cTheme = check("Mi tema", false)
        listOf(cCat, cList, cKey, cTheme).forEach { box.addView(it) }
        box.addView(txt("Los archivos de tu celular (carpetas) no se envían: en el proyector usa \"Buscar todos los videos\" para los de su USB.", 11f, Col.DIM).apply { setPadding(0, dp(6), 0, 0) })
        AlertDialog.Builder(this, dialogTheme()).setTitle("Enviar a mi proyector").setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Enviar") { _, _ ->
                val ip = ipEdit.text.toString().trim()
                getSharedPreferences("ajustes", MODE_PRIVATE).edit().putString("ip_proyector", ip).apply()
                toast("Enviando…")
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        runCatching { Link.send(applicationContext, ip, pinEdit.text.toString(),
                            Link.SendOptions(cCat.isChecked, cList.isChecked, cKey.isChecked, cTheme.isChecked)) }
                    }
                    AlertDialog.Builder(this@SettingsActivity, dialogTheme())
                        .setTitle(if (r.isSuccess) "¡Listo!" else "No se pudo enviar")
                        .setMessage(r.getOrElse { it.message ?: "Error" })
                        .setPositiveButton("OK", null).show()
                }
            }.show()
    }

    override fun onDestroy() {
        receiver?.stop()
        super.onDestroy()
    }

    private fun scanNow() {
        localStatus.text = "Buscando videos…"
        scope.launch {
            val r = runCatching {
                Local.scanAll(applicationContext) { done, total, msg -> localStatus.text = "$done / $total · $msg" }
            }
            localStatus.text = r.fold({ n -> if (n == 0) "No hay archivos nuevos." else "Listo: $n archivos nuevos agregados." },
                { "Error: ${it.message}" })
            renderLocalKeepStatus()
        }
    }

    private fun renderLocalKeepStatus() {
        val msg = localStatus.text
        renderLocal()
        localStatus.text = msg
    }

    // ---------------- Mantenimiento ----------------
    private fun mb(b: Long) = String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)

    private fun updateMaintStatus() {
        val (t, f, l) = Catalog.stats()
        maintStatus.text = "Biblioteca: $t títulos · $f archivos ($l locales)\n" +
            "Caché de imágenes: ${mb(ImageCache.sizeBytes(this))} de ${ImageCache.limitMb(this)} MB · Carátulas: ${mb(ImageCache.coversBytes(this))}"
    }

    private fun cleanLibrary() {
        maintStatus.text = "Revisando tu biblioteca y tus links… (puede tardar un poco)"
        scope.launch {
            val rep = Maintenance.runAll(applicationContext, checkLinks = true)
            updateMaintStatus()
            AlertDialog.Builder(this@SettingsActivity, dialogTheme())
                .setTitle("Limpieza terminada")
                .setMessage(rep.summary())
                .setPositiveButton("Listo", null).show()
        }
    }

    // ---------------- Compartir ----------------
    private lateinit var shareCard: LinearLayout
    private lateinit var subsCard: LinearLayout

    private fun field(value: String, hint: String) = EditText(this).apply {
        setText(value); this.hint = hint
        setHintTextColor(Col.DIM); setTextColor(Col.TEXT); textSize = 13f; setSingleLine()
        background = rounded(Col.CARD2, r().coerceAtLeast(dpf(4f)), dp(1), Col.LINE)
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun renderShare() {
        val c = shareCard
        c.removeAllViews()
        val url = Share.publicUrl(this)
        val nLinks = Catalog.allFiles().count { !Local.isLocal(it.url) && it.source.isEmpty() }
        c.addView(txt("Comparte tus links (con portadas y datos ya buscados) para que otra persona los vea en su Mi Cine. Se actualiza solo: lo que agregues o quites le aparece la próxima vez que abra la app.", 13f, Col.MUTED)
            .apply { setLineSpacing(0f, 1.2f) })
        c.addView(txt("Tienes $nLinks links para compartir. Los archivos de tu celular no se comparten.", 12f, Col.DIM).apply { setPadding(0, dp(6), 0, 0) })
        if (Share.token(this).isBlank()) {
            c.addView(txt(
                "Para activarlo (una sola vez):\n" +
                    "1. En github.com toca tu foto → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token (classic).\n" +
                    "2. Nombre: Mi Cine · Expiration: No expiration · marca solo la casilla \"gist\".\n" +
                    "3. Toca Generate token, cópialo y pégalo aquí.", 12f, Col.SOFT).apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
            c.addView(linkText("Abrir la página de tokens de GitHub") {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/settings/tokens/new?scopes=gist&description=Mi%20Cine"))) }
            })
        }
        val tk = field(Share.token(this), "Token de GitHub (ghp_…)")
        c.addView(tk, lp().apply { topMargin = dp(8) })
        val nm = field(Share.listName(this), "Nombre de tu lista")
        c.addView(nm, lp().apply { topMargin = dp(8) })
        val st = txt(if (url != null) "Publicada: " + java.text.SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(Share.lastPublished(this))) else "", 12f, Col.MUTED)
        c.addView(pill(if (url == null) "Crear mi lista compartida" else "Publicar ahora", true, R.drawable.ic_refresh) {
            Share.setToken(this, tk.text.toString())
            Share.setListName(this, nm.text.toString().ifBlank { "Mi Cine" })
            st.text = "Publicando…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { Share.publish(applicationContext) } }
                r.onSuccess { toast("Lista publicada"); renderShare() }.onFailure { st.setTextColor(Col.RED); st.text = it.message }
            }
        }, lp().apply { topMargin = dp(10) })
        c.addView(st.apply { setPadding(0, dp(6), 0, 0) })
        if (url != null) {
            c.addView(txt("Link de tu lista:", 12f, Col.TEXT, true).apply { setPadding(0, dp(10), 0, 0) })
            c.addView(txt(url, 11f, Col.MUTED).apply { setTextIsSelectable(true) })
            val b = hbox().apply { setPadding(0, dp(8), 0, 0) }
            b.addView(pill("Enviar invitación", true) {
                val msg = "Te comparto mi Mi Cine 🎬\n\n1) Descarga la app: ${Updater.downloadPage(this)}\n" +
                    "2) Ábrela → Ajustes → Listas que sigo → pega este link:\n$url"
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Enviar con…"))
            }, lp(0, WRAP, 1f))
            b.addView(pill("Copiar link", false) {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("lista", url))
                toast("Link copiado")
            }, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
            c.addView(b)
            val auto = hbox().apply {
                setPadding(0, dp(10), 0, 0)
                setOnClickListener { Share.setAutoPublish(this@SettingsActivity, !Share.autoPublish(this@SettingsActivity)); renderShare() }
            }
            auto.addView(android.widget.CheckBox(this).apply {
                isChecked = Share.autoPublish(this@SettingsActivity); isClickable = false
                buttonTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            })
            auto.addView(txt("Publicar los cambios solos (al agregar links y al abrir la app)", 13f, Col.TEXT), lp(0, WRAP, 1f))
            c.addView(auto)
        }
        c.addView(linkText("Guardar mi lista en un archivo") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, "lista_mi_cine.json"), REQ_EXPORT_LIST)
        })
    }

    private fun renderSubs() {
        val c = subsCard
        c.removeAllViews()
        c.addView(txt("Pega el link de la lista que alguien te compartió. Se revisa sola cada vez que abres la app.", 13f, Col.MUTED))
        val subs = Share.subscriptions(this)
        val fmt = java.text.SimpleDateFormat("dd/MM HH:mm", Locale.US)
        subs.forEach { s ->
            val row = hbox().apply { setPadding(0, dp(10), 0, 0) }
            val col = vbox()
            col.addView(txt(s.name, 14f, Col.TEXT, true, 1))
            col.addView(txt("${s.count} archivos · revisada ${if (s.lastSync > 0) fmt.format(Date(s.lastSync)) else "nunca"}", 11f, Col.MUTED))
            row.addView(col, lp(0, WRAP, 1f))
            row.addView(iconButton(R.drawable.ic_close, 40, Col.MUTED) {
                AlertDialog.Builder(this, dialogTheme())
                    .setTitle("¿Dejar de seguir \"${s.name}\"?")
                    .setPositiveButton("Dejar y borrar sus títulos") { _, _ -> Share.removeSubscription(this, s.url, true); renderSubs() }
                    .setNeutralButton("Dejar pero conservarlos") { _, _ -> Share.removeSubscription(this, s.url, false); renderSubs() }
                    .setNegativeButton("Cancelar", null).show()
            })
            c.addView(row)
        }
        val input = field("", "Link de la lista (gist.github.com/…)")
        c.addView(input, lp().apply { topMargin = dp(12) })
        val st = txt("", 12f, Col.MUTED).apply { setPadding(0, dp(6), 0, 0) }
        val b = hbox().apply { setPadding(0, dp(8), 0, 0) }
        b.addView(pill("Seguir lista", true, R.drawable.ic_add) {
            val u = input.text.toString().trim()
            if (!u.startsWith("http")) { st.setTextColor(Col.RED); st.text = "Pega un link que empiece con https://"; return@pill }
            st.text = "Descargando la lista…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { Share.sync(applicationContext, u) } }
                r.onSuccess { (a, _) -> toast("Listo: $a títulos/capítulos agregados"); renderSubs() }
                    .onFailure { st.setTextColor(Col.RED); st.text = it.message }
            }
        }, lp(0, WRAP, 1f))
        if (subs.isNotEmpty()) b.addView(pill("Revisar ya", false, R.drawable.ic_refresh) {
            st.text = "Revisando…"
            scope.launch {
                val (a, r) = withContext(Dispatchers.IO) { Share.syncAll(applicationContext, force = true) }
                st.text = "$a nuevos · $r quitados"
                renderSubs()
            }
        }, lp(0, WRAP, 1f).apply { leftMargin = dp(8) })
        c.addView(b)
        c.addView(st)
        c.addView(linkText("Importar una lista desde archivo") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_IMPORT_LIST)
        })
    }

    // ---------------- Actualizaciones ----------------
    private fun updatesCard(): View {
        val c = card()
        c.addView(txt("Versión instalada: ${Updater.currentName(this)}", 14f, Col.TEXT, true))
        c.addView(txt("La app revisa sola si hay versión nueva cada vez que la abres (máximo 2 veces al día).", 12f, Col.MUTED).apply { setPadding(0, dp(4), 0, 0) })
        val repo = field(Updater.repo(this), "usuario/repositorio de GitHub")
        c.addView(repo, lp().apply { topMargin = dp(10) })
        val st = txt("", 12f, Col.MUTED).apply { setPadding(0, dp(6), 0, 0) }
        c.addView(pill("Buscar actualización", true, R.drawable.ic_refresh) {
            Updater.setRepo(this, repo.text.toString().ifBlank { Updater.DEFAULT_REPO })
            st.setTextColor(Col.MUTED); st.text = "Buscando…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { Updater.latest(applicationContext) } }
                r.onSuccess { rel ->
                    if (rel == null) st.text = "No encontré versiones con APK."
                    else if (rel.code > Updater.currentCode(this@SettingsActivity)) { st.text = "Hay versión nueva: ${rel.name}"; Updater.offer(this@SettingsActivity, rel, false) }
                    else st.text = "Ya tienes la última versión."
                }.onFailure { st.setTextColor(Col.RED); st.text = it.message }
            }
        }, lp().apply { topMargin = dp(10) })
        c.addView(st)
        c.addView(linkText("Copiar link de descarga de la app") {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                .setPrimaryClip(android.content.ClipData.newPlainText("app", Updater.downloadPage(this)))
            toast("Link copiado")
        })
        return c
    }

    private fun header(s: String) = heading(s.uppercase(), 12f, Col.RED).apply {
        letterSpacing = 0.08f
        setPadding(dp(4), dp(18), 0, dp(8))
    }

    private fun card(): LinearLayout = vbox().apply {
        background = rounded(Col.CARD, r(1.5f))
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun linkText(s: String, onClick: () -> Unit): View = txt(s, 13f, Col.RED, true).apply {
        setPadding(0, dp(10), 0, dp(4))
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
