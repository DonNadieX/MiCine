package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.URL
import kotlin.random.Random

/**
 * "Enviar al proyector": el celular le pasa al proyector (por tu Wi-Fi, sin internet de por medio):
 *  - tus links con portadas y datos,
 *  - la lista compartida que sigues o publicas (para que se actualice sola),
 *  - tu clave de TMDB y tu tema.
 * Así no tienes que escribir nada con el control remoto.
 */
object Link {

    const val PORT = 8765

    /** IP del aparato en tu Wi-Fi, ej. 192.168.1.23 */
    fun localIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else if (it.name.startsWith("eth")) 1 else 2 }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    }.getOrNull()

    fun newPin(): String = (1000 + Random.nextInt(9000)).toString()

    // ---------------- Lado del proyector (recibe) ----------------
    class Receiver(private val ctx: Context, val pin: String, private val onReceived: (String) -> Unit) {
        @Volatile private var running = true
        private var server: ServerSocket? = null

        fun stop() { running = false; runCatching { server?.close() } }

        /** Bloquea el hilo: llámalo desde Dispatchers.IO. */
        fun run() {
            val s = ServerSocket()
            s.reuseAddress = true
            s.bind(InetSocketAddress(PORT))
            s.soTimeout = 1000
            server = s
            while (running) {
                val sock = try { s.accept() } catch (_: SocketTimeoutException) { continue } catch (_: Exception) { break }
                sock.use { c ->
                    c.soTimeout = 15_000
                    val input = BufferedInputStream(c.getInputStream())
                    val head = ByteArrayOutputStream()
                    // Lee los encabezados hasta la línea vacía
                    var last4 = 0
                    while (true) {
                        val b = input.read()
                        if (b < 0) break
                        head.write(b)
                        last4 = (last4 shl 8) or b
                        if (last4 == 0x0D0A0D0A || head.size() > 16_000) break
                    }
                    val headers = head.toString("UTF-8")
                    val len = Regex("(?i)content-length:\\s*(\\d+)").find(headers)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    val body = ByteArray(len.coerceAtMost(20_000_000))
                    var read = 0
                    while (read < body.size) {
                        val n = input.read(body, read, body.size - read)
                        if (n < 0) break
                        read += n
                    }
                    val (code, answer) = runCatching { handle(String(body, 0, read, Charsets.UTF_8)) }
                        .getOrElse { 400 to (it.message ?: "Error") }
                    val out = JSONObject().put("ok", code == 200).put("msg", answer).toString().toByteArray()
                    c.getOutputStream().apply {
                        write(("HTTP/1.1 $code OK\r\nContent-Type: application/json\r\nContent-Length: ${out.size}\r\nConnection: close\r\n\r\n").toByteArray())
                        write(out)
                        flush()
                    }
                    if (code == 200) onReceived(answer)
                }
            }
            runCatching { s.close() }
        }

        private fun handle(text: String): Pair<Int, String> {
            val o = JSONObject(text)
            if (o.optString("pin") != pin) return 403 to "El código no coincide"
            val parts = mutableListOf<String>()
            o.optString("tmdb").takeIf { it.isNotBlank() }?.let { Tmdb.setKey(ctx, it); parts += "clave de TMDB" }
            o.optString("bot").takeIf { TgBot.isValid(it) }?.let { TgBot.setUrl(ctx, it); parts += "bot de Telegram" }
            o.optString("tema").takeIf { it.isNotBlank() }?.let { id -> if (Themes.all.any { it.id == id }) { Themes.set(ctx, id); parts += "tema" } }
            // Listas que sigue o publica el celular → el proyector las sigue y se actualiza solo
            val subs = o.optJSONArray("listas")
            if (subs != null) for (i in 0 until subs.length()) {
                val u = subs.getString(i)
                runCatching { Share.sync(ctx, u) }.onSuccess { (a, _) -> parts += "lista compartida ($a nuevos)" }
            }
            o.optJSONObject("catalogo")?.let { cat ->
                val n = Share.importFile(cat.toString())
                parts += "$n links"
            }
            Catalog.save()
            return 200 to if (parts.isEmpty()) "Nada nuevo" else "Recibido: " + parts.joinToString(", ")
        }
    }

    // ---------------- Lado del celular (envía) ----------------
    data class SendOptions(val catalog: Boolean, val lists: Boolean, val tmdb: Boolean, val theme: Boolean)

    fun send(ctx: Context, ip: String, pin: String, opt: SendOptions): String {
        val o = JSONObject().put("pin", pin.trim())
        if (opt.catalog) o.put("catalogo", Share.exportList(ctx))
        if (opt.lists) {
            val urls = Share.subscriptions(ctx).map { it.url }.toMutableList()
            Share.publicUrl(ctx)?.let { urls += it }   // tu propia lista publicada, para que el proyector la siga
            o.put("listas", org.json.JSONArray(urls.distinct()))
        }
        if (opt.tmdb && Tmdb.hasKey(ctx)) o.put("tmdb", Tmdb.key(ctx))
        if (opt.theme) o.put("tema", Themes.cur.id)
        TgBot.url(ctx)?.let { o.put("bot", it) }   // tu bot de Telegram también se pasa al proyector
        val host = ip.trim().removePrefix("http://").substringBefore('/').substringBefore(':')
        val c = URL("http://$host:$PORT/recibir").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 8_000
        c.readTimeout = 120_000
        c.setRequestProperty("Content-Type", "application/json")
        try {
            c.outputStream.use { it.write(o.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val msg = runCatching { JSONObject(txt).optString("msg") }.getOrDefault(txt)
            if (code !in 200..299) error(msg.ifBlank { "El proyector respondió $code" })
            return msg
        } catch (e: java.net.ConnectException) {
            error("No encontré el proyector en $host. Revisa que los dos estén en el mismo Wi-Fi y que la pantalla \"Recibir\" esté abierta.")
        } finally {
            c.disconnect()
        }
    }
}
