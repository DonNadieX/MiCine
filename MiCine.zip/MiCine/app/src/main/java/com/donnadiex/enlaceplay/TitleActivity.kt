package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class TitleActivity : BaseActivity() {

    private lateinit var t: Title
    private var tab = 0
    private lateinit var body: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private val openSeasons = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val found = intent.getStringExtra("id")?.let { Catalog.title(it) }
        if (found == null) { finish(); return }
        t = found
        Catalog.nextToWatch(t.id)?.let { openSeasons.add(it.season) }

        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), 0) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        tabsRow = hbox()
        top.addView(tabsRow, lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        body = vbox().apply { setPadding(0, 0, 0, dp(40)) }
        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!::t.isInitialized) return
        val fresh = Catalog.title(t.id)
        if (fresh == null) { finish(); return }
        t = fresh
        render()
    }

    private fun render() {
        val labels = listOf("Resumen", if (t.kind == Kind.SERIES) "Temporadas" else "Archivos")
        tabsRow.removeAllViews()
        labels.forEachIndexed { i, s ->
            tabsRow.addView(txt(s, 17f, if (i == tab) Col.RED else Col.MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(12), dp(8), dp(12))
                if (i == tab) background = underline(24)
                setOnClickListener { tab = i; render() }
            }, lp(0, WRAP, 1f))
        }
        body.removeAllViews()
        if (tab == 0) summary() else if (t.kind == Kind.SERIES) seasons() else movieFiles()
    }

    // ---------- Resumen ----------
    private fun summary() {
        val files = Catalog.filesOf(t.id)
        val next = Catalog.nextToWatch(t.id)

        val actions = listOf(
            R.drawable.ic_play to { next?.let { Nav.play(this, it.id) }; Unit },
            R.drawable.ic_info to { next?.let { Nav.info(this, it.id) }; Unit },
            (if (t.favorite) R.drawable.ic_heart else R.drawable.ic_heart_outline) to {
                t.favorite = !t.favorite
                Catalog.save()
                toast(if (t.favorite) "Agregado a Mi lista" else "Quitado de Mi lista")
                render()
            },
            R.drawable.ic_edit to { correctDialog() },
            R.drawable.ic_delete to { deleteDialog() }
        )
        val localCover = files.firstOrNull { it.coverPath != null }?.coverPath

        if (Themes.cur.detail == DetailStyle.POSTER) {
            // Póster gigante con columna de acciones a la derecha
            val h = (screenW * 1.35f).toInt()
            val frame = FrameLayout(this)
            val img = ImageView(this)
            frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            img.show(t.poster ?: t.backdrop, localCover)
            if (t.poster.isNullOrBlank()) {
                frame.addView(heading(t.name, 26f).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
            }
            frame.addView(View(this).apply { background = fadeBottom() }, FrameLayout.LayoutParams(MATCH, dp(120), Gravity.BOTTOM))
            val side = vbox().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(Color.parseColor("#B3000000"), if (Themes.cur.radius == 0f) 0f else dpf(24f))
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            actions.forEachIndexed { i, (icon, act) ->
                side.addView(iconButton(icon, 50, if (i == 2 && t.favorite) Col.RED else Color.WHITE) { act() })
            }
            frame.addView(side, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(10) })
            body.addView(frame, lp(MATCH, h))
        } else {
            // Banner panorámico + póster pequeño encimado + fila de acciones
            val bh = (screenW * 9f / 16f).toInt()
            val wrap = FrameLayout(this)
            val ban = ImageView(this)
            wrap.addView(ban, FrameLayout.LayoutParams(MATCH, bh))
            ban.show(t.fanart(), localCover)
            wrap.addView(View(this).apply { background = fadeBottom() }, FrameLayout.LayoutParams(MATCH, bh / 2, Gravity.TOP).apply { topMargin = bh / 2 })
            val pw = dp(108)
            val row = hbox().apply { gravity = Gravity.BOTTOM; setPadding(dp(16), 0, dp(16), 0) }
            val pf = FrameLayout(this).apply {
                background = rounded(Col.CARD2, r(), dp(2), Col.BG)
                clipToOutline = true
            }
            val pimg = ImageView(this)
            pf.addView(pimg, FrameLayout.LayoutParams(MATCH, MATCH))
            pimg.show(t.poster, localCover)
            row.addView(pf, LinearLayout.LayoutParams(pw, (pw * 1.5f).toInt()))
            val tcol = vbox().apply { setPadding(dp(14), 0, 0, dp(4)) }
            tcol.addView(heading(t.name, 22f, Col.TEXT, 3))
            tcol.addView(txt(t.metaLine(), 12f, Col.MUTED).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(tcol, lp(0, WRAP, 1f))
            wrap.addView(row, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = bh - (pw * 0.9f).toInt() })
            body.addView(wrap, lp(MATCH, bh + (pw * 0.6f).toInt() + dp(8)))
            val bar = hbox().apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(6), dp(8), dp(4)) }
            val labels = listOf("Ver", "Archivo", "Mi lista", "Corregir", "Quitar")
            actions.forEachIndexed { i, (icon, act) ->
                val it2 = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setOnClickListener { act() } }
                it2.addView(ImageView(this).apply {
                    setImageResource(icon)
                    setColorFilter(if (i == 0 || (i == 2 && t.favorite)) Col.RED else Col.TEXT)
                }, LinearLayout.LayoutParams(dp(26), dp(26)))
                it2.addView(txt(labels[i], 11f, Col.MUTED).apply { setPadding(0, dp(3), 0, 0) })
                bar.addView(it2, lp(0, WRAP, 1f))
            }
            body.addView(bar, lp())
        }

        val card = vbox().apply {
            background = rounded(Col.CARD, if (Themes.cur.detail == DetailStyle.POSTER) r(2.2f) else r())
            setPadding(dp(18), dp(18), dp(18), dp(20))
        }
        val head = hbox()
        if (Themes.cur.detail == DetailStyle.POSTER) head.addView(heading(t.name, 26f), lp(0, WRAP, 1f))
        else head.addView(View(this), lp(0, 1, 1f))
        if (t.rating > 0) {
            head.addView(txt(String.format(Locale.US, "★ %.1f", t.rating), 14f, if (Themes.cur.light) Col.RED else Color.parseColor("#F5C518"), true).apply {
                background = rounded(Color.TRANSPARENT, dpf(16f), dp(1), Col.LINE)
                setPadding(dp(12), dp(6), dp(12), dp(6))
            })
        }
        card.addView(head)

        val chips = mutableListOf(chip(if (t.kind == Kind.SERIES) "Serie" else "Película", true))
        if (t.year > 0) chips += chip(t.year.toString())
        if (t.kind == Kind.SERIES) {
            val s = Catalog.seasonsOf(t.id).size
            chips += chip("$s ${if (s == 1) "temporada" else "temporadas"}")
            chips += chip("${files.size} episodios" + if (t.totalEpisodes > files.size) " de ${t.totalEpisodes}" else "")
        } else {
            files.firstOrNull { it.durationMs > 0 }?.let { chips += chip(Fmt.duration(it.durationMs)) }
            files.map { it.quality }.filter { it.isNotBlank() }.distinct().forEach { chips += chip(it.uppercase()) }
        }
        if (t.status.isNotBlank()) chips += chip(t.status)
        card.addView(chipRow(chips), lp().apply { topMargin = dp(14) })
        if (t.genres.isNotEmpty()) card.addView(chipRow(t.genres.map { chip(it) }), lp().apply { topMargin = dp(8) })

        val playLabel = when {
            next == null -> "Sin archivos"
            next.positionMs > 5000 && !next.finished -> "Continuar" + if (next.episode > 0) " ${next.code}" else ""
            next.episode > 0 -> "Reproducir ${next.code}"
            else -> "Reproducir"
        }
        card.addView(pill(playLabel, true, R.drawable.ic_play) { next?.let { Nav.play(this, it.id) } }, lp().apply { topMargin = dp(18) })
        if (next != null && next.progress > 0f && !next.finished) {
            card.addView(progressBar(next.progress, 4).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8) })
        }
        if (next != null && next.episode > 0 && next.epName.isNotBlank()) {
            card.addView(txt("${next.code} · ${next.epName}", 13f, Col.MUTED).apply { setPadding(0, dp(8), 0, 0) })
        }

        val ov = t.overview.ifBlank {
"Sin sinopsis. Toca el lápiz para buscar el título correcto."
        }
        val ovView = txt(ov, 15f, Col.SOFT, false, 5).apply {
            setLineSpacing(0f, 1.25f)
            setPadding(0, dp(18), 0, 0)
            setOnClickListener { maxLines = if (maxLines == 5) 100 else 5 }
        }
        card.addView(ovView)
        body.addView(card, lp().apply { topMargin = if (Themes.cur.detail == DetailStyle.POSTER) -dp(18) else dp(6) })
    }

    // ---------- Temporadas ----------
    private fun seasons() {
        val files = Catalog.filesOf(t.id)
        val wrap = vbox().apply { setPadding(dp(8), dp(4), dp(8), 0) }
        files.groupBy { it.season }.toSortedMap().forEach { (season, eps) ->
            val open = season in openSeasons
            val header = hbox().apply {
                background = rounded(Col.CARD, r(1.6f))
                setPadding(dp(18), dp(18), dp(14), dp(18))
                setOnClickListener {
                    if (!openSeasons.add(season)) openSeasons.remove(season)
                    render()
                }
            }
            header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_folder); setColorFilter(Col.RED) },
                LinearLayout.LayoutParams(dp(28), dp(28)))
            header.addView(heading(String.format(Locale.US, "Temporada %02d", season), 19f).apply {
                setPadding(dp(18), 0, 0, 0)
            }, lp(0, WRAP, 1f))
            val seen = eps.count { it.finished }
            header.addView(txt(if (seen > 0) "$seen/${eps.size}" else "${eps.size} ep.", 13f, Col.MUTED).apply { setPadding(0, 0, dp(8), 0) })
            header.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_expand)
                setColorFilter(Col.RED)
                rotation = if (open) 180f else 0f
            }, LinearLayout.LayoutParams(dp(26), dp(26)))
            wrap.addView(header, lp().apply { topMargin = dp(10) })
            if (open) eps.forEach { wrap.addView(episodeRow(it)) }
        }
        body.addView(wrap)
    }

    private fun episodeRow(f: MediaFile): View {
        val row = hbox().apply {
            gravity = Gravity.TOP
            setPadding(dp(8), dp(12), dp(4), dp(4))
            setOnClickListener { Nav.play(this@TitleActivity, f.id) }
            setOnLongClickListener { Nav.info(this@TitleActivity, f.id); true }
        }
        val w = dp(132)
        val thumb = vbox().apply { background = rounded(Col.CARD2, r(0.8f)); clipToOutline = true }
        val tf = FrameLayout(this)
        val img = ImageView(this)
        tf.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(f.still ?: t.backdrop, f.coverPath)
        tf.addView(ImageView(this).apply { setImageResource(R.drawable.ic_play); alpha = 0.9f },
            FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        thumb.addView(tf, LinearLayout.LayoutParams(w, (w * 9f / 16f).toInt()))
        if (f.progress > 0f || f.finished) thumb.addView(progressBar(if (f.finished) 1f else f.progress))
        row.addView(thumb, LinearLayout.LayoutParams(w, WRAP))

        val col = vbox().apply { setPadding(dp(12), 0, 0, 0) }
        val name = f.epName.ifBlank { "Episodio ${f.episode}" }
        col.addView(txt("${f.episode}. $name", 15f, Col.TEXT, true, 2))
        val meta = listOfNotNull(
            if (f.durationMs > 0) Fmt.duration(f.durationMs) else null,
            f.quality.uppercase().ifBlank { null },
            if (f.finished) "Visto" else null
        ).joinToString(" · ")
        if (meta.isNotBlank()) col.addView(txt(meta, 12f, if (f.finished) Col.RED else Col.MUTED).apply { setPadding(0, dp(3), 0, 0) })
        if (f.epOverview.isNotBlank()) col.addView(txt(f.epOverview, 12f, Col.MUTED, false, 3).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(col, lp(0, WRAP, 1f))
        row.addView(iconButton(R.drawable.ic_info, 40, Col.MUTED) { Nav.info(this, f.id) })
        return row
    }

    // ---------- Película: archivos ----------
    private fun movieFiles() {
        val wrap = vbox().apply { setPadding(dp(14), dp(8), dp(14), 0) }
        wrap.addView(txt("Toca para reproducir · mantén presionado para ver la metadata", 12f, Col.MUTED).apply { setPadding(0, 0, 0, dp(8)) })
        Catalog.filesOf(t.id).forEach { f ->
            val row = hbox().apply {
                background = rounded(Col.CARD, r(1.5f))
                setPadding(dp(14), dp(14), dp(6), dp(14))
                setOnClickListener { Nav.play(this@TitleActivity, f.id) }
                setOnLongClickListener { Nav.info(this@TitleActivity, f.id); true }
            }
            row.addView(ImageView(this).apply { setImageResource(R.drawable.ic_play); setColorFilter(Col.RED) },
                LinearLayout.LayoutParams(dp(28), dp(28)))
            val col = vbox().apply { setPadding(dp(14), 0, 0, 0) }
            col.addView(txt(f.fileName.ifBlank { "Archivo" }, 14f, Col.TEXT, true, 2))
            val meta = listOfNotNull(
                f.quality.uppercase().ifBlank { null },
                if (f.durationMs > 0) Fmt.duration(f.durationMs) else null,
                if (f.positionMs > 5000 && !f.finished) "Visto hasta ${Fmt.duration(f.positionMs)}" else null,
                if (f.finished) "Visto" else null
            ).joinToString(" · ")
            if (meta.isNotBlank()) col.addView(txt(meta, 12f, Col.MUTED).apply { setPadding(0, dp(3), 0, 0) })
            row.addView(col, lp(0, WRAP, 1f))
            row.addView(iconButton(R.drawable.ic_info, 40, Col.MUTED) { Nav.info(this, f.id) })
            wrap.addView(row, lp().apply { bottomMargin = dp(10) })
        }
        body.addView(wrap)
    }

    // ---------- Corregir / eliminar ----------
    private fun correctDialog() {
        val box = vbox(18)
        val nameEdit = EditText(this).apply { setText(t.name); hint = "Nombre" }
        val yearEdit = EditText(this).apply {
            setText(if (t.year > 0) t.year.toString() else ""); hint = "Año (opcional)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rSeries = RadioButton(this).apply { text = "Serie"; id = View.generateViewId() }
        val rMovie = RadioButton(this).apply { text = "Película"; id = View.generateViewId() }
        group.addView(rSeries); group.addView(rMovie)
        group.check(if (t.kind == Kind.SERIES) rSeries.id else rMovie.id)
        box.addView(nameEdit); box.addView(yearEdit); box.addView(group)

        val b = AlertDialog.Builder(this, dialogTheme())
            .setTitle("Corregir datos")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Solo renombrar") { _, _ ->
                t.name = nameEdit.text.toString().trim().ifBlank { t.name }
                t.year = yearEdit.text.toString().toIntOrNull() ?: 0
                t.kind = if (group.checkedRadioButtonId == rSeries.id) Kind.SERIES else Kind.MOVIE
                Catalog.save(); render()
            }
        run {
            b.setPositiveButton("Buscar portada") { _, _ ->
                val kind = if (group.checkedRadioButtonId == rSeries.id) Kind.SERIES else Kind.MOVIE
                search(nameEdit.text.toString().trim(), kind, yearEdit.text.toString().toIntOrNull() ?: 0)
            }
        }
        b.show()
    }

    private fun search(q: String, kind: Kind, year: Int) {
        if (q.isBlank()) return
        toast("Buscando…")
        scope.launch {
            val res = withContext(Dispatchers.IO) { runCatching { Meta.search(this@TitleActivity, q, kind, year) }.getOrDefault(emptyList()) }
            if (res.isEmpty()) { toast("No encontré \"$q\". Prueba con el nombre en inglés."); return@launch }
            val names = res.map { r -> r.name + (if (r.year > 0) " (${r.year})" else "") + if (r.kind == Kind.SERIES) " · Serie" else " · Película" }
            AlertDialog.Builder(this@TitleActivity, dialogTheme())
                .setTitle("¿Cuál es?")
                .setItems(names.toTypedArray()) { _, i -> apply(res[i]) }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun apply(r: TmdbResult) {
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    Meta.apply(this@TitleActivity, t, r)
                }.isSuccess
            }
            val dup = Catalog.titles().firstOrNull { it.id != t.id && t.ext.isNotBlank() && it.ext == t.ext && it.kind == t.kind }
            if (dup != null) {
                Catalog.merge(t.id, dup.id)
                Catalog.save()
                toast("Unido con \"${dup.name}\" que ya estaba en tu catálogo")
                Nav.title(this@TitleActivity, dup.id)
                finish()
                return@launch
            }
            Catalog.save()
            toast(if (ok) "Datos actualizados" else "No se pudo conectar. Revisa tu internet.")
            render()
        }
    }

    private fun deleteDialog() {
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("¿Quitar \"${t.name}\" del catálogo?")
            .setMessage("Se quitan sus ${Catalog.filesOf(t.id).size} links de la app. Los archivos originales no se tocan.")
            .setPositiveButton("Quitar") { _, _ -> Catalog.deleteTitle(t.id); finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
