package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class Kind { SERIES, MOVIE }

data class InfoSection(val title: String, val rows: List<Pair<String, String>>)

/** Una serie o una película del catálogo. */
class Title(
    val id: String = UUID.randomUUID().toString(),
    var kind: Kind,
    var name: String,
    var year: Int = 0,
    var tmdbId: Int = 0,
    var ext: String = "",
    var anime: Boolean = false,
    var poster: String? = null,
    var backdrop: String? = null,
    var overview: String = "",
    var genres: List<String> = emptyList(),
    var rating: Double = 0.0,
    var status: String = "",
    var totalSeasons: Int = 0,
    var totalEpisodes: Int = 0,
    var favorite: Boolean = false,
    var addedAt: Long = System.currentTimeMillis(),
    var parsedKey: String = NameParser.key(name)
)

/** Un archivo (episodio o película) con su link. */
class MediaFile(
    val id: String = UUID.randomUUID().toString(),
    var titleId: String,
    var season: Int = 0,
    var episode: Int = 0,
    val url: String,
    var fileName: String = "",
    var quality: String = "",
    var epName: String = "",
    var epOverview: String = "",
    var still: String? = null,
    var durationMs: Long = 0,
    var positionMs: Long = 0,
    var watchedAt: Long = 0,
    var finished: Boolean = false,
    var coverPath: String? = null,
    var info: List<InfoSection> = emptyList(),
    var addedAt: Long = System.currentTimeMillis()
) {
    val code: String
        get() = if (episode > 0) "T$season:E$episode" else ""

    val progress: Float
        get() = if (durationMs > 0 && positionMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

/** Todo el catálogo vive en un archivo JSON dentro del teléfono. */
object Catalog {
    private val titles = mutableListOf<Title>()
    private val files = mutableListOf<MediaFile>()
    private var loaded = false
    private lateinit var file: File

    private val io = java.util.concurrent.Executors.newSingleThreadScheduledExecutor()
    private var pendingSave: java.util.concurrent.ScheduledFuture<*>? = null

    // Índices en memoria (como la base de datos de Kodi): búsquedas instantáneas aunque tengas miles de archivos.
    private var byTitle: Map<String, List<MediaFile>>? = null
    private var byUrl: Map<String, MediaFile>? = null
    private fun invalidate() { byTitle = null; byUrl = null }

    @Synchronized
    fun init(ctx: Context) {
        if (loaded) return
        file = File(ctx.filesDir, "catalog.json")
        // Si el archivo principal se dañó, prueba con los respaldos automáticos.
        val candidates = listOf(file, File(ctx.filesDir, "catalog.tmp")) +
            (1..3).map { File(ctx.filesDir, "catalog.bak$it") }
        for (f in candidates) {
            if (!f.exists() || f.length() == 0L) continue
            val ok = runCatching { fromJson(JSONObject(f.readText())) }.isSuccess
            if (ok) break
        }
        loaded = true
    }

    /** Guarda en segundo plano y agrupa cambios seguidos en una sola escritura. */
    fun save() {
        if (!loaded) return
        synchronized(this) {
            pendingSave?.cancel(false)
            pendingSave = io.schedule({ writeNow() }, 400, java.util.concurrent.TimeUnit.MILLISECONDS)
        }
    }

    /** Guardado inmediato (al salir del reproductor, al importar respaldos, etc.). */
    fun saveNow() {
        if (!loaded) return
        synchronized(this) { pendingSave?.cancel(false) }
        io.submit { writeNow() }.get()
    }

    @Synchronized private fun snapshot(): String = toJson().toString()

    private fun writeNow() {
        runCatching {
            val text = snapshot()
            val dir = file.parentFile ?: return
            rotateBackups(dir)
            val tmp = File(dir, "catalog.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(file)) { file.writeText(text); tmp.delete() }
        }.onFailure { CrashLog.note("Guardar catálogo", it) }
    }

    /** Hasta 3 copias de seguridad, una por día. */
    private fun rotateBackups(dir: File) {
        if (!file.exists() || file.length() == 0L) return
        val b1 = File(dir, "catalog.bak1")
        val dayMs = 24L * 60 * 60 * 1000
        if (b1.exists() && System.currentTimeMillis() - b1.lastModified() < dayMs) return
        File(dir, "catalog.bak3").delete()
        File(dir, "catalog.bak2").renameTo(File(dir, "catalog.bak3"))
        b1.renameTo(File(dir, "catalog.bak2"))
        file.copyTo(b1, overwrite = true)
    }

    fun backupInfo(ctx: Context): List<Pair<String, Long>> =
        (1..3).map { File(ctx.filesDir, "catalog.bak$it") }.filter { it.exists() }.map { it.name to it.lastModified() }

    fun restoreBackup(ctx: Context, name: String): Boolean = synchronized(this) {
        val f = File(ctx.filesDir, name)
        val ok = runCatching { fromJson(JSONObject(f.readText())) }.isSuccess
        if (ok) save()
        ok
    }

    @Synchronized
    fun stats(): Triple<Int, Int, Int> = Triple(titles.size, files.size, files.count { it.url.startsWith("content://") })

    // ---------- Consultas ----------
    @Synchronized fun titles(): List<Title> = titles.sortedByDescending { it.addedAt }
    @Synchronized fun title(id: String): Title? = titles.firstOrNull { it.id == id }
    @Synchronized fun file(id: String): MediaFile? = files.firstOrNull { it.id == id }
    @Synchronized fun fileByUrl(url: String): MediaFile? {
        val m = byUrl ?: files.associateBy { it.url }.also { byUrl = it }
        return m[url]
    }

    @Synchronized
    fun filesOf(titleId: String): List<MediaFile> {
        val m = byTitle ?: files.groupBy { it.titleId }
            .mapValues { (_, v) -> v.sortedWith(compareBy({ it.season }, { it.episode }, { it.quality })) }
            .also { byTitle = it }
        return m[titleId] ?: emptyList()
    }

    @Synchronized
    fun findTitle(kind: Kind, key: String): Title? =
        titles.firstOrNull { it.kind == kind && (it.parsedKey == key || NameParser.key(it.name) == key) }

    /** "Seguir viendo": lo último que dejaste a medias (uno por título). */
    @Synchronized
    fun continueWatching(): List<MediaFile> {
        val seen = mutableSetOf<String>()
        return files.filter { it.watchedAt > 0 && !it.finished && it.positionMs > 5_000 }
            .sortedByDescending { it.watchedAt }
            .filter { seen.add(it.titleId) }
    }

    /** El episodio que toca ver: el que dejaste a medias, o el siguiente al último terminado. */
    @Synchronized
    fun nextToWatch(titleId: String): MediaFile? {
        val list = filesOf(titleId)
        if (list.isEmpty()) return null
        val last = list.filter { it.watchedAt > 0 }.maxByOrNull { it.watchedAt } ?: return list.first()
        if (!last.finished) return last
        val idx = list.indexOf(last)
        return list.getOrNull(idx + 1) ?: list.first()
    }

    @Synchronized
    fun seasonsOf(titleId: String): List<Int> = filesOf(titleId).map { it.season }.distinct().sorted()

    // ---------- Cambios ----------
    @Synchronized
    fun addTitle(t: Title) {
        titles.add(t)
    }

    @Synchronized
    fun addFile(f: MediaFile) {
        files.add(f)
        invalidate()
    }

    @Synchronized
    fun deleteTitle(id: String) {
        files.filter { it.titleId == id }.forEach { f -> f.coverPath?.let { File(it).delete() } }
        files.removeAll { it.titleId == id }
        titles.removeAll { it.id == id }
        invalidate()
        save()
    }

    @Synchronized
    fun deleteFile(id: String) {
        val f = files.firstOrNull { it.id == id } ?: return
        f.coverPath?.let { File(it).delete() }
        files.remove(f)
        invalidate()
        if (files.none { it.titleId == f.titleId }) titles.removeAll { it.id == f.titleId }
        save()
    }

    /** Une dos títulos (por ejemplo si TMDB dice que son la misma serie). */
    @Synchronized
    fun merge(fromId: String, intoId: String) {
        if (fromId == intoId) return
        files.filter { it.titleId == fromId }.forEach { it.titleId = intoId }
        titles.removeAll { it.id == fromId }
        invalidate()
    }

    @Synchronized
    fun clearAll() {
        files.forEach { f -> f.coverPath?.let { File(it).delete() } }
        files.clear()
        titles.clear()
        invalidate()
        save()
    }

    @Synchronized
    fun genres(): List<String> =
        titles.flatMap { it.genres }.groupingBy { it }.eachCount()
            .filter { it.value >= 2 }.entries.sortedByDescending { it.value }.map { it.key }

    // ---------- Respaldo ----------
    @Synchronized
    fun exportJson(): String = toJson().toString(2)

    @Synchronized
    fun importJson(text: String): Int {
        val o = JSONObject(text)
        val before = files.size
        val tArr = o.optJSONArray("titles") ?: JSONArray()
        for (i in 0 until tArr.length()) {
            val t = titleFrom(tArr.getJSONObject(i))
            if (titles.none { it.id == t.id }) titles.add(t)
        }
        val fArr = o.optJSONArray("files") ?: JSONArray()
        for (i in 0 until fArr.length()) {
            val f = fileFrom(fArr.getJSONObject(i))
            if (files.none { it.id == f.id || it.url == f.url }) files.add(f)
        }
        invalidate()
        save()
        return files.size - before
    }

    // ---------- JSON ----------
    private fun toJson(): JSONObject {
        val tArr = JSONArray()
        titles.forEach { t ->
            tArr.put(
                JSONObject()
                    .put("id", t.id).put("kind", t.kind.name).put("name", t.name).put("year", t.year)
                    .put("tmdb", t.tmdbId).put("ext", t.ext).put("anime", t.anime).put("poster", t.poster ?: "").put("backdrop", t.backdrop ?: "")
                    .put("overview", t.overview).put("genres", JSONArray(t.genres)).put("rating", t.rating)
                    .put("status", t.status).put("seasons", t.totalSeasons).put("episodes", t.totalEpisodes)
                    .put("fav", t.favorite).put("added", t.addedAt).put("key", t.parsedKey)
            )
        }
        val fArr = JSONArray()
        files.forEach { f ->
            val info = JSONArray()
            f.info.forEach { s ->
                val rows = JSONArray()
                s.rows.forEach { (k, v) -> rows.put(JSONArray().put(k).put(v)) }
                info.put(JSONObject().put("t", s.title).put("r", rows))
            }
            fArr.put(
                JSONObject()
                    .put("id", f.id).put("title", f.titleId).put("s", f.season).put("e", f.episode)
                    .put("url", f.url).put("file", f.fileName).put("q", f.quality)
                    .put("epName", f.epName).put("epOv", f.epOverview).put("still", f.still ?: "")
                    .put("dur", f.durationMs).put("pos", f.positionMs).put("watched", f.watchedAt)
                    .put("done", f.finished).put("cover", f.coverPath ?: "").put("info", info)
                    .put("added", f.addedAt)
            )
        }
        return JSONObject().put("version", 1).put("titles", tArr).put("files", fArr)
    }

    private fun fromJson(o: JSONObject) {
        val tArr0 = o.optJSONArray("titles") ?: JSONArray()  // valida antes de borrar lo actual
        if (tArr0.length() == 0 && (o.optJSONArray("files")?.length() ?: 0) > 0) error("respaldo incompleto")
        titles.clear(); files.clear(); invalidate()
        val tArr = o.optJSONArray("titles") ?: JSONArray()
        for (i in 0 until tArr.length()) titles.add(titleFrom(tArr.getJSONObject(i)))
        val fArr = o.optJSONArray("files") ?: JSONArray()
        for (i in 0 until fArr.length()) files.add(fileFrom(fArr.getJSONObject(i)))
    }

    private fun titleFrom(o: JSONObject): Title {
        val g = o.optJSONArray("genres") ?: JSONArray()
        return Title(
            id = o.getString("id"),
            kind = runCatching { Kind.valueOf(o.optString("kind")) }.getOrDefault(Kind.MOVIE),
            name = o.optString("name"),
            year = o.optInt("year"),
            tmdbId = o.optInt("tmdb"),
            anime = o.optBoolean("anime"),
            ext = o.optString("ext").ifBlank { if (o.optInt("tmdb") > 0) "tmdb:" + o.optInt("tmdb") else "" },
            poster = o.optString("poster").ifBlank { null },
            backdrop = o.optString("backdrop").ifBlank { null },
            overview = o.optString("overview"),
            genres = (0 until g.length()).map { g.getString(it) },
            rating = o.optDouble("rating", 0.0),
            status = o.optString("status"),
            totalSeasons = o.optInt("seasons"),
            totalEpisodes = o.optInt("episodes"),
            favorite = o.optBoolean("fav"),
            addedAt = o.optLong("added", System.currentTimeMillis()),
            parsedKey = o.optString("key").ifBlank { NameParser.key(o.optString("name")) }
        )
    }

    private fun fileFrom(o: JSONObject): MediaFile {
        val info = mutableListOf<InfoSection>()
        val arr = o.optJSONArray("info") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val r = s.optJSONArray("r") ?: JSONArray()
            info.add(InfoSection(s.optString("t"), (0 until r.length()).map {
                val p = r.getJSONArray(it); p.optString(0) to p.optString(1)
            }))
        }
        return MediaFile(
            id = o.getString("id"),
            titleId = o.getString("title"),
            season = o.optInt("s"),
            episode = o.optInt("e"),
            url = o.getString("url"),
            fileName = o.optString("file"),
            quality = o.optString("q"),
            epName = o.optString("epName"),
            epOverview = o.optString("epOv"),
            still = o.optString("still").ifBlank { null },
            durationMs = o.optLong("dur"),
            positionMs = o.optLong("pos"),
            watchedAt = o.optLong("watched"),
            finished = o.optBoolean("done"),
            coverPath = o.optString("cover").ifBlank { null },
            info = info,
            addedAt = o.optLong("added", System.currentTimeMillis())
        )
    }
}
