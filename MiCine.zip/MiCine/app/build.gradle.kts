plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.donnadiex.enlaceplay"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.donnadiex.micine"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "5.0"
    }

    // Firma fija: así cada APK nuevo se instala ENCIMA del anterior sin borrar tu catálogo.
    signingConfigs {
        create("micine") {
            storeFile = file("micine.keystore")
            storePassword = "micine123"
            keyAlias = "micine"
            keyPassword = "micine123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("micine")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("micine")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("io.coil-kt:coil:2.7.0")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
}
