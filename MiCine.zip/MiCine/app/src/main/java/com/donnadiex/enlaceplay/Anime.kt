package com.donnadiex.enlaceplay

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Anime gratis y sin clave:
 *  - AniList (graphql.anilist.co): póster, banner, sinopsis, géneros, calificación, estado, nombres en romaji/inglés/japonés.
 *  - Jikan / MyAnimeList (api.jikan.moe): nombres de cada capítulo.
 */
object Anime {

    private const val FIELDS = """
        id idMal format status episodes averageScore genres synonyms
        title { romaji english native }
        startDate { year }
        coverImage { extraLarge large }
        bannerImage
        description(asHtml: false)
        streamingEpisodes { title thumbnail }
        countryOfOrigin
        studios(isMain: true) { nodes { name } }
    """

    private const val CHARS = """
        characters(sort: [ROLE, RELEVANCE], perPage: 15) {
          edges { role node { name { full } image { large } } voiceActors(language: JAPANESE) { name { full } } }
        }
    """

    private var lastJikan = 0L

    private fun post(query: String, vars: JSONObject): JSONObject? {
        val c = URL("https://graphql.anilist.co").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 12_000
        c.readTimeout = 15_000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", USER_AGENT)
        return try {
            c.outputStream.use { it.write(JSONObject().put("query", query).put("variables", vars).toString().toByteArray()) }
            when (c.responseCode) {
                in 200..299 -> JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                429 -> { Thread.sleep(4_000); null }
                else -> null
            }
        } finally {
            c.disconnect()
        }
    }

    /** Jikan permite ~3 consultas por segundo: espera lo necesario. */
    @Synchronized
    private fun jikan(path: String): JSONObject? {
        val wait = 450 - (System.currentTimeMillis() - lastJikan)
        if (wait > 0) Thread.sleep(wait)
        lastJikan = System.currentTimeMillis()
        val c = URL("https://api.jikan.moe/v4$path").openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", USER_AGENT)
        return try {
            if (c.responseCode in 200..299) JSONObject(c.inputStream.bufferedReader().use { it.readText() }) else null
        } finally {
            c.disconnect()
        }
    }

    private fun titleOf(m: JSONObject): String {
        val t = m.optJSONObject("title") ?: return ""
        return t.optString("english").takeIf { it.isNotBlank() && it != "null" }
            ?: t.optString("romaji").takeIf { it.isNotBlank() && it != "null" }
            ?: t.optString("native")
    }

    /** Todos los nombres conocidos (para reconocer "Shingeki no Kyojin" = "Attack on Titan"). */
    private fun allNames(m: JSONObject): List<String> {
        val t = m.optJSONObject("title")
        val out = mutableListOf<String>()
        listOf("english", "romaji", "native").forEach { k -> t?.optString(k)?.takeIf { it.isNotBlank() && it != "null" }?.let { out += it } }
        m.optJSONArray("synonyms")?.let { a -> for (i in 0 until a.length()) out += a.getString(i) }
        return out
    }

    private fun toResult(m: JSONObject): TmdbResult = TmdbResult(
        id = m.optInt("id"),
        kind = if (m.optString("format") == "MOVIE") Kind.MOVIE else Kind.SERIES,
        name = titleOf(m),
        year = m.optJSONObject("startDate")?.optInt("year") ?: 0,
        poster = m.optJSONObject("coverImage")?.optString("extraLarge")?.takeIf { it.startsWith("http") },
        overview = FreeMeta.stripHtml(m.optString("description").takeIf { it != "null" } ?: ""),
        src = "anilist"
    )

    fun search(query: String, kind: Kind? = null): List<TmdbResult> {
        val q = "query (\$s: String) { Page(perPage: 10) { media(search: \$s, type: ANIME, sort: SEARCH_MATCH) { $FIELDS } } }"
        val arr = post(q, JSONObject().put("s", query))
            ?.optJSONObject("data")?.optJSONObject("Page")?.optJSONArray("media") ?: return emptyList()
        val list = (0 until arr.length()).map { toResult(arr.getJSONObject(it)) }
        return if (kind == null) list else list.sortedByDescending { it.kind == kind }
    }

    /** Busca y devuelve el mejor resultado comparando con todos sus nombres (romaji, inglés, sinónimos). */
    fun best(name: String, year: Int, kind: Kind?): TmdbResult? {
        val q = "query (\$s: String) { Page(perPage: 10) { media(search: \$s, type: ANIME, sort: SEARCH_MATCH) { $FIELDS } } }"
        val arr = post(q, JSONObject().put("s", name))
            ?.optJSONObject("data")?.optJSONObject("Page")?.optJSONArray("media") ?: return null
        if (arr.length() == 0) return null
        val key = NameParser.key(name)
        val all = (0 until arr.length()).map { arr.getJSONObject(it) }
        val exact = all.filter { m -> allNames(m).any { NameParser.key(it) == key } }
        val pick = exact.firstOrNull { year == 0 || it.optJSONObject("startDate")?.optInt("year") == year }
            ?: exact.firstOrNull { kind == null || (it.optString("format") == "MOVIE") == (kind == Kind.MOVIE) }
            ?: exact.firstOrNull()
            ?: all.first()   // AniList ya ordena por parecido
        return toResult(pick)
    }

    fun apply(t: Title, id: Int) {
        val q = "query (\$id: Int) { Media(id: \$id, type: ANIME) { $FIELDS $CHARS } }"
        val m = post(q, JSONObject().put("id", id))?.optJSONObject("data")?.optJSONObject("Media")
            ?: error("AniList no respondió")
        t.anime = true
        t.tmdbId = 0
        t.ext = "anilist:$id"
        t.kind = if (m.optString("format") == "MOVIE") Kind.MOVIE else Kind.SERIES
        t.name = titleOf(m).ifBlank { t.name }
        t.year = m.optJSONObject("startDate")?.optInt("year")?.takeIf { it > 0 } ?: t.year
        t.overview = FreeMeta.stripHtml(m.optString("description").takeIf { it != "null" } ?: "")
        m.optJSONObject("coverImage")?.let { c ->
            (c.optString("extraLarge").takeIf { it.startsWith("http") } ?: c.optString("large").takeIf { it.startsWith("http") })
                ?.let { t.poster = it }
        }
        m.optString("bannerImage").takeIf { it.startsWith("http") }?.let { t.backdrop = it }
        val g = m.optJSONArray("genres") ?: JSONArray()
        t.genres = listOf("Anime") + (0 until g.length()).map { GENRES[g.getString(it)] ?: g.getString(it) }
        t.rating = m.optInt("averageScore").takeIf { it > 0 }?.let { it / 10.0 } ?: 0.0
        t.status = when (m.optString("status")) {
            "FINISHED" -> "Finalizado"
            "RELEASING" -> "En emisión"
            "NOT_YET_RELEASED" -> "Próximamente"
            "CANCELLED" -> "Cancelado"
            "HIATUS" -> "En pausa"
            else -> ""
        }
        t.totalEpisodes = m.optInt("episodes")
        t.totalSeasons = 1
        t.origin = m.optString("countryOfOrigin").takeIf { it.length == 2 } ?: "JP"
        m.optJSONObject("studios")?.optJSONArray("nodes")?.optJSONObject(0)?.optString("name")?.let { t.network = it }
        t.seasons = mapOf(1 to SeasonInfo(t.poster, t.overview, t.year, ""))
        m.optJSONObject("characters")?.optJSONArray("edges")?.let { a ->
            t.cast = (0 until a.length()).map { a.getJSONObject(it) }.map { e ->
                val node = e.optJSONObject("node")
                val va = e.optJSONArray("voiceActors")?.optJSONObject(0)?.optJSONObject("name")?.optString("full")
                CastMember(node?.optJSONObject("name")?.optString("full") ?: "",
                    listOfNotNull(if (e.optString("role") == "MAIN") "Principal" else null, va?.let { "Voz: $it" }).joinToString(" · "),
                    node?.optJSONObject("image")?.optString("large")?.takeIf { it.startsWith("http") })
            }
        }

        // Capítulos: imágenes de AniList + nombres de MyAnimeList
        val files = Catalog.filesOf(t.id)
        if (t.kind != Kind.SERIES || files.isEmpty()) return
        val thumbs = mutableMapOf<Int, Pair<String, String?>>()
        m.optJSONArray("streamingEpisodes")?.let { a ->
            for (i in 0 until a.length()) {
                val e = a.getJSONObject(i)
                val title = e.optString("title")
                val n = Regex("(?i)episode\\s*(\\d+)").find(title)?.groupValues?.get(1)?.toIntOrNull() ?: continue
                val clean = title.replace(Regex("(?i)^episode\\s*\\d+\\s*[-:–]\\s*"), "")
                thumbs[n] = clean to e.optString("thumbnail").takeIf { it.startsWith("http") }
            }
        }
        val names = mutableMapOf<Int, String>()
        val mal = m.optInt("idMal")
        if (mal > 0) {
            var page = 1
            while (page <= 15) {
                val o = jikan("/anime/$mal/episodes?page=$page") ?: break
                val d = o.optJSONArray("data") ?: break
                for (i in 0 until d.length()) {
                    val e = d.getJSONObject(i)
                    e.optString("title").takeIf { it.isNotBlank() && it != "null" }?.let { names[e.optInt("mal_id")] = it }
                }
                if (o.optJSONObject("pagination")?.optBoolean("has_next_page") != true) break
                page++
            }
        }
        // Una sola temporada en tus archivos: los capítulos se emparejan por número.
        val oneSeason = files.map { it.season }.distinct().size <= 1
        files.forEach { f ->
            if (!oneSeason && f.season > 1) return@forEach
            (names[f.episode] ?: thumbs[f.episode]?.first)?.takeIf { it.isNotBlank() }?.let { f.epName = it }
            thumbs[f.episode]?.second?.let { f.still = it }
        }
    }

    private val GENRES = mapOf(
        "Action" to "Acción", "Adventure" to "Aventura", "Comedy" to "Comedia", "Drama" to "Drama",
        "Ecchi" to "Ecchi", "Fantasy" to "Fantasía", "Horror" to "Terror", "Mahou Shoujo" to "Chicas mágicas",
        "Mecha" to "Mecha", "Music" to "Música", "Mystery" to "Misterio", "Psychological" to "Psicológico",
        "Romance" to "Romance", "Sci-Fi" to "Ciencia ficción", "Slice of Life" to "Vida cotidiana",
        "Sports" to "Deportes", "Supernatural" to "Sobrenatural", "Thriller" to "Suspenso"
    )
}
