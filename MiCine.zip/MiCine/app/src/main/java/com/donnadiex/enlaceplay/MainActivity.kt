package com.donnadiex.enlaceplay

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Nav {
    fun title(c: Context, id: String) =
        c.startActivity(Intent(c, TitleActivity::class.java).putExtra("id", id))

    fun play(c: Context, fileId: String) =
        c.startActivity(Intent(c, PlayerActivity::class.java).putExtra("file", fileId))

    fun info(c: Context, fileId: String) =
        c.startActivity(Intent(c, FileInfoActivity::class.java).putExtra("file", fileId))
}

/** Adaptador sencillo: Android solo crea las tarjetas que se ven en pantalla. */
class ViewAdapter(private val items: List<Title>, private val make: (Title, Int) -> View) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = make(items[position], position)
}

class MainActivity : BaseActivity() {

    private enum class Sec(val label: String, val icon: Int, val inNav: Boolean = true) {
        HOME("Inicio", R.drawable.ic_home),
        SERIES("Series", R.drawable.ic_tv),
        MOVIES("Películas", R.drawable.ic_movie),
        MYLIST("Mi lista", R.drawable.ic_heart),
        ALL("Todo", R.drawable.ic_list, false)
    }

    private val th get() = Themes.cur
    /** En proyector siempre se usa el menú lateral (es lo más cómodo con el control). */
    private val nav get() = if (Tv.on) NavStyle.SIDE_RAIL else th.nav
    private var sec = Sec.HOME
    private var query: String? = null
    private lateinit var body: FrameLayout
    private lateinit var header: LinearLayout
    private val navViews = mutableMapOf<Sec, View>()
    private var builtNav: NavStyle? = null
    private var railW = 0
    private val homeCap get() = if (Tv.lite) 12 else 20

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildSkeleton()
        handleShare(intent)
        // Al abrir (en segundo plano, como Kodi):
        // 1) archivos nuevos en tus carpetas, 2) listas que sigues, 3) limpieza, 4) publicar tu lista, 5) actualizaciones.
        if (savedInstanceState == null) scope.launch {
            // Primero se muestra la pantalla; las tareas pesadas esperan y van una por una.
            delay(if (Tv.lite) 4000 else 1500)
            // Si una búsqueda de portadas quedó a medias, se retoma.
            MetaWork.resume(applicationContext)
            // Lo nuevo de tu canal de Telegram (Mi Cine Bot)
            if (TgBot.syncIfDue(applicationContext) > 0) render()
            // Proyector: si ya conoces un celular, se reconecta y copia lo nuevo
            if (RemoteLib.hasDevice(applicationContext)) {
                val h = RemoteLib.discover(applicationContext)
                if (h != null && h.id == RemoteLib.savedId(applicationContext)) {
                    RemoteLib.connect(applicationContext, h)
                    val r = runCatching { RemoteLib.sync(applicationContext, h) }.getOrNull()
                    if (r != null && r.files + r.removed > 0) render()
                }
                RemoteLib.ensureLoop(applicationContext)
            }
            var changed = false
            if (Local.autoScanEnabled(this@MainActivity) && Local.folders(this@MainActivity).isNotEmpty()) {
                changed = runCatching { Local.scanAll(applicationContext) { _, _, _ -> } }.getOrDefault(0) > 0
            }
            if (MediaScan.autoEnabled(this@MainActivity)) {
                if (runCatching { MediaScan.scan(applicationContext) { _, _, _ -> } }.getOrDefault(0) > 0) changed = true
            }
            val (a, r) = withContext(Dispatchers.IO) { runCatching { Share.syncAll(applicationContext) }.getOrDefault(0 to 0) }
            if (a + r > 0) {
                changed = true
                android.widget.Toast.makeText(this@MainActivity,
                    "Lista compartida: ${a} nuevos" + if (r > 0) ", $r quitados" else "", android.widget.Toast.LENGTH_SHORT).show()
            }
            val rep = runCatching { Maintenance.onAppOpen(applicationContext) }.getOrNull()
            if (rep != null && rep.total > 0) changed = true
            if (changed) render()
            withContext(Dispatchers.IO) { runCatching { Share.publishIfChanged(applicationContext) } }
            runCatching { Updater.checkOnOpen(this@MainActivity) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            i.action = null
            startActivity(Intent(this, AddActivity::class.java).putExtra("text", text))
        }
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_MENU || keyCode == android.view.KeyEvent.KEYCODE_SETTINGS) {
            startActivity(Intent(this, SettingsActivity::class.java)); return true
        }
        if (keyCode == android.view.KeyEvent.KEYCODE_SEARCH) { query = ""; buildHeader(); render(); return true }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        if (recreating) return
        render()
    }

    // ======================= Estructura según el tema =======================
    private fun buildSkeleton() {
        header = hbox()
        body = FrameLayout(this)
        navViews.clear()
        builtNav = nav
        val root: ViewGroup = when (nav) {
            NavStyle.SIDE_RAIL -> {
                railW = dp(78)
                val h = hbox().apply { gravity = Gravity.TOP; setBackgroundColor(Col.BG) }
                h.addView(buildRail(), LinearLayout.LayoutParams(railW, MATCH))
                val col = vbox()
                col.addView(header, lp())
                col.addView(body, lp(MATCH, 0, 1f))
                h.addView(col, lp(0, MATCH, 1f))
                h
            }
            NavStyle.BOTTOM_BAR -> {
                val v = vbox().apply { setBackgroundColor(Col.BG) }
                v.addView(header, lp())
                v.addView(body, lp(MATCH, 0, 1f))
                v.addView(View(this).apply { setBackgroundColor(Col.LINE) }, lp(MATCH, 1))
                v.addView(buildBottomBar(), lp())
                v
            }
            NavStyle.PILLS, NavStyle.TOP_TABS -> {
                val v = vbox().apply { setBackgroundColor(Col.BG) }
                v.addView(header, lp())
                v.addView(if (nav == NavStyle.PILLS) buildPills() else buildTabs(), lp())
                v.addView(body, lp(MATCH, 0, 1f))
                v
            }
        }
        setContentView(root)
        buildHeader()
    }

    private fun buildHeader() {
        header.removeAllViews()
        header.setPadding(dp(14), dp(8), dp(6), dp(4))
        val q = query
        if (q == null) {
            when (nav) {
                NavStyle.SIDE_RAIL ->
                    header.addView(heading(sec.label, 24f, Col.TEXT), lp(0, WRAP, 1f))
                else -> {
                    val logo = when (th.home) {
                        HomeStyle.MAGAZINE -> txt(th.logo, 30f, Col.TEXT, true).apply { setTypeface(th.titleFont, Typeface.BOLD_ITALIC) }
                        HomeStyle.LIST -> txt(th.logo, 24f, Col.RED, true).apply { typeface = Typeface.MONOSPACE }
                        else -> heading(th.logo, 26f, Col.RED)
                    }
                    header.addView(logo, lp(0, WRAP, 1f))
                }
            }
            header.addView(iconButton(R.drawable.ic_search) { query = ""; buildHeader(); render() })
        } else {
            val edit = EditText(this).apply {
                hint = "Buscar título o género"
                setHintTextColor(Col.DIM)
                setTextColor(Col.TEXT)
                typeface = th.font
                textSize = 17f
                setSingleLine()
                background = rounded(Col.CARD2, r().coerceAtLeast(dpf(4f)))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setText(q)
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; render() }
                })
            }
            header.addView(edit, lp(0, WRAP, 1f))
            header.addView(iconButton(R.drawable.ic_close, tint = Col.RED) {
                query = null
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(edit.windowToken, 0)
                buildHeader(); render()
            })
            edit.requestFocus()
            edit.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(edit, 0) }
        }
        header.addView(iconButton(R.drawable.ic_add) { startActivity(Intent(this, AddActivity::class.java)) })
        if (nav != NavStyle.SIDE_RAIL) {
            header.addView(iconButton(R.drawable.ic_settings) { startActivity(Intent(this, SettingsActivity::class.java)) })
        }
    }

    private fun go(s: Sec) {
        sec = s
        query = null
        buildHeader()
        render()
    }

    /** Pestañas de texto con rayita (Cine, Papel). */
    private fun buildTabs(): View {
        val row = hbox().apply { setPadding(dp(8), 0, dp(8), 0) }
        Sec.values().filter { it.inNav }.forEach { s ->
            val tv = heading(s.label, 15f, Col.MUTED).apply {
                setPadding(dp(10), dp(10), dp(10), dp(12))
                setOnClickListener { go(s) }
            }
            navViews[s] = tv
            row.addView(tv)
        }
        return row
    }

    /** Píldoras tipo interruptor (Ficha técnica). */
    private fun buildPills(): View {
        val sv = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = hbox().apply { setPadding(dp(12), dp(4), dp(12), dp(10)) }
        Sec.values().filter { it.inNav }.forEach { s ->
            val tv = txt(s.label, 14f, Col.TEXT, true).apply {
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { go(s) }
            }
            navViews[s] = tv
            row.addView(tv, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        sv.addView(row)
        return sv
    }

    /** Menú lateral con iconos (Estuario). */
    private fun buildRail(): View {
        val rail = vbox().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Col.CARD)
            setPadding(0, dp(14), 0, dp(10))
        }
        rail.addView(txt("MC", 18f, Col.ON_ACCENT, true).apply {
            gravity = Gravity.CENTER
            background = rounded(Col.RED, dpf(6f))
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { bottomMargin = dp(18) })
        Sec.values().filter { it.inNav }.forEach { s ->
            val item = vbox().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { go(s) }
            }
            item.addView(ImageView(this).apply { setImageResource(s.icon) }, LinearLayout.LayoutParams(dp(26), dp(26)))
            item.addView(txt(s.label, 10f, Col.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
            navViews[s] = item
            rail.addView(item, lp())
        }
        rail.addView(View(this), lp(MATCH, 0, 1f))
        rail.addView(iconButton(R.drawable.ic_settings, 48, Col.MUTED) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        return rail
    }

    /** Barra inferior con iconos (Muro). */
    private fun buildBottomBar(): View {
        val bar = hbox().apply { setBackgroundColor(Col.CARD); setPadding(0, dp(6), 0, dp(6)) }
        Sec.values().filter { it.inNav }.forEach { s ->
            val item = vbox().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setOnClickListener { go(s) }
            }
            item.addView(ImageView(this).apply { setImageResource(s.icon) }, LinearLayout.LayoutParams(dp(24), dp(24)))
            item.addView(heading(s.label, 10f, Col.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            navViews[s] = item
            bar.addView(item, lp(0, WRAP, 1f))
        }
        return bar
    }

    private fun highlightNav() {
        navViews.forEach { (s, v) ->
            val on = s == sec && query == null
            // Se usa el estilo con el que se construyó el menú (por si cambiaste de tema)
            if (v is TextView) {
                v.setTextColor(if (on) (if (builtNav == NavStyle.PILLS) Col.ON_ACCENT else Col.RED) else Col.MUTED)
                v.background = when {
                    builtNav == NavStyle.PILLS -> if (on) rounded(Col.RED, dpf(20f)) else rounded(Color.TRANSPARENT, dpf(20f), dp(1), Col.LINE)
                    on -> underline()
                    else -> null
                }
                return@forEach
            }
            if (v !is LinearLayout) return@forEach
            when (builtNav) {
                else -> {
                    val g = v
                    (g.getChildAt(0) as? ImageView)?.setColorFilter(if (on) Col.RED else Col.MUTED)
                    (g.getChildAt(1) as? TextView)?.setTextColor(if (on) Col.TEXT else Col.MUTED)
                    g.background = if (on && builtNav == NavStyle.SIDE_RAIL)
                        LayerDrawableLeft() else null
                }
            }
        }
    }

    @Suppress("FunctionName")
    private fun LayerDrawableLeft() = android.graphics.drawable.LayerDrawable(
        arrayOf(android.graphics.drawable.ColorDrawable(Col.CARD2), android.graphics.drawable.ColorDrawable(Col.RED))
    ).apply {
        setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
        setLayerWidth(1, dp(3))
    }

    // ======================= Contenido =======================
    private fun render() {
        highlightNav()
        body.removeAllViews()
        val all = Catalog.titles()
        val q = query
        when {
            q != null -> {
                val k = NameParser.key(q)
                val res = if (k.isBlank()) all else all.filter { t ->
                    NameParser.key(t.name).contains(k) || t.genres.any { NameParser.key(it).contains(k) }
                }
                if (res.isEmpty() && k.isNotBlank()) showEmpty("Sin resultados para \"$q\"", false) else collection(res)
            }
            all.isEmpty() -> showEmpty("Tu catálogo está vacío", true)
            sec == Sec.SERIES -> collection(all.filter { it.kind == Kind.SERIES }.sortedBy { it.name.lowercase() })
            sec == Sec.MOVIES -> collection(all.filter { it.kind == Kind.MOVIE }.sortedBy { it.name.lowercase() })
            sec == Sec.ALL -> collection(all)
            sec == Sec.MYLIST -> {
                val fav = all.filter { it.favorite }
                if (fav.isEmpty()) showEmpty("Toca el corazón en cualquier título para guardarlo aquí", false) else collection(fav)
            }
            else -> {
                val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
                val content = vbox().apply { setPadding(0, 0, 0, dp(32)) }
                if (Tv.on) {
                    // Proyector: imagen panorámica arriba y filas que se recorren con las flechas
                    if (th.home == HomeStyle.WALL) homeWall(content, all)
                    else homeFanart(content, all, posterRows = th.home != HomeStyle.FANART)
                } else when (th.home) {
                    HomeStyle.ROWS -> homeRows(content, all)
                    HomeStyle.FANART -> homeFanart(content, all)
                    HomeStyle.WALL -> homeWall(content, all)
                    HomeStyle.LIST -> homeList(content, all)
                    HomeStyle.MAGAZINE -> homeMagazine(content, all)
                }
                scroll.addView(content)
                body.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
            }
        }
    }

    private val contentW get() = screenW - railW

    /** Lista completa con reciclado de vistas (no se alenta aunque tengas cientos de títulos). */
    private fun collection(list: List<Title>) {
        if (list.isEmpty()) { showEmpty("Nada por aquí todavía.", false); return }
        val view: AbsListView = when (th.grid) {
            GridStyle.POSTERS -> {
                val pad = dp(14); val gap = dp(8)
                val cols = if (Tv.on) ((contentW - pad * 2) / dp(138)).coerceAtLeast(4) else 3
                val colW = (contentW - pad * 2 - gap * (cols - 1)) / cols
                GridView(this).apply {
                    numColumns = cols; horizontalSpacing = gap; verticalSpacing = dp(14)
                    setPadding(pad, dp(10), pad, dp(24)); clipToPadding = false
                    adapter = ViewAdapter(list) { t, _ -> posterCard(t, colW) { Nav.title(this@MainActivity, t.id) } }
                }
            }
            GridStyle.WALL -> {
                val cols = if (Tv.on) 6 else 3
                val colW = contentW / cols
                GridView(this).apply {
                    numColumns = cols; horizontalSpacing = 0; verticalSpacing = 0
                    adapter = ViewAdapter(list) { t, _ -> posterCard(t, colW, wall = true) { Nav.title(this@MainActivity, t.id) } }
                }
            }
            GridStyle.LANDSCAPE -> {
                val pad = dp(12); val gap = dp(10)
                val cols = if (Tv.on) 3 else 2
                val colW = (contentW - pad * 2 - gap * (cols - 1)) / cols
                GridView(this).apply {
                    numColumns = cols; horizontalSpacing = gap; verticalSpacing = dp(14)
                    setPadding(pad, dp(6), pad, dp(24)); clipToPadding = false
                    adapter = ViewAdapter(list) { t, _ -> landscapeCard(t, colW) { Nav.title(this@MainActivity, t.id) } }
                }
            }
            GridStyle.ROWS -> ListView(this).apply {
                divider = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT); dividerHeight = dp(10)
                setPadding(dp(12), dp(4), dp(12), dp(24)); clipToPadding = false
                adapter = ViewAdapter(list) { t, _ -> mediaRow(t) { Nav.title(this@MainActivity, t.id) } }
            }
            GridStyle.INDEX -> ListView(this).apply {
                divider = null
                setPadding(dp(20), 0, dp(20), dp(24)); clipToPadding = false
                adapter = ViewAdapter(list) { t, i -> indexRow(t, i + 1) { Nav.title(this@MainActivity, t.id) } }
            }
        }
        view.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        view.isVerticalScrollBarEnabled = false
        // Con el control: OK sobre el elemento elegido abre el título
        view.onItemClickListener = android.widget.AdapterView.OnItemClickListener { _, _, pos, _ ->
            list.getOrNull(pos)?.let { Nav.title(this, it.id) }
        }
        if (Tv.on) view.setPadding(view.paddingLeft + dp(6), view.paddingTop + dp(6), view.paddingRight + dp(6), view.paddingBottom)
        body.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun seeAll(content: LinearLayout, total: Int) {
        if (total <= homeCap) return
        content.addView(pill("Ver los $total títulos", false) { go(Sec.ALL) }, lp().apply {
            setMargins(dp(14), dp(16), dp(14), 0)
        })
    }

    // ---------- Cine: portada gigante + filas ----------
    private fun homeRows(content: LinearLayout, all: List<Title>) {
        val featured = all.firstOrNull { !it.poster.isNullOrBlank() } ?: all.first()
        content.addView(heroPoster(featured))
        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(sectionTitle("Seguir viendo"))
            content.addView(hRow(cont.mapNotNull { f -> Catalog.title(f.titleId)?.let { continueCard(f, it) } }))
        }
        val w = dp(110)
        fun row(title: String, list: List<Title>) {
            if (list.isEmpty()) return
            content.addView(sectionTitle(title))
            content.addView(hRow(list.take(homeCap).map { t -> posterCard(t, w) { Nav.title(this, t.id) } }))
        }
        row("Mi lista", all.filter { it.favorite })
        row("Agregados recientemente", all)
        row("Series", all.filter { it.kind == Kind.SERIES })
        row("Películas", all.filter { it.kind == Kind.MOVIE })
        Catalog.genres().take(if (Tv.lite) 0 else 8).forEach { g -> row(g, all.filter { g in it.genres }) }
    }

    private fun heroPoster(t: Title): View {
        val h = (screenW * 1.3f).toInt()
        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(t.poster ?: t.backdrop, t.localCover())
        frame.addView(View(this).apply { background = fadeBottom() }, FrameLayout.LayoutParams(MATCH, h / 2, Gravity.BOTTOM))
        val info = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), 0, dp(16), dp(18)) }
        info.addView(heading(t.name, 30f, Col.TEXT, 2).apply { gravity = Gravity.CENTER })
        val sub = (listOf(if (t.kind == Kind.SERIES) "Serie" else "Película") + t.genres.take(3)).joinToString("  •  ")
        info.addView(txt(sub, 13f, Col.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(14)) })
        info.addView(playInfoButtons(t), lp())
        frame.addView(info, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        frame.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        frame.setOnClickListener { Nav.title(this, t.id) }
        return frame
    }

    private fun playInfoButtons(t: Title): View {
        val btns = hbox().apply { gravity = Gravity.CENTER }
        btns.addView(pill("Reproducir", true, R.drawable.ic_play) {
            Catalog.nextToWatch(t.id)?.let { Nav.play(this, it.id) }
        }, lp(0, WRAP, 1f))
        btns.addView(pill("Más info", false, R.drawable.ic_info) { Nav.title(this, t.id) },
            lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        return btns
    }

    private fun continueCard(f: MediaFile, t: Title): View {
        val w = dp(180)
        val box = vbox().apply { background = rounded(Col.CARD, r()); clipToOutline = true }
        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(f.still ?: t.backdrop ?: t.poster, f.coverPath)
        frame.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            background = rounded(Color.parseColor("#99000000"), dpf(22f), dp(2), Color.WHITE)
            setPadding(dp(9), dp(9), dp(9), dp(9))
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        box.addView(frame, LinearLayout.LayoutParams(w, (w * 9f / 16f).toInt()))
        box.addView(progressBar(f.progress))
        val label = if (f.episode > 0) "${t.name} · ${f.code}" else t.name
        box.addView(txt(label, 12f, Col.TEXT, true, 1).apply { setPadding(dp(8), dp(6), dp(8), dp(1)) }, lp(w, WRAP))
        box.addView(txt(remaining(f), 11f, Col.MUTED, false, 1).apply { setPadding(dp(8), 0, dp(8), dp(8)) }, lp(w, WRAP))
        box.layoutParams = LinearLayout.LayoutParams(w, WRAP)
        box.setOnClickListener { Nav.play(this, f.id) }
        box.setOnLongClickListener { Nav.title(this, t.id); true }
        return box
    }

    private fun remaining(f: MediaFile) = "Quedan ${Fmt.duration((f.durationMs - f.positionMs).coerceAtLeast(0))}"

    // ---------- Estuario: fanart panorámico + filas horizontales ----------
    private fun homeFanart(content: LinearLayout, all: List<Title>, posterRows: Boolean = false) {
        val featured = all.firstOrNull { it.backdrop != null } ?: all.firstOrNull { it.fanart() != null } ?: all.first()
        val w = contentW
        val h = minOf((w * 10f / 16f).toInt(), (screenH * 0.62f).toInt())
        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(featured.fanart(), featured.localCover())
        frame.addView(View(this).apply { background = fadeLeft() }, FrameLayout.LayoutParams((w * 0.85f).toInt(), MATCH))
        frame.addView(View(this).apply { background = fadeBottom() }, FrameLayout.LayoutParams(MATCH, h / 3, Gravity.BOTTOM))
        val info = vbox().apply { setPadding(dp(16), 0, dp(16), dp(14)) }
        info.addView(txt("DESTACADO", 11f, Col.RED, true).apply { letterSpacing = 0.15f })
        info.addView(heading(featured.name, 24f, Col.TEXT, 2).apply { setPadding(0, dp(2), 0, dp(2)) })
        info.addView(txt(featured.metaLine(), 12f, Col.MUTED))
        if (featured.overview.isNotBlank()) info.addView(txt(featured.overview, 12f, Col.SOFT, false, 2).apply { setPadding(0, dp(6), dp(40), dp(10)) })
        val b = hbox()
        b.addView(pill("Reproducir", true, R.drawable.ic_play) { Catalog.nextToWatch(featured.id)?.let { Nav.play(this, it.id) } })
        b.addView(pill("Información", false) { Nav.title(this, featured.id) }, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        info.addView(b)
        frame.addView(info, FrameLayout.LayoutParams((w * 0.9f).toInt(), WRAP, Gravity.BOTTOM or Gravity.START))
        frame.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        if (!Tv.on) frame.setOnClickListener { Nav.title(this, featured.id) }
        content.addView(frame)

        val cw = if (Tv.on) dp(230) else (contentW * 0.62f).toInt()
        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(sectionTitle("Seguir viendo"))
            content.addView(hRow(cont.mapNotNull { f ->
                Catalog.title(f.titleId)?.let { t ->
                    landscapeCard(t, cw, (if (f.episode > 0) "${f.code} · " else "") + remaining(f), f.progress) { Nav.play(this, f.id) }
                }
            }, 10))
        }
        fun row(title: String, list: List<Title>) {
            if (list.isEmpty()) return
            content.addView(sectionTitle(title))
            content.addView(hRow(list.take(homeCap).map { t ->
                if (posterRows) posterCard(t, dp(124)) { Nav.title(this, t.id) } else landscapeCard(t, cw) { Nav.title(this, t.id) }
            }, if (posterRows) 12 else 10))
        }
        row("Agregados recientemente", all)
        row("Series", all.filter { it.kind == Kind.SERIES })
        row("Películas", all.filter { it.kind == Kind.MOVIE })
        row("Favoritos", all.filter { it.favorite })
        Catalog.genres().take(if (Tv.lite) 0 else 6).forEach { g -> row(g, all.filter { g in it.genres }) }
    }

    // ---------- Muro: contador gigante + pared de pósters ----------
    private fun homeWall(content: LinearLayout, all: List<Title>) {
        val top = vbox().apply { setPadding(dp(16), dp(10), dp(16), dp(16)) }
        val big = hbox().apply { gravity = Gravity.BOTTOM }
        big.addView(heading(all.size.toString(), 72f, Col.RED))
        big.addView(heading("títulos\nen tu muro", 16f, Col.TEXT).apply { setPadding(dp(10), 0, 0, dp(14)) })
        top.addView(big)
        val files = all.sumOf { Catalog.filesOf(it.id).size }
        val watchingCount = Catalog.continueWatching().size
        top.addView(heading("${all.count { it.kind == Kind.SERIES }} series · ${all.count { it.kind == Kind.MOVIE }} películas · $files archivos · $watchingCount en curso",
            12f, Col.MUTED))
        content.addView(top)

        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(heading("Seguir viendo", 13f, Col.RED).apply { setPadding(dp(16), 0, dp(16), dp(8)) })
            content.addView(hRow(cont.mapNotNull { f ->
                Catalog.title(f.titleId)?.let { t ->
                    val chip = hbox().apply {
                        background = rounded(Col.CARD2, 0f)
                        setOnClickListener { Nav.play(this@MainActivity, f.id) }
                    }
                    val im = ImageView(this)
                    im.show(t.poster, t.localCover())
                    chip.addView(im, LinearLayout.LayoutParams(dp(40), dp(60)))
                    val c = vbox().apply { setPadding(dp(10), 0, dp(12), 0) }
                    c.addView(heading(t.name, 12f, Col.TEXT, 1))
                    c.addView(txt(if (f.episode > 0) f.code else remaining(f), 11f, Col.MUTED))
                    chip.addView(c)
                    chip
                }
            }, 6))
            content.addView(View(this), lp(MATCH, dp(16)))
        }
        // Pared: 3 columnas de borde a borde (6 en proyector)
        val wallCols = if (Tv.on) 6 else 3
        val colW = contentW / wallCols
        all.take(homeCap * 2).chunked(wallCols).forEach { rowItems ->
            val row = hbox()
            rowItems.forEach { t -> row.addView(posterCard(t, colW, wall = true) { Nav.title(this, t.id) }) }
            content.addView(row)
        }
        if (all.size > homeCap * 2) content.addView(pill("Ver todo el muro", true) { go(Sec.ALL) }, lp().apply {
            setMargins(dp(16), dp(16), dp(16), 0)
        })
    }

    // ---------- Ficha técnica: listas detalladas ----------
    private fun homeList(content: LinearLayout, all: List<Title>) {
        content.setPadding(dp(12), 0, dp(12), dp(32))
        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(listLabel("SEGUIR VIENDO"))
            cont.forEach { f ->
                val t = Catalog.title(f.titleId) ?: return@forEach
                val row = hbox().apply {
                    background = rounded(Col.CARD, r())
                    setPadding(dp(8), dp(8), dp(10), dp(8))
                    setOnClickListener { Nav.play(this@MainActivity, f.id) }
                }
                val tw = dp(96)
                val im = ImageView(this).apply { background = rounded(Col.CARD2, r(0.5f)); clipToOutline = true }
                im.show(f.still ?: t.fanart(), f.coverPath)
                row.addView(im, LinearLayout.LayoutParams(tw, (tw * 9f / 16f).toInt()))
                val c = vbox().apply { setPadding(dp(10), 0, dp(6), 0) }
                c.addView(txt(t.name, 14f, Col.TEXT, true, 1))
                c.addView(txt(listOfNotNull(f.code.ifBlank { null }, f.epName.ifBlank { null }).joinToString(" · ").ifBlank { remaining(f) },
                    12f, Col.MUTED, false, 1))
                c.addView(progressBar(f.progress, 4).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(6) })
                row.addView(c, lp(0, WRAP, 1f))
                row.addView(ImageView(this).apply { setImageResource(R.drawable.ic_play); setColorFilter(Col.RED) },
                    LinearLayout.LayoutParams(dp(28), dp(28)))
                content.addView(row, lp().apply { bottomMargin = dp(8) })
            }
        }
        content.addView(listLabel("AGREGADOS RECIENTEMENTE"))
        all.take(homeCap).forEach { t -> content.addView(mediaRow(t) { Nav.title(this, t.id) }, lp().apply { bottomMargin = dp(10) }) }
        if (all.size > homeCap) content.addView(pill("Ver los ${all.size} títulos", false) { go(Sec.ALL) }, lp().apply { topMargin = dp(6) })
    }

    private fun listLabel(s: String) = txt(s, 11f, Col.RED, true).apply {
        typeface = Typeface.MONOSPACE
        letterSpacing = 0.12f
        setPadding(dp(2), dp(16), 0, dp(8))
    }

    // ---------- Papel: portada de revista + índice ----------
    private fun homeMagazine(content: LinearLayout, all: List<Title>) {
        content.setPadding(dp(20), 0, dp(20), dp(36))
        val date = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "MX")).format(Date())
        content.addView(View(this).apply { setBackgroundColor(Col.TEXT) }, lp(MATCH, dp(2)))
        content.addView(txt("Edición del $date  ·  ${all.size} títulos", 12f, Col.MUTED).apply {
            setTypeface(th.font, Typeface.ITALIC); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
        }, lp())
        content.addView(View(this).apply { setBackgroundColor(Col.LINE) }, lp(MATCH, dp(1)))

        val t = all.firstOrNull { !it.poster.isNullOrBlank() } ?: all.first()
        val cover = hbox().apply { gravity = Gravity.TOP; setPadding(0, dp(20), 0, dp(10)) }
        val pw = ((screenW - dp(40)) * 0.44f).toInt()
        val pf = FrameLayout(this).apply { background = rounded(Col.CARD2, 0f, dp(1), Col.TEXT); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        val im = ImageView(this)
        im.show(t.poster, t.localCover())
        pf.addView(im, FrameLayout.LayoutParams(MATCH, MATCH))
        cover.addView(pf, LinearLayout.LayoutParams(pw, (pw * 1.5f).toInt()))
        val col = vbox().apply { setPadding(dp(16), 0, 0, 0) }
        col.addView(txt("PORTADA", 11f, Col.RED, true).apply { letterSpacing = 0.2f })
        col.addView(txt(t.name, 28f, Col.TEXT, true, 3).apply { setLineSpacing(0f, 0.95f); setPadding(0, dp(4), 0, dp(6)) })
        col.addView(txt(t.metaLine(), 13f, Col.MUTED).apply { setTypeface(th.font, Typeface.ITALIC) })
        if (t.overview.isNotBlank()) col.addView(txt(t.overview, 14f, Col.SOFT, false, 7).apply { setLineSpacing(0f, 1.2f); setPadding(0, dp(10), 0, 0) })
        cover.addView(col, lp(0, WRAP, 1f))
        cover.setOnClickListener { Nav.title(this, t.id) }
        content.addView(cover)
        content.addView(playInfoButtons(t), lp().apply { bottomMargin = dp(10) })

        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(magSection("En curso"))
            cont.forEach { f ->
                val tt = Catalog.title(f.titleId) ?: return@forEach
                content.addView(txt("—  ${tt.name}" + (if (f.episode > 0) ", ${f.code}" else "") + "  ·  ${remaining(f).lowercase()}",
                    15f, Col.TEXT).apply {
                    setPadding(0, dp(8), 0, dp(8))
                    setOnClickListener { Nav.play(this@MainActivity, f.id) }
                })
            }
        }
        content.addView(magSection("Índice"))
        all.take(homeCap).forEachIndexed { i, x -> content.addView(indexRow(x, i + 1) { Nav.title(this, x.id) }) }
        if (all.size > homeCap) content.addView(pill("Índice completo (${all.size})", false) { go(Sec.ALL) }, lp().apply { topMargin = dp(14) })
    }

    private fun magSection(s: String): View {
        val v = vbox().apply { setPadding(0, dp(22), 0, dp(4)) }
        v.addView(View(this).apply { setBackgroundColor(Col.TEXT) }, lp(MATCH, dp(2)))
        v.addView(txt(s, 22f, Col.TEXT, true).apply { setTypeface(th.titleFont, Typeface.BOLD_ITALIC); setPadding(0, dp(6), 0, 0) })
        return v
    }

    // ---------- Vacío ----------
    private fun showEmpty(msg: String, showAdd: Boolean) {
        val scroll = ScrollView(this)
        val box = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(28), dp(70), dp(28), 0) }
        box.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher) }, LinearLayout.LayoutParams(dp(90), dp(90)))
        box.addView(heading(msg, 18f).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) })
        if (showAdd) {
            box.addView(txt("Pega links o elige carpetas de tu celular o memoria USB y la app arma las series, temporadas y películas por ti.", 14f, Col.MUTED)
                .apply { gravity = Gravity.CENTER })
            box.addView(pill("Agregar contenido", true, R.drawable.ic_add) {
                startActivity(Intent(this, AddActivity::class.java))
            }, lp(WRAP, WRAP).apply { topMargin = dp(22) })
        }
        scroll.addView(box)
        body.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
