package com.donnadiex.enlaceplay

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONObject

/** Control remoto del proyector desde el celular (sin internet, por el punto de acceso). */
class RemoteActivity : BaseActivity() {

    private lateinit var state: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowSub: TextView
    private lateinit var time: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: ImageView
    private lateinit var cover: ImageView
    private lateinit var shareBtn: TextView
    private var lastLen = 0L
    private var dragging = false
    private var lastCover: String? = null
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val col = vbox().apply { setPadding(dp(20), dp(16), dp(20), dp(28)) }
        scroll.addView(col)

        val top = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(iconButton(R.drawable.ic_back, 40, Col.TEXT) { finish() })
        top.addView(heading("Control del proyector", 20f, Col.TEXT).apply { setPadding(dp(8), 0, 0, 0) }, lp(0, WRAP, 1f))
        col.addView(top)

        state = txt("", 13f, Col.MUTED).apply { setPadding(0, dp(10), 0, dp(6)) }
        col.addView(state)
        shareBtn = pill("", false) { toggleShare() }
        col.addView(shareBtn, lp())

        // Lo que se está viendo
        val now = vbox().apply {
            background = rounded(Col.CARD, r(1.5f)); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        cover = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Col.CARD2, r()) ; clipToOutline = true }
        now.addView(cover, lp(MATCH, dp(170)))
        nowTitle = txt("Nada en reproducción", 17f, Col.TEXT, true, 2).apply { setPadding(0, dp(10), 0, 0) }
        nowSub = txt("", 13f, Col.MUTED, false, 1)
        now.addView(nowTitle); now.addView(nowSub)
        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            thumbTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && lastLen > 0) time.text = Fmt.duration(lastLen * p / 1000) + " / " + Fmt.duration(lastLen)
                }
                override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    dragging = false
                    if (lastLen > 0) cmd("seek", JSONObject().put("to", lastLen * (s?.progress ?: 0) / 1000))
                }
            })
        }
        now.addView(seek, lp().apply { topMargin = dp(10) })
        time = txt("", 12f, Col.MUTED).apply { gravity = Gravity.END }
        now.addView(time, lp())
        col.addView(now, lp().apply { topMargin = dp(14) })

        // Botones
        val row1 = hbox().apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(4)) }
        row1.addView(round(R.drawable.ic_skip_prev, 52) { cmd("prev") })
        row1.addView(round(R.drawable.ic_replay, 52) { cmd("rel", JSONObject().put("ms", -10_000)) })
        playBtn = round(R.drawable.ic_pause, 72, true) { cmd("toggle") }
        row1.addView(playBtn)
        row1.addView(round(R.drawable.ic_forward, 52) { cmd("rel", JSONObject().put("ms", 10_000)) })
        row1.addView(round(R.drawable.ic_skip_next, 52) { cmd("next") })
        col.addView(row1, lp())

        val row2 = hbox().apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        row2.addView(pill("Vol −", false) { cmd("vol", JSONObject().put("d", -1)) })
        row2.addView(pill("Vol +", false) { cmd("vol", JSONObject().put("d", 1)) }, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        row2.addView(pill("Saltar intro", false) { cmd("skip") }, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        row2.addView(pill("Detener", false) { cmd("stop") }, lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        col.addView(row2, lp())

        col.addView(txt("Para elegir qué ver: abre una serie o película y en el menú ☰ toca \"Ver en el proyector\".", 12f, Col.MUTED)
            .apply { setPadding(0, dp(18), 0, 0) })

        // Seguir viendo (atajo)
        val cont = Catalog.continueWatching().filter { Local.isLocal(it.url) }.take(6)
        if (cont.isNotEmpty()) {
            col.addView(heading("SEGUIR VIENDO EN EL PROYECTOR", 12f, Col.RED).apply { setPadding(0, dp(20), 0, dp(6)) })
            cont.forEach { f ->
                val t = Catalog.title(f.titleId)
                col.addView(pill((t?.name ?: f.fileName) + if (f.episode > 0) "  ·  ${f.code}" else "", false, R.drawable.ic_play) {
                    playOnProjector(f)
                }, lp().apply { bottomMargin = dp(6) })
            }
        }
        setContentView(scroll)
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun round(icon: Int, size: Int, big: Boolean = false, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(icon)
        setColorFilter(if (big) Col.ON_ACCENT else Col.TEXT)
        val pad = dp(if (big) 18 else 14)
        setPadding(pad, pad, pad, pad)
        background = rounded(if (big) Col.RED else Col.CARD, dpf(size / 2f))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(5), 0, dp(5), 0) }
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun cmd(c: String, extra: JSONObject = JSONObject()) {
        if (!LibraryShare.running) { toast("Primero activa \"Compartir mi biblioteca\""); return }
        if (!LibraryShare.projectorOnline) toast("El proyector no está conectado; se enviará cuando se conecte")
        LibraryShare.send(extra.put("c", c))
    }

    private fun playOnProjector(f: MediaFile) {
        cmd("play", JSONObject().put("f", f.id).put("pos", if (f.finished) 0 else f.positionMs))
        toast("Enviado al proyector")
    }

    private fun toggleShare() {
        if (ShareService.on) ShareService.stop(this) else { askNotifications(); ShareService.start(this) }
        ui.postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        val sharing = LibraryShare.running
        shareBtn.text = if (sharing) "Compartiendo · toca para dejar de compartir" else "Compartir mi biblioteca"
        state.text = when {
            !sharing -> "1) Activa el punto de acceso de tu celular.  2) Conecta el proyector a esa red.  3) Toca \"Compartir mi biblioteca\".  4) En el proyector: Ajustes → Buscar mi celular."
            LibraryShare.projectorOnline -> "● Conectado: ${LibraryShare.projectorName.ifBlank { "proyector" }}"
            else -> "Esperando al proyector…  (IP del celular: ${LibraryShare.ips().joinToString(", ")})"
        }
        state.setTextColor(if (sharing && LibraryShare.projectorOnline) Color.parseColor("#4CAF50") else Col.MUTED)
        val s = LibraryShare.status
        val fresh = s != null && System.currentTimeMillis() - LibraryShare.statusAt < 8_000
        if (!fresh) {
            nowTitle.text = "Nada en reproducción"; nowSub.text = ""; time.text = ""
            seek.progress = 0; playBtn.setImageResource(R.drawable.ic_play)
            return
        }
        nowTitle.text = s!!.optString("title")
        nowSub.text = s.optString("sub")
        val pos = s.optLong("pos"); lastLen = s.optLong("len")
        if (!dragging) {
            time.text = Fmt.duration(pos).let { if (it == "—") "0:00" else it } + " / " + (if (lastLen > 0) Fmt.duration(lastLen) else "--:--")
            if (lastLen > 0) seek.progress = (pos * 1000 / lastLen).toInt()
        }
        playBtn.setImageResource(if (s.optBoolean("playing")) R.drawable.ic_pause else R.drawable.ic_play)
        val fid = s.optString("f")
        if (fid != lastCover) {
            lastCover = fid
            val f = Catalog.file(fid); val t = f?.let { Catalog.title(it.titleId) }
            cover.show(f?.still ?: t?.fanart() ?: t?.poster ?: f?.coverPath)
        }
    }

    private fun toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()
}
