package com.donnadiex.enlaceplay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.DatagramPacket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * "Compartir mi biblioteca" (lado del celular), parecido a BubbleUPnP pero hecho para Mi Cine:
 *  - El proyector se conecta al punto de acceso del celular (no gasta datos: el video va directo).
 *  - Mi Cine del proyector ve tu catálogo con pósters y datos, reproduce y adelanta sin internet.
 *  - El celular puede mandar órdenes al proyector (reproducir, pausa, adelantar, volumen…).
 *  - También es un servidor DLNA: VLC, BubbleUPnP o una Smart TV pueden ver tus videos.
 */
object LibraryShare {
    const val PORT = 8766
    const val ST_MICINE = "urn:micine:device:Library:1"
    private const val ST_SERVER = "urn:schemas-upnp-org:device:MediaServer:1"
    private const val ST_CDS = "urn:schemas-upnp-org:service:ContentDirectory:1"
    private const val ST_CMS = "urn:schemas-upnp-org:service:ConnectionManager:1"

    private var http: MiniHttp? = null
    @Volatile private var ssdpRunning = false
    private var ssdpSocket: MulticastSocket? = null
    private lateinit var app: Context

    val running: Boolean get() = http?.isRunning == true

    // ---- Proyector conectado ----
    @Volatile var projectorName = ""
    @Volatile var projectorSeenAt = 0L
    /** Lo que se está viendo en el proyector (lo manda el proyector cada 2 s). */
    @Volatile var status: JSONObject? = null
    @Volatile var statusAt = 0L
    private val commands = LinkedBlockingQueue<JSONObject>()

    val projectorOnline: Boolean get() = System.currentTimeMillis() - projectorSeenAt < 45_000

    fun send(cmd: JSONObject) { commands.offer(cmd.put("t", System.currentTimeMillis())) }

    fun deviceId(ctx: Context): String {
        val p = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        return p.getString("id_aparato", null) ?: UUID.randomUUID().toString().also { p.edit().putString("id_aparato", it).apply() }
    }

    fun deviceName(): String = (Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL).trim()

    /** Las IPs del celular (en el punto de acceso suele ser 192.168.x.1). */
    fun ips(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && it.isSiteLocalAddress }.mapNotNull { it.hostAddress }
    }.getOrDefault(emptyList())

    fun start(ctx: Context) {
        app = ctx.applicationContext
        Catalog.init(app)
        if (running) return
        commands.clear()
        val h = MiniHttp(PORT) { req, res -> handle(req, res) }
        h.start()
        http = h
        startSsdp()
    }

    fun stop() {
        http?.stop(); http = null
        ssdpRunning = false
        runCatching { ssdpSocket?.close() }
        commands.clear()
        commands.offer(JSONObject().put("c", "bye"))
    }

    // ======================= Peticiones =======================
    private fun shared(): List<MediaFile> = Catalog.allFiles().filter {
        it.source.isEmpty() && (Local.isLocal(it.url) || it.url.startsWith("http"))
    }

    private fun handle(req: MiniHttp.Request, res: MiniHttp.Response) {
        val p = req.path
        when {
            p == "/micine/info" -> res.json(info().toString())
            p == "/micine/catalog" -> { seen(req); res.json(catalog(req).toString()) }
            p.startsWith("/micine/v/") -> streamFile(req, res, p.removePrefix("/micine/v/").substringBefore('.'))
            p == "/micine/img" -> image(req, res)
            p.startsWith("/micine/cover/") -> cover(res, p.removePrefix("/micine/cover/"))
            p == "/micine/cmd" -> { seen(req); waitCommand(req, res) }
            p == "/micine/status" -> { seen(req); status = runCatching { JSONObject(req.bodyText) }.getOrNull(); statusAt = System.currentTimeMillis(); res.json("{}") }
            p == "/micine/progress" -> { seen(req); progress(req); res.json("{}") }
            p == "/dlna/desc.xml" -> res.xml(Dlna.description(req.localIp, deviceId(app), "Mi Cine · ${deviceName()}"))
            p == "/dlna/cds.xml" -> res.xml(Dlna.CDS_SCPD)
            p == "/dlna/cms.xml" -> res.xml(Dlna.CMS_SCPD)
            p == "/dlna/cds/control" -> res.xml(Dlna.contentDirectory(req, shared()), mapOf("EXT" to ""))
            p == "/dlna/cms/control" -> res.xml(Dlna.connectionManager(req), mapOf("EXT" to ""))
            p.startsWith("/dlna/") && req.method in listOf("SUBSCRIBE", "UNSUBSCRIBE") ->
                res.send(200, "text/plain", ByteArray(0), mapOf("SID" to "uuid:${UUID.randomUUID()}", "TIMEOUT" to "Second-1800"))
            else -> res.text(404, "No encontrado")
        }
    }

    private fun seen(req: MiniHttp.Request) {
        projectorSeenAt = System.currentTimeMillis()
        req.query["n"]?.takeIf { it.isNotBlank() }?.let { projectorName = it }
    }

    private fun info() = JSONObject().put("app", "micine").put("id", deviceId(app)).put("name", deviceName())
        .put("version", BuildConfigLite.versionName(app)).put("files", shared().size)

    private fun catalog(req: MiniHttp.Request): JSONObject {
        val id = deviceId(app)
        val files = shared()
        val tids = files.map { it.titleId }.toSet()
        val tArr = JSONArray()
        tids.mapNotNull { Catalog.title(it) }.forEach { tArr.put(Catalog.titleToJson(it)) }
        val fArr = JSONArray()
        files.forEach { f ->
            val o = Catalog.fileToJson(f)
            if (Local.isLocal(f.url)) o.put("url", "micine://$id/${f.id}")
            o.put("cover", if (f.coverPath != null && File(f.coverPath!!).exists()) "1" else "")
            o.put("info", JSONArray())   // la ficha técnica se lee en el proyector si hace falta
            fArr.put(o)
        }
        return JSONObject().put("id", id).put("name", deviceName()).put("ip", req.localIp)
            .put("titles", tArr).put("files", fArr)
    }

    private fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "mkv" -> "video/x-matroska"; "mp4", "m4v" -> "video/mp4"; "avi" -> "video/x-msvideo"
        "webm" -> "video/webm"; "ts", "m2ts" -> "video/mp2t"; "mov" -> "video/quicktime"
        "wmv" -> "video/x-ms-wmv"; "flv" -> "video/x-flv"; "3gp" -> "video/3gpp"; else -> "video/mp4"
    }

    fun mimeOfFile(f: MediaFile) = mimeOf(Subs.nameOf(app, Uri.parse(f.url)) ?: f.fileName)

    private fun streamFile(req: MiniHttp.Request, res: MiniHttp.Response, fileId: String) {
        val f = Catalog.file(fileId)
        if (f == null || !Local.isLocal(f.url)) { res.text(404, "No existe"); return }
        val uri = Uri.parse(f.url)
        val len = app.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        res.stream(req, len, mimeOfFile(f), { offset ->
            val pfd = app.contentResolver.openFileDescriptor(uri, "r") ?: error("sin acceso")
            val fis = object : FileInputStream(pfd.fileDescriptor) {
                override fun close() { runCatching { super.close() }; runCatching { pfd.close() } }
            }
            if (offset > 0) fis.channel.position(offset)
            fis
        }, mapOf("transferMode.dlna.org" to "Streaming", "contentFeatures.dlna.org" to "DLNA.ORG_OP=01;DLNA.ORG_FLAGS=01700000000000000000000000000000"))
    }

    /** Pósters y fotos: salen de las imágenes que el celular ya guardó (no hace falta internet). */
    @SuppressLint("UnsafeOptInUsageError")
    @OptIn(coil.annotation.ExperimentalCoilApi::class)
    private fun image(req: MiniHttp.Request, res: MiniHttp.Response) {
        val u = req.query["u"] ?: run { res.text(400, ""); return }
        val loader = coil.Coil.imageLoader(app)
        fun fromCache(): File? = runCatching {
            loader.diskCache?.openSnapshot(u)?.use { File(it.data.toString()).takeIf { f -> f.length() > 0 }?.let { f ->
                // Copia para poder cerrar el snapshot sin perder el archivo
                val tmp = File(app.cacheDir, "img_tmp_${u.hashCode()}"); f.copyTo(tmp, true); tmp
            } }
        }.getOrNull()
        var file = fromCache()
        if (file == null && u.startsWith("http")) {
            // Si el celular sí tiene internet, la descarga y la guarda
            runCatching {
                kotlinx.coroutines.runBlocking {
                    loader.execute(coil.request.ImageRequest.Builder(app).data(u).build())
                }
            }
            file = fromCache()
        }
        if (file == null && File(u).exists()) file = File(u)
        if (file == null) { res.text(404, "Sin imagen"); return }
        val f = file
        res.stream(req, f.length(), "image/jpeg", { off -> FileInputStream(f).also { if (off > 0) it.skip(off) } })
        if (f.name.startsWith("img_tmp_")) f.delete()
    }

    private fun cover(res: MiniHttp.Response, fileId: String) {
        val path = Catalog.file(fileId)?.coverPath
        val f = path?.let { File(it) }
        if (f == null || !f.exists()) { res.text(404, ""); return }
        res.send(200, "image/jpeg", f.readBytes())
    }

    private fun waitCommand(req: MiniHttp.Request, res: MiniHttp.Response) {
        val wait = (req.query["wait"]?.toLongOrNull() ?: 20).coerceIn(1, 30)
        var c = commands.poll(wait, TimeUnit.SECONDS)
        // Órdenes viejas (más de 30 s) ya no sirven
        while (c != null && System.currentTimeMillis() - c.optLong("t") > 30_000) c = commands.poll()
        res.json((c ?: JSONObject()).toString())
    }

    private fun progress(req: MiniHttp.Request) {
        val o = runCatching { JSONObject(req.bodyText) }.getOrNull() ?: return
        val f = Catalog.file(o.optString("f")) ?: return
        val watched = o.optLong("watched")
        if (watched <= f.watchedAt) return
        f.positionMs = o.optLong("pos")
        if (o.optLong("dur") > 0) f.durationMs = o.optLong("dur")
        f.finished = o.optBoolean("done")
        f.watchedAt = watched
        Catalog.save()
    }

    // ======================= Búsqueda en la red (SSDP) =======================
    private fun startSsdp() {
        if (ssdpRunning) return
        ssdpRunning = true
        Thread({
            val group = InetAddress.getByName("239.255.255.250")
            val ms = runCatching { MulticastSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(1900)) } }.getOrNull()
            if (ms == null) { ssdpRunning = false; return@Thread }
            ssdpSocket = ms
            runCatching {
                NetworkInterface.getNetworkInterfaces().toList()
                    .filter { it.isUp && !it.isLoopback && it.supportsMulticast() && it.inetAddresses.toList().any { a -> a is Inet4Address } }
                    .forEach { nif -> runCatching { ms.joinGroup(InetSocketAddress(group, 1900), nif) } }
            }
            ms.soTimeout = 2000
            val buf = ByteArray(4096)
            var lastNotify = 0L
            while (ssdpRunning) {
                if (System.currentTimeMillis() - lastNotify > 60_000) { lastNotify = System.currentTimeMillis(); notifyAlive(ms, group) }
                val pk = DatagramPacket(buf, buf.size)
                try { ms.receive(pk) } catch (_: java.net.SocketTimeoutException) { continue } catch (_: Exception) { break }
                val msg = String(pk.data, 0, pk.length)
                if (!msg.startsWith("M-SEARCH")) continue
                val st = Regex("(?im)^ST:\\s*(.+)$").find(msg)?.groupValues?.get(1)?.trim() ?: continue
                val uuid = "uuid:" + deviceId(app)
                val targets = when (st) {
                    "ssdp:all" -> listOf("upnp:rootdevice", ST_SERVER, ST_CDS, ST_CMS, ST_MICINE)
                    "upnp:rootdevice", ST_SERVER, ST_CDS, ST_CMS, ST_MICINE, uuid -> listOf(st)
                    else -> emptyList()
                }
                val ip = ipFor(pk.address) ?: continue
                targets.forEach { t ->
                    val usn = if (t == uuid) uuid else "$uuid::$t"
                    val r = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\n" +
                        "LOCATION: http://$ip:$PORT/dlna/desc.xml\r\nSERVER: Android/${Build.VERSION.RELEASE} UPnP/1.0 MiCine/5\r\n" +
                        "ST: $t\r\nUSN: $usn\r\nX-MICINE-NAME: ${deviceName()}\r\n\r\n"
                    runCatching { ms.send(DatagramPacket(r.toByteArray(), r.length, pk.address, pk.port)) }
                }
            }
            runCatching { ms.close() }
        }, "MiCine-ssdp").start()
    }

    private fun notifyAlive(ms: MulticastSocket, group: InetAddress) {
        val uuid = "uuid:" + deviceId(app)
        ips().forEach { ip ->
            listOf("upnp:rootdevice", ST_SERVER, ST_CDS, ST_MICINE).forEach { t ->
                val m = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nCACHE-CONTROL: max-age=1800\r\n" +
                    "LOCATION: http://$ip:$PORT/dlna/desc.xml\r\nNT: $t\r\nNTS: ssdp:alive\r\n" +
                    "SERVER: Android/${Build.VERSION.RELEASE} UPnP/1.0 MiCine/5\r\nUSN: $uuid::$t\r\n\r\n"
                runCatching { ms.send(DatagramPacket(m.toByteArray(), m.length, group, 1900)) }
            }
        }
    }

    /** La IP del celular que está en la misma red que quien pregunta. */
    private fun ipFor(remote: InetAddress): String? {
        val r = remote.hostAddress ?: return ips().firstOrNull()
        val prefix = r.substringBeforeLast('.')
        return ips().firstOrNull { it.substringBeforeLast('.') == prefix } ?: ips().firstOrNull()
    }

    fun urlFor(localIp: String, f: MediaFile) = "http://$localIp:$PORT/micine/v/${f.id}"
    fun imgUrl(localIp: String, u: String) = "http://$localIp:$PORT/micine/img?u=" + URLEncoder.encode(u, "UTF-8")
}

/** Versión de la app sin depender de BuildConfig. */
object BuildConfigLite {
    fun versionName(ctx: Context): String = runCatching {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    }.getOrDefault("")
}

/** Mantiene el servidor encendido con la pantalla apagada y muestra la notificación. */
class ShareService : Service() {
    companion object {
        private const val CH = "compartir"
        private const val ID = 4108
        private const val STOP = "detener"
        @Volatile var on = false

        fun start(ctx: Context) {
            val i = Intent(ctx, ShareService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, ShareService::class.java)) }
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var mcast: WifiManager.MulticastLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b = if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(CH) == null)
                nm.createNotificationChannel(NotificationChannel(CH, "Compartir biblioteca", NotificationManager.IMPORTANCE_LOW))
            Notification.Builder(this, CH)
        } else @Suppress("DEPRECATION") Notification.Builder(this)
        val stopPi = PendingIntent.getService(this, 1, Intent(this, ShareService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, RemoteActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        val n = b.setSmallIcon(R.drawable.ic_tv)
            .setContentTitle("Mi Cine: compartiendo tu biblioteca")
            .setContentText("En el proyector: Ajustes → Buscar mi celular · " + LibraryShare.ips().joinToString(", "))
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "Dejar de compartir", stopPi).build())
            .build()
        runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(ID, n)
        }
        runCatching { LibraryShare.start(this) }.onFailure {
            android.widget.Toast.makeText(this, "No se pudo compartir: ${it.message}", android.widget.Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        on = true
        if (wake == null) runCatching {
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MiCine:compartir").apply { acquire(8 * 3_600_000L) }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MiCine:compartir").apply { acquire() }
            mcast = wm.createMulticastLock("MiCine:ssdp").apply { setReferenceCounted(false); acquire() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        on = false
        LibraryShare.stop()
        runCatching { wake?.release() }; runCatching { wifi?.release() }; runCatching { mcast?.release() }
        wake = null; wifi = null; mcast = null
        super.onDestroy()
    }
}
