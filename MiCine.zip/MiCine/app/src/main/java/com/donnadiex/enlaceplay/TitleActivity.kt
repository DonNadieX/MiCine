package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class TitleActivity : BaseActivity() {

    private lateinit var t: Title
    private var tab = 0
    private lateinit var body: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val found = intent.getStringExtra("id")?.let { Catalog.title(it) }
        if (found == null) { finish(); return }
        t = found

        root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), 0) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        tabsRow = hbox()
        top.addView(tabsRow, lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        body = vbox().apply { setPadding(0, 0, 0, dp(40)) }
        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)

        // Títulos agregados antes de esta versión: bajan portadas de temporada, origen y reparto una sola vez.
        if (t.ext.isNotBlank() && !t.ext.startsWith("manual") && t.cast.isEmpty() && t.seasons.isEmpty() && t.origin.isBlank()) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { runCatching { Meta.refresh(applicationContext, t) }.getOrDefault(false) }
                if (ok) { t.tint = 0; Catalog.save(); render() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (recreating || !::t.isInitialized) return
        val fresh = Catalog.title(t.id)
        if (fresh == null) { finish(); return }
        t = fresh
        render()
    }

    private fun render() {
        val labels = listOf("Resumen", if (t.kind == Kind.SERIES) "Temporadas" else "Archivos")
        tabsRow.removeAllViews()
        labels.forEachIndexed { i, s ->
            tabsRow.addView(txt(s, 17f, if (i == tab) Col.RED else Col.MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(12), dp(8), dp(12))
                if (i == tab) background = underline(24)
                setOnClickListener { tab = i; render() }
            }, lp(0, WRAP, 1f))
        }
        body.removeAllViews()
        applyTint()
        if (tab == 0) summary() else if (t.kind == Kind.SERIES) seasons() else movieFiles()
    }

    /** Fondo con el color del póster de esta serie. Se calcula una vez y se guarda. */
    private fun applyTint() {
        if (t.tint != 0) {
            root.background = Look.ambient(t.tint)
            window.statusBarColor = Look.topColor(t.tint)
            return
        }
        if (t.poster.isNullOrBlank() && t.localCover() == null) return
        if (Tv.lite) return   // modo ligero: sin calcular colores (ahorra memoria en el proyector)
        scope.launch {
            val c = runCatching { Look.computeTint(applicationContext, t) }.getOrNull() ?: return@launch
            t.tint = c
            Catalog.save()
            render()
        }
    }

    // ---------- Resumen (diseño Cinemático) ----------
    private fun summary() {
        val files = Catalog.filesOf(t.id)
        val next = Catalog.nextToWatch(t.id)
        val localCover = files.firstOrNull { it.coverPath != null }?.coverPath
        val soft = if (t.tint != 0) Look.soft(t.tint) else Col.MUTED

        // Banner panorámico + póster pequeño encimado
        val bh = minOf((screenW * 9f / 16f).toInt(), (screenH * 0.58f).toInt())
        val pw = dp(if (Tv.on) 120 else 100)
        val ph = (pw * 1.5f).toInt()
        val hero = FrameLayout(this)
        val ban = ImageView(this)
        hero.addView(ban, FrameLayout.LayoutParams(MATCH, bh))
        ban.show(t.backdrop ?: t.seasons.values.firstOrNull { it.poster != null }?.poster ?: t.poster, localCover)
        val fadeTo = if (t.tint != 0) Look.topColor(t.tint) else Col.BG
        hero.addView(View(this).apply {
            background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(fadeTo, (fadeTo and 0x00FFFFFF) or 0x66000000, Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(MATCH, bh / 2).apply { topMargin = bh / 2 })
        val row = hbox().apply { gravity = Gravity.BOTTOM; setPadding(dp(14), 0, dp(14), 0) }
        val pf = FrameLayout(this).apply { background = rounded(Col.CARD2, r(), dp(2), Color.WHITE); clipToOutline = true }
        val pimg = ImageView(this)
        pf.addView(pimg, FrameLayout.LayoutParams(MATCH, MATCH))
        pimg.show(t.poster, localCover)
        if (t.poster.isNullOrBlank() && localCover == null) pf.addView(heading(t.name, 12f, Col.TEXT, 4).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
        row.addView(pf, LinearLayout.LayoutParams(pw, ph))
        val tcol = vbox().apply { setPadding(dp(12), 0, 0, dp(2)) }
        tcol.addView(heading(t.name, 21f, Col.TEXT, 3))
        val line = listOfNotNull(
            if (t.year > 0) t.year.toString() else null,
            t.network.ifBlank { null },
            if (t.kind == Kind.SERIES) "${files.size} ep." else files.firstOrNull { it.durationMs > 0 }?.let { Fmt.duration(it.durationMs) }
        ).joinToString(" · ")
        tcol.addView(txt(line, 13f, soft).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(tcol, lp(0, WRAP, 1f))
        hero.addView(row, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = bh - ph / 2 - dp(14) })
        body.addView(hero, lp(MATCH, bh + ph / 2 + dp(4)))

        val side = if (Tv.on) dp(40) else dp(14)
        val content = vbox().apply { setPadding(side, dp(12), side, 0) }

        // Etiquetas
        val chips = mutableListOf<TextView>(originTag(t, t.tint))
        if (t.rating > 0) chips += chip(String.format(Locale.US, "★ %.1f", t.rating)).apply {
            setTextColor(if (Themes.cur.light) Col.RED else Color.parseColor("#F5C518"))
        }
        if (t.status.isNotBlank()) chips += chip(t.status)
        t.genres.filter { it != "Anime" }.take(4).forEach { chips += chip(it) }
        content.addView(chipRow(chips))

        // Botones: Reproducir/Continuar + Mi lista + más opciones
        val buttons = hbox().apply { setPadding(0, dp(12), 0, 0) }
        val playLabel = when {
            next == null -> "Sin archivos"
            next.positionMs > 5000 && !next.finished -> "Continuar" + if (next.episode > 0) " ${next.code}" else ""
            next.episode > 0 -> "Reproducir ${next.code}"
            else -> "Reproducir"
        }
        buttons.addView(pill(playLabel, true, R.drawable.ic_play) { next?.let { Nav.play(this, it.id) } }, lp(0, WRAP, 1f))
        fun square(icon: Int, tint: Int, click: (View) -> Unit) = ImageView(this).apply {
            setImageResource(icon); setColorFilter(tint)
            background = rounded(Col.CARD2, r(0.8f).coerceAtLeast(dpf(4f)))
            setPadding(dp(11), dp(11), dp(11), dp(11))
            setOnClickListener { click(it) }
        }
        buttons.addView(square(if (t.favorite) R.drawable.ic_heart else R.drawable.ic_heart_outline, if (t.favorite) Col.RED else Col.TEXT) {
            t.favorite = !t.favorite
            Catalog.save()
            toast(if (t.favorite) "Agregado a Mi lista" else "Quitado de Mi lista")
            render()
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        buttons.addView(square(R.drawable.ic_list, Col.TEXT) { v -> moreMenu(v, next) },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        content.addView(buttons, lp())

        // Sinopsis
        val ov = t.overview.ifBlank { "Sin sinopsis. Toca ☰ → Corregir datos para buscar el título correcto." }
        content.addView(txt(ov, 14f, Col.SOFT, false, 4).apply {
            setLineSpacing(0f, 1.25f)
            setPadding(0, dp(14), 0, 0)
            setOnClickListener { maxLines = if (maxLines == 4) 100 else 4 }
        })

        // Tarjeta del siguiente capítulo
        if (next != null && (t.kind == Kind.SERIES || next.positionMs > 5000)) {
            val card = hbox().apply {
                background = rounded((Col.TEXT and 0x00FFFFFF) or 0x14000000, r(1.2f))
                setPadding(dp(8), dp(8), dp(10), dp(8))
                setOnClickListener { Nav.play(this@TitleActivity, next.id) }
            }
            val tw = dp(112)
            val th = FrameLayout(this).apply { background = rounded(Col.CARD2, r(0.6f)); clipToOutline = true }
            val ti = ImageView(this)
            th.addView(ti, FrameLayout.LayoutParams(MATCH, MATCH))
            ti.show(next.still ?: t.backdrop ?: t.poster, next.coverPath)
            th.addView(ImageView(this).apply { setImageResource(R.drawable.ic_play) }, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            card.addView(th, LinearLayout.LayoutParams(tw, (tw * 9f / 16f).toInt()))
            val c = vbox().apply { setPadding(dp(10), 0, 0, 0) }
            c.addView(txt(if (next.positionMs > 5000 && !next.finished) "CONTINUAR" else "SIGUIENTE", 10f, Col.RED, true).apply { letterSpacing = 0.1f })
            c.addView(txt(listOfNotNull(next.code.ifBlank { null }, next.epName.ifBlank { if (next.episode > 0) "Capítulo ${next.episode}" else null })
                .joinToString(" · ").ifBlank { t.name }, 14f, Col.TEXT, true, 2))
            if (next.progress > 0f && !next.finished) c.addView(progressBar(next.progress, 3).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(6) })
            card.addView(c, lp(0, WRAP, 1f))
            content.addView(card, lp().apply { topMargin = dp(14) })
        }
        body.addView(content)

        // Reparto
        if (t.cast.isNotEmpty()) {
            body.addView(sectionTitle(if (t.anime) "Personajes" else "Reparto"))
            // Toca a un actor para ver todo lo que tienes con él
            body.addView(hRow(t.cast.map { c ->
                castCard(c).apply {
                    isClickable = true; isFocusable = true
                    setOnClickListener {
                        startActivity(android.content.Intent(this@TitleActivity, MainActivity::class.java).putExtra("buscar", c.name)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    }
                }
            }, 12))
        }

        // Más de la misma saga, en orden de estreno
        Sagas.of(t)?.let { sg ->
            body.addView(sectionTitle("Saga: ${sg.name} (${sg.titles.size})"))
            body.addView(hRow(sg.titles.map { m ->
                posterCard(m, dp(if (Tv.on) 120 else 104)) { if (m.id != t.id) Nav.title(this, m.id) }.apply {
                    if (m.id == t.id) alpha = 0.45f
                }
            }, 12))
        }

        // Ficha de datos
        val seen = files.count { it.finished }
        val facts = listOfNotNull(
            if (t.status.isNotBlank()) "Estado" to t.status else null,
            if (t.network.isNotBlank()) (if (t.anime) "Estudio" else if (t.kind == Kind.SERIES) "Cadena" else "Productora") to t.network else null,
            if (t.origin.isNotBlank()) "Origen" to (Look.flag(t.origin) + " " + Look.originLabel(t)) else null,
            if (t.kind == Kind.SERIES) "Tienes" to ("${files.size}" + if (t.totalEpisodes > 0) " de ${t.totalEpisodes} ep." else " ep.") else null,
            if (t.kind == Kind.SERIES && files.isNotEmpty()) "Visto" to "${seen * 100 / files.size}% ($seen ep.)" else null,
            files.map { it.quality }.filter { it.isNotBlank() }.distinct().takeIf { it.isNotEmpty() }?.let { "Calidad" to it.joinToString(", ") { q -> q.uppercase() } },
            "Archivos en" to files.map { Local.whereLabel(it.url) }.distinct().joinToString(", ")
        )
        body.addView(sectionTitle("Ficha"))
        val grid = vbox().apply {
            background = rounded((Col.TEXT and 0x00FFFFFF) or 0x0F000000, r(1.2f))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        facts.chunked(2).forEach { pair ->
            val r = hbox().apply { gravity = Gravity.TOP; setPadding(0, dp(7), 0, dp(7)) }
            pair.forEach { (k, v) ->
                val cell = vbox()
                cell.addView(txt(k, 11f, soft))
                cell.addView(txt(v, 13f, Col.TEXT, true, 2))
                r.addView(cell, lp(0, WRAP, 1f))
            }
            if (pair.size == 1) r.addView(View(this), lp(0, 1, 1f))
            grid.addView(r)
        }
        body.addView(grid, lp().apply { setMargins(side, 0, side, 0) })
    }

    private fun moreMenu(anchor: View, next: MediaFile?) {
        val pm = android.widget.PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Información del archivo")
        pm.menu.add(0, 2, 1, "Corregir datos / portada")
        pm.menu.add(0, 3, 2, "Actualizar datos")
        pm.menu.add(0, 4, 3, "Quitar del catálogo")
        if (LibraryShare.running && next != null && Local.isLocal(next.url)) pm.menu.add(0, 5, 0, "📽  Ver en el proyector")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> next?.let { Nav.info(this, it.id) }
                2 -> correctDialog()
                3 -> {
                    toast("Actualizando…")
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { runCatching { Meta.refresh(applicationContext, t) }.getOrDefault(false) }
                        t.tint = 0
                        Catalog.save()
                        toast(if (ok) "Datos actualizados" else "No se pudo actualizar")
                        render()
                    }
                }
                4 -> deleteDialog()
                5 -> next?.let { f ->
                    LibraryShare.send(org.json.JSONObject().put("c", "play").put("f", f.id).put("pos", if (f.finished) 0 else f.positionMs))
                    if (!LibraryShare.projectorOnline) toast("El proyector aún no se conecta; empezará en cuanto lo haga")
                    startActivity(android.content.Intent(this, RemoteActivity::class.java))
                }
            }
            true
        }
        pm.show()
    }

    // ---------- Temporadas ----------
    private var selSeason = -1
    private val prefs get() = getSharedPreferences("ajustes", MODE_PRIVATE)
    private var onlyUnseen = false
    private val desc get() = prefs.getBoolean("ep_desc", false)
    private val gridMode get() = prefs.getBoolean("ep_grid", false)
    private var showLimit = 60

    private fun seasons() {
        val files = Catalog.filesOf(t.id)
        val bySeason = files.groupBy { it.season }.toSortedMap()
        if (bySeason.isEmpty()) return
        val next = Catalog.nextToWatch(t.id)
        if (selSeason !in bySeason.keys) selSeason = next?.season?.takeIf { it in bySeason.keys } ?: bySeason.firstKey()
        val tint = t.tint
        val accentSoft = if (tint != 0) Look.soft(tint) else Col.MUTED

        // Encabezado: origen + cadena/estudio + año
        val head = vbox().apply { setPadding(dp(14), dp(10), dp(14), 0) }
        val tags = hbox()
        tags.addView(originTag(t, tint))
        val extra = listOfNotNull(t.network.ifBlank { null }, if (t.year > 0) t.year.toString() else null).joinToString(" · ")
        if (extra.isNotBlank()) tags.addView(chip(extra), lp(WRAP, WRAP).apply { leftMargin = dp(8) })
        head.addView(chipRowOf(tags))
        head.addView(heading(t.name, 22f, Col.TEXT, 2).apply { setPadding(0, dp(8), 0, 0) })
        body.addView(head)

        // Carrusel de temporadas con portada y anillo de progreso
        val cardW = dp(118)
        val cards = bySeason.map { (n, eps) ->
            val info = t.seasons[n]
            val on = n == selSeason
            val box = vbox().apply {
                alpha = if (on) 1f else 0.6f
                setOnClickListener { selSeason = n; showLimit = 60; render() }
            }
            val frame = FrameLayout(this).apply {
                background = rounded(Col.CARD2, r(1.3f), if (on) dp(2) else 0, Col.TEXT)
                clipToOutline = true
                if (on) setPadding(dp(2), dp(2), dp(2), dp(2))
            }
            val img = ImageView(this)
            frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
            img.show(info?.poster ?: t.poster, eps.firstOrNull { it.coverPath != null }?.coverPath ?: t.localCover())
            frame.addView(txt(if (n == 0) "ESP" else "T$n", 11f, Color.WHITE, true).apply {
                background = rounded(Color.parseColor("#B3000000"), dpf(4f))
                setPadding(dp(6), dp(1), dp(6), dp(1))
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { setMargins(dp(6), dp(6), 0, 0) })
            frame.addView(Look.Ring(this, eps.count { it.finished }, eps.size, Col.RED),
                FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(6), dp(6)) })
            box.addView(frame, LinearLayout.LayoutParams(cardW, (cardW * 1.45f).toInt()))
            val title = when {
                n == 0 -> "Especiales"
                info?.name?.isNotBlank() == true && !info.name.matches(Regex("(?i)(season|temporada) ?\\d+")) -> info.name
                else -> "Temporada $n"
            }
            box.addView(txt(title, 13f, Col.TEXT, true, 1).apply { setPadding(0, dp(6), 0, 0) }, LinearLayout.LayoutParams(cardW, WRAP))
            val sub = listOfNotNull("${eps.size} ep.", info?.year?.takeIf { it > 0 }?.toString()).joinToString(" · ")
            box.addView(txt(sub, 11f, accentSoft), LinearLayout.LayoutParams(cardW, WRAP))
            box
        }
        body.addView(hRow(cards, 10).apply { setPadding(dp(14), dp(14), dp(14), dp(6)) })

        // Panel de la temporada elegida
        val eps = bySeason[selSeason].orEmpty()
        val seasonNext = eps.firstOrNull { !it.finished && it.positionMs > 5000 } ?: eps.firstOrNull { !it.finished }
        val panel = vbox().apply {
            background = rounded((Col.TEXT and 0x00FFFFFF) or 0x14000000, r(1.4f))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val sOverview = t.seasons[selSeason]?.overview?.ifBlank { null } ?: t.overview
        if (sOverview.isNotBlank()) panel.addView(txt(sOverview, 13f, Col.SOFT, false, 3).apply {
            setLineSpacing(0f, 1.2f)
            setOnClickListener { maxLines = if (maxLines == 3) 100 else 3 }
        })
        val btns = hbox().apply { setPadding(0, if (sOverview.isNotBlank()) dp(10) else 0, 0, 0) }
        val playLabel = when {
            seasonNext == null -> "Ver de nuevo"
            seasonNext.positionMs > 5000 -> "Continuar ${seasonNext.code}"
            else -> "Reproducir ${seasonNext.code}"
        }
        btns.addView(pill(playLabel, true, R.drawable.ic_play) {
            (seasonNext ?: eps.firstOrNull())?.let { Nav.play(this, it.id) }
        }, lp(0, WRAP, 3f))
        val allSeen = eps.isNotEmpty() && eps.all { it.finished }
        btns.addView(pill(if (allSeen) "Desmarcar" else "Vista", false, if (allSeen) 0 else R.drawable.ic_check) {
            eps.forEach { f ->
                f.finished = !allSeen
                if (!allSeen) { f.positionMs = 0; f.watchedAt = System.currentTimeMillis() }
            }
            Catalog.save(); render()
            toast(if (allSeen) "Temporada marcada como no vista" else "Temporada marcada como vista")
        }, lp(0, WRAP, 2f).apply { leftMargin = dp(8) })
        panel.addView(btns, lp())
        body.addView(panel, lp().apply { setMargins(dp(14), dp(8), dp(14), dp(10)) })

        // Filtros
        val filters = hbox().apply { setPadding(dp(14), 0, dp(14), dp(6)) }
        fun fchip(label: String, on: Boolean, click: () -> Unit) = txt(label, 12f, if (on) Col.BG else Col.TEXT, true).apply {
            background = if (on) rounded(Col.TEXT, dpf(14f)) else rounded((Col.TEXT and 0x00FFFFFF) or 0x1F000000, dpf(14f))
            setPadding(dp(12), dp(5), dp(12), dp(5))
            setOnClickListener { click() }
        }
        filters.addView(fchip("Todos", !onlyUnseen) { onlyUnseen = false; render() })
        filters.addView(fchip("Sin ver", onlyUnseen) { onlyUnseen = true; render() }, lp(WRAP, WRAP).apply { leftMargin = dp(6) })
        filters.addView(fchip(if (desc) "⇅ Último primero" else "⇅ Primero primero", false) {
            prefs.edit().putBoolean("ep_desc", !desc).apply(); render()
        }, lp(WRAP, WRAP).apply { leftMargin = dp(6) })
        filters.addView(View(this), lp(0, 1, 1f))
        filters.addView(fchip(if (gridMode) "☰ Lista" else "▦ Mosaico", false) {
            prefs.edit().putBoolean("ep_grid", !gridMode).apply(); render()
        })
        body.addView(chipRowOf(filters))

        // Capítulos
        var list = if (onlyUnseen) eps.filter { !it.finished } else eps
        if (desc) list = list.reversed()
        if (list.isEmpty()) {
            body.addView(txt(if (onlyUnseen) "¡Ya viste toda esta temporada!" else "Sin capítulos.", 14f, Col.MUTED).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(30), 0, 0)
            }, lp())
            return
        }
        val shown = list.take(showLimit)
        if (gridMode) {
            val gap = dp(10)
            val cols = if (Tv.on) 4 else 2
            val colW = (screenW - dp(28) - gap * (cols - 1)) / cols
            val wrap = vbox().apply { setPadding(dp(14), dp(6), dp(14), 0) }
            shown.chunked(cols).forEach { pair ->
                val row = hbox().apply { gravity = Gravity.TOP }
                pair.forEachIndexed { i, f -> row.addView(episodeTile(f, colW, f.id == seasonNext?.id), lp(colW, WRAP).apply { if (i > 0) leftMargin = gap }) }
                wrap.addView(row, lp().apply { bottomMargin = dp(12) })
            }
            body.addView(wrap)
        } else {
            shown.forEach { body.addView(episodeRow(it, it.id == seasonNext?.id)) }
        }
        if (list.size > showLimit) {
            body.addView(pill("Mostrar más (${list.size - showLimit})", false) { showLimit += 60; render() }, lp().apply {
                setMargins(dp(14), dp(10), dp(14), 0)
            })
        }
    }

    private fun chipRowOf(row: LinearLayout): View = android.widget.HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(row)
    }

    /** Miniatura del capítulo con número grande, palomita si ya se vio y barra de progreso. */
    private fun episodeThumb(f: MediaFile, w: Int, isNext: Boolean): View {
        val thumb = vbox().apply { background = rounded(Col.CARD2, r(0.8f)); clipToOutline = true }
        val tf = FrameLayout(this)
        val img = ImageView(this)
        tf.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(f.still ?: t.backdrop ?: t.seasons[f.season]?.poster, f.coverPath)
        tf.addView(View(this).apply {
            background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.parseColor("#B3000000"), Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(MATCH, w / 4, Gravity.BOTTOM))
        tf.addView(txt(f.episode.toString(), 20f, Color.WHITE, true).apply { setShadowLayer(6f, 0f, 1f, Color.BLACK) },
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(7), 0, 0, dp(2)) })
        if (f.finished) {
            tf.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_check)
                background = rounded(Col.RED, dpf(10f))
                setColorFilter(Col.ON_ACCENT)
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(5), dp(5), 0) })
        } else if (isNext) {
            tf.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_play)
                background = rounded(Color.parseColor("#99000000"), dpf(18f), dp(2), Color.WHITE)
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
        }
        thumb.addView(tf, LinearLayout.LayoutParams(w, (w * 9f / 16f).toInt()))
        if (!f.finished && f.progress > 0f) thumb.addView(progressBar(f.progress))
        return thumb
    }

    private fun episodeMeta(f: MediaFile, isNext: Boolean): String = listOfNotNull(
        if (f.durationMs > 0) Fmt.duration(f.durationMs) else null,
        if (isNext && f.positionMs > 5000) "quedan ${Fmt.duration((f.durationMs - f.positionMs).coerceAtLeast(0))}" else null,
        f.quality.uppercase().ifBlank { null },
        if (f.finished) "Visto" else null,
        if (f.deadSince > 0) "⚠ Link caído" else null
    ).joinToString(" · ")

    private fun episodeRow(f: MediaFile, isNext: Boolean): View {
        val row = hbox().apply {
            gravity = Gravity.TOP
            setPadding(dp(14), dp(10), dp(4), dp(10))
            if (isNext) background = android.graphics.drawable.LayerDrawable(arrayOf(
                android.graphics.drawable.ColorDrawable((Col.TEXT and 0x00FFFFFF) or 0x14000000),
                android.graphics.drawable.ColorDrawable(Col.RED))).apply {
                setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL); setLayerWidth(1, dp(3))
            }
            alpha = if (f.finished && !isNext) 0.6f else 1f
            setOnClickListener { Nav.play(this@TitleActivity, f.id) }
            setOnLongClickListener { Nav.info(this@TitleActivity, f.id); true }
        }
        row.addView(episodeThumb(f, dp(128), isNext), LinearLayout.LayoutParams(dp(128), WRAP))
        val col = vbox().apply { setPadding(dp(12), 0, 0, 0) }
        if (isNext) col.addView(txt(if (f.positionMs > 5000) "CONTINUAR" else "SIGUIENTE", 10f, Col.RED, true).apply { letterSpacing = 0.1f })
        col.addView(txt(f.epName.ifBlank { "Capítulo ${f.episode}" }, 15f, Col.TEXT, true, 2))
        val meta = episodeMeta(f, isNext)
        if (meta.isNotBlank()) col.addView(txt(meta, 12f, Col.MUTED).apply { setPadding(0, dp(3), 0, 0) })
        if (f.epOverview.isNotBlank()) col.addView(txt(f.epOverview, 12f, Col.MUTED, false, 2).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(col, lp(0, WRAP, 1f))
        row.addView(iconButton(R.drawable.ic_info, 40, Col.MUTED) { Nav.info(this, f.id) })
        return row
    }

    private fun episodeTile(f: MediaFile, w: Int, isNext: Boolean): View {
        val box = vbox().apply {
            alpha = if (f.finished && !isNext) 0.6f else 1f
            setOnClickListener { Nav.play(this@TitleActivity, f.id) }
            setOnLongClickListener { Nav.info(this@TitleActivity, f.id); true }
        }
        box.addView(episodeThumb(f, w, isNext), LinearLayout.LayoutParams(w, WRAP))
        box.addView(txt(f.epName.ifBlank { "Capítulo ${f.episode}" }, 13f, if (isNext) Col.RED else Col.TEXT, true, 1)
            .apply { setPadding(0, dp(5), 0, 0) }, LinearLayout.LayoutParams(w, WRAP))
        val meta = episodeMeta(f, isNext)
        if (meta.isNotBlank()) box.addView(txt(meta, 11f, Col.MUTED, false, 1), LinearLayout.LayoutParams(w, WRAP))
        return box
    }

    // ---------- Película: archivos ----------
    private fun movieFiles() {
        val wrap = vbox().apply { setPadding(dp(14), dp(8), dp(14), 0) }
        wrap.addView(txt("Toca para reproducir · mantén presionado para ver la metadata", 12f, Col.MUTED).apply { setPadding(0, 0, 0, dp(8)) })
        Catalog.filesOf(t.id).forEach { f ->
            val row = hbox().apply {
                background = rounded(Col.CARD, r(1.5f))
                setPadding(dp(14), dp(14), dp(6), dp(14))
                setOnClickListener { Nav.play(this@TitleActivity, f.id) }
                setOnLongClickListener { Nav.info(this@TitleActivity, f.id); true }
            }
            row.addView(ImageView(this).apply { setImageResource(R.drawable.ic_play); setColorFilter(Col.RED) },
                LinearLayout.LayoutParams(dp(28), dp(28)))
            val col = vbox().apply { setPadding(dp(14), 0, 0, 0) }
            col.addView(txt(f.fileName.ifBlank { "Archivo" }, 14f, Col.TEXT, true, 2))
            val meta = listOfNotNull(
                f.quality.uppercase().ifBlank { null },
                if (f.durationMs > 0) Fmt.duration(f.durationMs) else null,
                if (f.positionMs > 5000 && !f.finished) "Visto hasta ${Fmt.duration(f.positionMs)}" else null,
                if (f.finished) "Visto" else null
            ).joinToString(" · ")
            if (meta.isNotBlank()) col.addView(txt(meta, 12f, Col.MUTED).apply { setPadding(0, dp(3), 0, 0) })
            row.addView(col, lp(0, WRAP, 1f))
            row.addView(iconButton(R.drawable.ic_info, 40, Col.MUTED) { Nav.info(this, f.id) })
            wrap.addView(row, lp().apply { bottomMargin = dp(10) })
        }
        body.addView(wrap)
    }

    // ---------- Corregir / eliminar ----------
    private fun correctDialog() {
        val scroll = ScrollView(this)
        val box = vbox(18)
        fun field(value: String, hint: String, multi: Boolean = false) = EditText(this).apply {
            setText(value); this.hint = hint; textSize = 14f
            if (multi) { minLines = 3; gravity = Gravity.TOP } else setSingleLine()
        }
        fun label(s: String) = txt(s, 12f, Col.RED, true).apply { setPadding(0, dp(14), 0, 0) }
        val nameEdit = field(t.name, "Nombre")
        val yearEdit = field(if (t.year > 0) t.year.toString() else "", "Año (opcional)").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rSeries = RadioButton(this).apply { text = "Serie"; id = View.generateViewId() }
        val rMovie = RadioButton(this).apply { text = "Película"; id = View.generateViewId() }
        val rAnime = RadioButton(this).apply { text = "Anime"; id = View.generateViewId() }
        group.addView(rSeries); group.addView(rMovie); group.addView(rAnime)
        group.check(if (t.anime) rAnime.id else if (t.kind == Kind.SERIES) rSeries.id else rMovie.id)
        val imdbEdit = field(if (t.ext.startsWith("imdb:")) t.ext.removePrefix("imdb:") else "", "Link o código de IMDb (tt…)")
        val posterEdit = field(t.poster.orEmpty(), "Link de la imagen del póster")
        val ovEdit = field(t.overview, "Sinopsis", multi = true)

        box.addView(nameEdit); box.addView(yearEdit); box.addView(group)
        box.addView(label("¿No lo encuentra? Pega su link de IMDb"))
        box.addView(txt("Abre la serie o película en imdb.com, toca Compartir → Copiar link y pégalo aquí. Busca con ese código en TMDB y TVmaze.", 12f, Col.MUTED))
        box.addView(imdbEdit)
        box.addView(label("O ponlo a mano"))
        box.addView(txt("En Google Imágenes o IMDb mantén presionado el póster → Copiar dirección de imagen.", 12f, Col.MUTED))
        box.addView(posterEdit); box.addView(ovEdit)
        scroll.addView(box)

        fun isAnime() = group.checkedRadioButtonId == rAnime.id
        fun kind() = if (group.checkedRadioButtonId == rMovie.id) Kind.MOVIE
            else if (isAnime() && t.kind == Kind.MOVIE) Kind.MOVIE else Kind.SERIES
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Corregir datos")
            .setView(scroll)
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Guardar a mano") { _, _ ->
                t.name = nameEdit.text.toString().trim().ifBlank { t.name }
                t.year = yearEdit.text.toString().toIntOrNull() ?: 0
                t.kind = kind()
                t.anime = isAnime()
                if (t.anime && "Anime" !in t.genres) t.genres = listOf("Anime") + t.genres
                t.poster = posterEdit.text.toString().trim().takeIf { it.startsWith("http") }
                t.overview = ovEdit.text.toString().trim()
                if (t.ext.isBlank()) t.ext = "manual:" + t.id
                Catalog.save(); render()
                toast("Guardado")
            }
            .setPositiveButton("Buscar") { _, _ ->
                val imdb = imdbEdit.text.toString().trim()
                if (Meta.imdbId(imdb) != null) searchImdb(imdb)
                else search(nameEdit.text.toString().trim(), kind(), yearEdit.text.toString().toIntOrNull() ?: 0, isAnime())
            }
            .show()
    }

    private fun searchImdb(text: String) {
        toast("Buscando por IMDb…")
        scope.launch {
            val r = withContext(Dispatchers.IO) { Meta.findImdb(this@TitleActivity, text) }
            if (r == null) {
                toast("Ese código no está en TMDB ni TVmaze. Usa \"Guardar a mano\" para poner el póster y la sinopsis.")
                return@launch
            }
            apply(r)
        }
    }

    private fun search(q: String, kind: Kind, year: Int, anime: Boolean = false) {
        if (q.isBlank()) return
        toast("Buscando…")
        scope.launch {
            val res = withContext(Dispatchers.IO) { runCatching {
                if (anime) Meta.searchAnime(q, null).ifEmpty { Meta.search(this@TitleActivity, q, kind, year) }
                else Meta.search(this@TitleActivity, q, kind, year)
            }.getOrDefault(emptyList()) }
            if (res.isEmpty()) { toast("No encontré \"$q\". Prueba con el nombre en inglés o pega su link de IMDb en el lápiz."); return@launch }
            val names = res.map { r -> r.name + (if (r.year > 0) " (${r.year})" else "") + (if (r.src == "anilist") " · Anime" else "") + if (r.kind == Kind.SERIES) " · Serie" else " · Película" }
            AlertDialog.Builder(this@TitleActivity, dialogTheme())
                .setTitle("¿Cuál es?")
                .setItems(names.toTypedArray()) { _, i -> apply(res[i]) }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun apply(r: TmdbResult) {
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    Meta.apply(this@TitleActivity, t, r)
                }.isSuccess
            }
            val dup = Catalog.titles().firstOrNull { it.id != t.id && t.ext.isNotBlank() && it.ext == t.ext && it.kind == t.kind }
            if (dup != null) {
                Catalog.merge(t.id, dup.id)
                Catalog.save()
                toast("Unido con \"${dup.name}\" que ya estaba en tu catálogo")
                Nav.title(this@TitleActivity, dup.id)
                finish()
                return@launch
            }
            Catalog.save()
            toast(if (ok) "Datos actualizados" else "No se pudo conectar. Revisa tu internet.")
            render()
        }
    }

    private fun deleteDialog() {
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("¿Quitar \"${t.name}\" del catálogo?")
            .setMessage("Se quitan sus ${Catalog.filesOf(t.id).size} links de la app. Los archivos originales no se tocan.")
            .setPositiveButton("Quitar") { _, _ -> Catalog.deleteTitle(t.id); finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
