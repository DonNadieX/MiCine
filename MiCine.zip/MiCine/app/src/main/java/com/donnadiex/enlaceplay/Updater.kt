package com.donnadiex.enlaceplay

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Release(val code: Int, val name: String, val notes: String, val apkUrl: String, val page: String)

/**
 * Actualizaciones automáticas:
 * GitHub publica cada versión (Releases) y la app revisa si hay una más nueva.
 * El repositorio tiene que ser PÚBLICO para que otras personas puedan descargar.
 */
object Updater {

    const val DEFAULT_REPO = "DonNadieX/MiCine"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    fun repo(ctx: Context) = prefs(ctx).getString("repo_app", DEFAULT_REPO)!!.trim()
    fun setRepo(ctx: Context, r: String) = prefs(ctx).edit().putString("repo_app", r.trim()
        .removePrefix("https://github.com/").removeSuffix("/").removeSuffix(".git")).apply()

    @Suppress("DEPRECATION")
    fun currentCode(ctx: Context): Int = runCatching {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    }.getOrDefault(0)

    fun currentName(ctx: Context): String = runCatching {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    }.getOrDefault("")

    /** Consulta la última versión publicada. null si no hay o no se pudo consultar. */
    fun latest(ctx: Context): Release? {
        val c = URL("https://api.github.com/repos/${repo(ctx)}/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 15_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", USER_AGENT)
        try {
            when (c.responseCode) {
                404 -> error("No hay versiones publicadas en ${repo(ctx)} (o el repositorio es privado)")
                in 200..299 -> {}
                else -> error("GitHub respondió ${c.responseCode}")
            }
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val tag = o.optString("tag_name")
            val code = Regex("\\d+").find(tag)?.value?.toIntOrNull() ?: return null
            val assets = o.optJSONArray("assets") ?: return null
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }
                .firstOrNull { it.optString("name").endsWith(".apk") }?.optString("browser_download_url") ?: return null
            return Release(code, o.optString("name").ifBlank { tag }, o.optString("body"), apk, o.optString("html_url"))
        } finally {
            c.disconnect()
        }
    }

    /** Al abrir la app (máximo cada 12 horas): si hay versión nueva, pregunta si instalarla. */
    suspend fun checkOnOpen(activity: Activity) {
        val p = prefs(activity)
        if (System.currentTimeMillis() - p.getLong("upd_revisado", 0) < 12 * 60 * 60 * 1000L) return
        val r = withContext(Dispatchers.IO) { runCatching { latest(activity) }.getOrNull() } ?: return
        p.edit().putLong("upd_revisado", System.currentTimeMillis()).apply()
        if (r.code > currentCode(activity) && r.code != p.getInt("upd_omitida", 0)) offer(activity, r, allowSkip = true)
    }

    fun offer(activity: Activity, r: Release, allowSkip: Boolean) {
        if (activity.isFinishing) return
        val notes = r.notes.lines().filter { it.isNotBlank() && !it.startsWith("Add files via upload") }.take(8).joinToString("\n")
        val b = AlertDialog.Builder(activity, if (Themes.cur.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
            else android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Hay una versión nueva: ${r.name}")
            .setMessage((if (notes.isNotBlank()) "$notes\n\n" else "") + "Tienes la ${currentName(activity)}. Tu catálogo no se borra al actualizar.")
            .setPositiveButton("Actualizar") { _, _ -> download(activity, r) }
            .setNegativeButton("Después", null)
        if (allowSkip) b.setNeutralButton("Omitir esta") { _, _ -> prefs(activity).edit().putInt("upd_omitida", r.code).apply() }
        b.show()
    }

    /** Descarga el APK y abre el instalador. */
    fun download(activity: Activity, r: Release) {
        // Android 8+: hace falta permitir "instalar apps desconocidas" para Mi Cine una vez.
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(activity, "Activa \"Permitir de esta fuente\" para Mi Cine y vuelve a tocar Actualizar.", Toast.LENGTH_LONG).show()
            runCatching {
                activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
            }
            return
        }
        val dm = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        File(dir, "MiCine.apk").delete()
        val id = dm.enqueue(DownloadManager.Request(Uri.parse(r.apkUrl))
            .setTitle("Mi Cine ${r.name}")
            .setDescription("Descargando actualización")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, "MiCine.apk"))
        prefs(activity).edit().putLong("upd_descarga", id).apply()
        Toast.makeText(activity, "Descargando la actualización…", Toast.LENGTH_SHORT).show()
        if (activity is BaseActivity) activity.scope.launch { waitAndInstall(activity, dm, id, r) }
    }

    private suspend fun waitAndInstall(activity: Activity, dm: DownloadManager, id: Long, r: Release) {
        repeat(600) {   // hasta 10 minutos
            delay(1000)
            val status = withContext(Dispatchers.IO) {
                dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) else -1
                } ?: -1
            }
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> { install(activity, dm, id, r); return }
                DownloadManager.STATUS_FAILED, -1 -> {
                    Toast.makeText(activity, "No se pudo descargar. Abriendo la página de descarga…", Toast.LENGTH_LONG).show()
                    runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.page))) }
                    return
                }
            }
        }
    }

    private fun install(activity: Activity, dm: DownloadManager, id: Long, r: Release) {
        val uri = dm.getUriForDownloadedFile(id)
        if (uri == null) {
            runCatching { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.page))) }
            return
        }
        runCatching {
            activity.startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure {
            Toast.makeText(activity, "Abre la notificación de descarga para instalar.", Toast.LENGTH_LONG).show()
        }
    }

    /** Link para que alguien descargue la app por primera vez. */
    fun downloadPage(ctx: Context) = "https://github.com/${repo(ctx)}/releases/latest"
}
