package com.donnadiex.enlaceplay

import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.net.ssl.SSLException

/**
 * Cuando un link no se reproduce, averigua POR QUÉ (fecha mal, sin internet, link borrado…)
 * y, si el link sí funciona, ofrece un "plan B": la app lo baja ella misma y se lo pasa
 * al reproductor por dentro (útil en proyectores que no abren bien conexiones seguras).
 */
object LinkDoctor {

    sealed class Result {
        object Works : Result()
        class Problem(val message: String) : Result()
    }

    private fun clockLooksWrong(): Boolean = Calendar.getInstance().get(Calendar.YEAR) < 2026

    private fun today(): String = SimpleDateFormat("d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "MX")).format(java.util.Date())

    /** Bloquea: llamar desde un hilo de fondo. */
    fun check(url: String): Result {
        if (clockLooksWrong()) return Result.Problem(
            "La fecha de este aparato está mal (dice: ${today()}). Con la fecha mal no se pueden abrir links seguros.\n\n" +
                "Ve a Ajustes de Android → Fecha y hora y activa \"automática\" (o ponla bien a mano)."
        )
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Range", "bytes=0-1")
            try {
                when (val code = c.responseCode) {
                    in 200..299 -> Result.Works
                    403 -> Result.Problem("El servidor no dio permiso (403). Si es de tu bot, pídele el link otra vez con /app y actualiza en Ajustes.")
                    404, 410 -> Result.Problem("El video ya no existe en el servidor (fue borrado o el link cambió).")
                    in 500..599 -> Result.Problem("El servidor tiene un problema ($code). Si es tu bot, revisa que Render diga \"Live\" o espera un momento.")
                    else -> Result.Problem("El servidor respondió con un error ($code).")
                }
            } finally { runCatching { c.inputStream.close() }; c.disconnect() }
        } catch (e: UnknownHostException) {
            Result.Problem("No hay internet en este aparato, o no encuentra el servidor. Revisa el Wi-Fi.")
        } catch (e: SocketTimeoutException) {
            Result.Problem("El servidor tardó demasiado en responder. Si es tu bot, puede estar despertando: espera 1 minuto y toca Reintentar.")
        } catch (e: SSLException) {
            Result.Problem("No se pudo abrir la conexión segura (https). Revisa que la fecha y hora de este aparato estén bien " +
                "(Ajustes de Android → Fecha y hora). Fecha actual: ${today()}.")
        } catch (e: Exception) {
            val cause = generateSequence<Throwable>(e) { it.cause }.firstOrNull { it is java.security.cert.CertificateException }
            if (cause != null) Result.Problem("El certificado del servidor no es válido para este aparato. Revisa la fecha y hora (dice: ${today()}).")
            else Result.Problem("No se pudo conectar: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ---------------- Plan B: puente local ----------------
    private var bridge: MiniHttp? = null
    private var port = 0

    /** http://127.0.0.1:<puerto>/p?u=<link>  → el reproductor lee de aquí y la app trae el video. */
    fun bridged(url: String): String {
        if (bridge?.isRunning != true) {
            port = 18000 + (Math.random() * 1500).toInt()
            bridge = MiniHttp(port) { req, res -> relay(req, res) }.also { it.start() }
        }
        return "http://127.0.0.1:$port/p?u=" + URLEncoder.encode(url, "UTF-8")
    }

    fun isBridged(url: String) = url.startsWith("http://127.0.0.1:")

    private fun relay(req: MiniHttp.Request, res: MiniHttp.Response) {
        val target = req.query["u"] ?: run { res.text(400, ""); return }
        val c = URL(target).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.instanceFollowRedirects = true
        c.requestMethod = if (req.method == "HEAD") "HEAD" else "GET"
        c.setRequestProperty("User-Agent", USER_AGENT)
        req.header("range")?.let { c.setRequestProperty("Range", it) }
        val code = c.responseCode
        val headers = mutableMapOf<String, String>()
        listOf("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges").forEach { k ->
            c.getHeaderField(k)?.let { headers[k] = it }
        }
        if (!headers.containsKey("Accept-Ranges")) headers["Accept-Ranges"] = "bytes"
        val body = if (code >= 400) c.errorStream else c.inputStream
        try { res.relay(code, headers, body) } finally { c.disconnect() }
    }
}
