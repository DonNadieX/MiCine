package com.donnadiex.enlaceplay

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Datos gratis SIN clave ni cuenta:
 *  - Series:    TVmaze  (api.tvmaze.com)   → póster, sinopsis, géneros, episodios con imagen
 *  - Películas: iTunes  (itunes.apple.com) → póster HD, sinopsis, género, año (tienda de México)
 */
object FreeMeta {

    private var lastItunes = 0L

    private fun getText(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Accept", "application/json")
        return try {
            when (c.responseCode) {
                in 200..299 -> c.inputStream.bufferedReader().use { it.readText() }
                429 -> { Thread.sleep(3_000); null }
                else -> null
            }
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** iTunes permite ~20 consultas por minuto: espera lo necesario entre cada una. */
    @Synchronized
    private fun itunes(url: String): JSONObject? {
        val wait = 3_100 - (System.currentTimeMillis() - lastItunes)
        if (wait > 0) Thread.sleep(wait)
        lastItunes = System.currentTimeMillis()
        return getText(url)?.let { runCatching { JSONObject(it) }.getOrNull() }
    }

    fun stripHtml(s: String): String =
        s.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .trim()

    private val GENRES = mapOf(
        "Drama" to "Drama", "Comedy" to "Comedia", "Action" to "Acción", "Adventure" to "Aventura",
        "Crime" to "Crimen", "Thriller" to "Suspenso", "Horror" to "Terror", "Science-Fiction" to "Ciencia ficción",
        "Fantasy" to "Fantasía", "Romance" to "Romance", "Mystery" to "Misterio", "Family" to "Familia",
        "Children" to "Infantil", "Anime" to "Anime", "Medical" to "Médica", "Legal" to "Legal",
        "Supernatural" to "Sobrenatural", "War" to "Bélica", "Western" to "Western", "History" to "Historia",
        "Music" to "Música", "Sports" to "Deportes", "Espionage" to "Espionaje", "Food" to "Cocina",
        "Nature" to "Naturaleza", "Travel" to "Viajes", "DIY" to "Hazlo tú mismo"
    )

    private fun statusEs(s: String) = when (s) {
        "Running" -> "En emisión"
        "Ended" -> "Finalizada"
        "To Be Determined" -> "Por confirmar"
        "In Development" -> "En desarrollo"
        else -> s
    }

    // ---------------- Búsqueda ----------------
    fun search(query: String, kind: Kind?, year: Int = 0): List<TmdbResult> {
        val out = mutableListOf<TmdbResult>()
        if (kind != Kind.MOVIE) out += searchShows(query, year)
        if (kind != Kind.SERIES) out += searchMovies(query, year)
        return out
    }

    private fun searchShows(query: String, year: Int): List<TmdbResult> {
        val txt = getText("https://api.tvmaze.com/search/shows?q=${enc(query)}") ?: return emptyList()
        val arr = runCatching { JSONArray(txt) }.getOrNull() ?: return emptyList()
        val list = (0 until minOf(arr.length(), 10)).map { i ->
            val s = arr.getJSONObject(i).getJSONObject("show")
            TmdbResult(
                id = s.optInt("id"),
                kind = Kind.SERIES,
                name = s.optString("name"),
                year = s.optString("premiered").take(4).toIntOrNull() ?: 0,
                poster = s.optJSONObject("image")?.optString("original")?.ifBlank { null },
                overview = stripHtml(s.optString("summary")),
                src = "tvmaze"
            )
        }
        return if (year > 0) list.sortedByDescending { it.year == year } else list
    }

    private fun searchMovies(query: String, year: Int): List<TmdbResult> {
        val o = itunes("https://itunes.apple.com/search?term=${enc(query)}&media=movie&entity=movie&country=mx&limit=10")
            ?: return emptyList()
        val arr = o.optJSONArray("results") ?: return emptyList()
        val list = (0 until arr.length()).map { i ->
            val m = arr.getJSONObject(i)
            TmdbResult(
                id = m.optLong("trackId").toInt(),
                kind = Kind.MOVIE,
                name = m.optString("trackName"),
                year = m.optString("releaseDate").take(4).toIntOrNull() ?: 0,
                poster = bigArt(m.optString("artworkUrl100")),
                overview = m.optString("longDescription"),
                src = "itunes"
            )
        }
        return if (year > 0) list.sortedByDescending { it.year == year } else list
    }

    /** Las portadas de iTunes vienen en 100x100; se pide la versión grande. */
    private fun bigArt(u: String?): String? =
        u?.takeIf { it.isNotBlank() }?.replace(Regex("/\\d+x\\d+bb"), "/600x900bb")

    // ---------------- Detalles ----------------
    fun apply(t: Title, r: TmdbResult) {
        if (r.kind == Kind.SERIES) applyShow(t, r.id) else applyMovie(t, r)
    }

    private fun applyShow(t: Title, id: Int) {
        val txt = getText("https://api.tvmaze.com/shows/$id?embed=episodes") ?: error("TVmaze no respondió")
        val s = JSONObject(txt)
        t.kind = Kind.SERIES
        t.tmdbId = 0
        t.ext = "tvmaze:$id"
        t.name = s.optString("name").ifBlank { t.name }
        t.year = s.optString("premiered").take(4).toIntOrNull() ?: t.year
        t.overview = stripHtml(s.optString("summary"))
        s.optJSONObject("image")?.optString("original")?.takeIf { it.isNotBlank() }?.let { t.poster = it }
        val g = s.optJSONArray("genres")
        if (g != null) t.genres = (0 until g.length()).map { GENRES[g.getString(it)] ?: g.getString(it) }
        t.rating = s.optJSONObject("rating")?.optDouble("average", 0.0)?.takeIf { !it.isNaN() } ?: 0.0
        t.status = statusEs(s.optString("status"))

        val eps = s.optJSONObject("_embedded")?.optJSONArray("episodes") ?: JSONArray()
        t.totalEpisodes = eps.length()
        val bySE = mutableMapOf<Pair<Int, Int>, JSONObject>()
        for (i in 0 until eps.length()) {
            val e = eps.getJSONObject(i)
            bySE[e.optInt("season") to e.optInt("number")] = e
        }
        t.totalSeasons = bySE.keys.map { it.first }.distinct().size
        // Fondo para la ficha: la imagen del primer episodio que tenga.
        if (t.backdrop == null) {
            (0 until eps.length()).firstNotNullOfOrNull { i ->
                eps.getJSONObject(i).optJSONObject("image")?.optString("original")?.ifBlank { null }
            }?.let { t.backdrop = it }
        }
        Catalog.filesOf(t.id).forEach { f ->
            val e = bySE[f.season to f.episode] ?: return@forEach
            e.optString("name").takeIf { it.isNotBlank() }?.let { f.epName = it }
            f.epOverview = stripHtml(e.optString("summary"))
            e.optJSONObject("image")?.optString("medium")?.takeIf { it.isNotBlank() }?.let { f.still = it }
            val rt = e.optInt("runtime")
            if (f.durationMs == 0L && rt > 0) f.durationMs = rt * 60_000L
        }
    }

    private fun applyMovie(t: Title, r: TmdbResult) {
        // Volvemos a pedir por id para tener la ficha completa.
        val o = itunes("https://itunes.apple.com/lookup?id=${r.id}&country=mx")
        val m = o?.optJSONArray("results")?.optJSONObject(0)
        t.kind = Kind.MOVIE
        t.tmdbId = 0
        t.ext = "itunes:${r.id}"
        t.name = m?.optString("trackName")?.ifBlank { null } ?: r.name.ifBlank { t.name }
        t.year = (m?.optString("releaseDate") ?: "").take(4).toIntOrNull() ?: r.year.takeIf { it > 0 } ?: t.year
        t.overview = m?.optString("longDescription")?.ifBlank { null } ?: r.overview
        (bigArt(m?.optString("artworkUrl100")) ?: r.poster)?.let { t.poster = it }
        m?.optString("primaryGenreName")?.takeIf { it.isNotBlank() }?.let { t.genres = listOf(it) }
        m?.optString("contentAdvisoryRating")?.takeIf { it.isNotBlank() }?.let { t.status = "Clasificación $it" }
        m?.optLong("trackTimeMillis")?.takeIf { it > 0 }?.let { ms ->
            Catalog.filesOf(t.id).forEach { f -> if (f.durationMs == 0L) f.durationMs = ms }
        }
    }

    /** Busca solo y aplica el mejor resultado. */
    fun autoMatch(t: Title): Boolean {
        val results = search(t.name, t.kind, t.year)
        val key = NameParser.key(t.name)
        val best = results.firstOrNull { NameParser.key(it.name) == key && (t.year == 0 || it.year == t.year) }
            ?: results.firstOrNull { NameParser.key(it.name) == key }
            ?: results.firstOrNull { NameParser.key(it.name).startsWith(key) || key.startsWith(NameParser.key(it.name)) }
            ?: results.firstOrNull()
            ?: return false
        apply(t, best)
        return true
    }
}

/** Decide la fuente: TMDB si hay clave, si no TVmaze + iTunes (gratis, sin clave). */
object Meta {
    fun usingTmdb(ctx: android.content.Context) = Tmdb.hasKey(ctx)

    fun sourceName(ctx: android.content.Context) =
        if (usingTmdb(ctx)) "TMDB" else "TVmaze (series) e iTunes (películas)"

    fun search(ctx: android.content.Context, q: String, kind: Kind?, year: Int): List<TmdbResult> =
        if (usingTmdb(ctx)) Tmdb.search(ctx, q, kind, year) else FreeMeta.search(q, kind, year)

    fun apply(ctx: android.content.Context, t: Title, r: TmdbResult) {
        if (r.src == "tmdb") {
            Tmdb.applyDetails(ctx, t, r.id, r.kind)
            t.ext = "tmdb:${r.id}"
            Tmdb.fillEpisodes(ctx, t)
        } else FreeMeta.apply(t, r)
    }

    fun autoMatch(ctx: android.content.Context, t: Title): Boolean =
        if (usingTmdb(ctx)) Tmdb.autoMatch(ctx, t).also { if (it) t.ext = "tmdb:${t.tmdbId}" }
        else FreeMeta.autoMatch(t)

    /** Vuelve a bajar los datos del título (por ejemplo, episodios nuevos). */
    fun refresh(ctx: android.content.Context, t: Title): Boolean {
        val src = t.ext.substringBefore(':', "")
        val id = t.ext.substringAfter(':', "").toIntOrNull() ?: 0
        return when {
            src == "tmdb" && usingTmdb(ctx) -> { Tmdb.applyDetails(ctx, t, id, t.kind); Tmdb.fillEpisodes(ctx, t); true }
            src == "tvmaze" || src == "itunes" ->
                runCatching { FreeMeta.apply(t, TmdbResult(id, t.kind, t.name, t.year, null, "", src)); true }.getOrDefault(false)
            else -> autoMatch(ctx, t)
        }
    }

    /** Une títulos que la fuente identificó como el mismo. */
    fun mergeDuplicates() {
        Catalog.titles().filter { it.ext.isNotBlank() }.groupBy { "${it.kind}-${it.ext}" }.values
            .filter { it.size > 1 }
            .forEach { same -> same.drop(1).forEach { Catalog.merge(it.id, same.first().id) } }
    }
}
