package com.donnadiex.enlaceplay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class LocalFolder(val uri: String, val name: String, val removable: Boolean)

/**
 * Contenido guardado en el teléfono, tarjeta SD o memoria USB (OTG).
 * Usa el selector de archivos de Android: la app solo ve las carpetas que tú eliges.
 */
object Local {

    val VIDEO_EXT = setOf(
        "mkv", "mp4", "m4v", "avi", "webm", "mov", "ts", "m2ts", "mts", "flv", "wmv",
        "3gp", "mpg", "mpeg", "vob", "ogv", "divx", "rmvb"
    )

    private val SEASON_DIR = Regex("^(?:temporada|temp|season|serie|t|s)\\s*[ ._-]?\\s*(\\d{1,2})\\b", RegexOption.IGNORE_CASE)
    private val EP_NUM = Regex("^(?:e|ep|cap|capitulo|capítulo|episodio|episode)?\\s*[ ._-]?\\s*(\\d{1,3})(?!\\d)", RegexOption.IGNORE_CASE)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    // ---------------- Carpetas guardadas ----------------
    fun folders(ctx: Context): List<String> = runCatching {
        val arr = JSONArray(prefs(ctx).getString("carpetas", "[]"))
        (0 until arr.length()).map { arr.getString(it) }
    }.getOrDefault(emptyList())

    fun folderInfo(ctx: Context, uri: String): LocalFolder {
        val u = Uri.parse(uri)
        val docId = runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrDefault("")
        val volume = docId.substringBefore(':')
        val path = docId.substringAfter(':', "")
        val removable = u.authority == "com.android.externalstorage.documents" && volume != "primary" && volume.isNotBlank()
        val where = if (removable) "SD / USB" else "Memoria interna"
        return LocalFolder(uri, "$where › ${path.ifBlank { "(raíz)" }}", removable)
    }

    fun addFolder(ctx: Context, uri: Uri) {
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val list = folders(ctx).toMutableList()
        if (uri.toString() !in list) list.add(uri.toString())
        prefs(ctx).edit().putString("carpetas", JSONArray(list).toString()).apply()
    }

    fun removeFolder(ctx: Context, uri: String) {
        runCatching {
            ctx.contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        prefs(ctx).edit().putString("carpetas", JSONArray(folders(ctx).filter { it != uri }).toString()).apply()
    }

    fun autoScanEnabled(ctx: Context) = prefs(ctx).getBoolean("autoescaneo", true)
    fun setAutoScan(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("autoescaneo", on).apply()

    /** Permiso para archivos sueltos elegidos uno por uno. */
    fun keepFile(ctx: Context, uri: Uri) {
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    // ---------------- Estado ----------------
    fun isLocal(url: String) = url.startsWith("content://") || url.startsWith("file://")

    /** ¿La carpeta (o la memoria USB donde está) está conectada ahora mismo? */
    fun isFolderAvailable(ctx: Context, uri: String): Boolean = runCatching {
        val u = Uri.parse(uri)
        val doc = DocumentsContract.buildDocumentUriUsingTree(u, DocumentsContract.getTreeDocumentId(u))
        ctx.contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)
            ?.use { it.moveToFirst() } ?: false
    }.getOrDefault(false)

    /** ¿El archivo sigue existiendo y se puede leer? */
    fun isFileAvailable(ctx: Context, url: String): Boolean = runCatching {
        ctx.contentResolver.query(Uri.parse(url), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { it.moveToFirst() } ?: false
    }.getOrDefault(false)

    fun whereLabel(url: String): String {
        if (RemoteLib.isRemote(url)) return "Mi celular"
        if (!isLocal(url)) return "Internet"
        if (MediaScan.isMediaUri(url)) return MediaScan.volumeOf(url).let { if (it == "external" || it == "external_primary") "Memoria interna" else "SD / USB" }
        val docId = runCatching { DocumentsContract.getDocumentId(Uri.parse(url)) }.getOrDefault("")
        val vol = docId.substringBefore(':')
        return if (vol.isNotBlank() && vol != "primary" && docId.contains(':')) "SD / USB" else "Memoria interna"
    }

    // ---------------- Escaneo ----------------
    /** Recorre una carpeta y sus subcarpetas (hasta 6 niveles) buscando videos. */
    fun scanFolder(ctx: Context, treeUri: String): List<ImportLine> {
        val tree = Uri.parse(treeUri)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val out = mutableListOf<ImportLine>()
        fun walk(docId: String, path: List<String>, depth: Int) {
            if (depth > 6) return
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (name.startsWith(".")) continue
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        walk(id, path + name, depth + 1)
                    } else {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        val isVideo = ext in VIDEO_EXT || mime.startsWith("video/")
                        if (!isVideo || name.lowercase().contains("sample")) continue
                        val url = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                        out.add(ImportLine(url, labelFor(path, name)))
                    }
                }
            }
        }
        val rootName = rootId.substringAfter(':', "").substringAfterLast('/')
        walk(rootId, if (rootName.isBlank()) emptyList() else listOf(rootName), 0)
        return out
    }

    /**
     * Arma un nombre que el lector entienda usando también las carpetas:
     *   Lucifer/Temporada 1/03.mkv          -> "Lucifer S01E03"
     *   Lucifer/Season 2/Episodio 5.mp4     -> "Lucifer S02E05"
     *   Series/Dark/S01E02.mkv              -> "Dark S01E02"
     *   Lucifer S01E03 1080p.mkv            -> se deja igual
     */
    fun labelFor(folders: List<String>, fileName: String): String {
        val base = fileName.substringBeforeLast('.')
        val p = NameParser.parse(fileName)
        val nameKey = NameParser.key(p.name)
        val nameIsReal = p.hasName
        val animeFolder = folders.any { NameParser.key(it).split(' ').any { w -> w == "anime" || w == "animes" } }
        val tag = if (animeFolder && !p.anime) "[Anime] " else ""
        if (p.isSeries && nameIsReal) return tag + fileName

        // Buscar carpeta de temporada desde la más cercana
        var seasonIdx = -1
        var season = 0
        for (i in folders.indices.reversed()) {
            val m = SEASON_DIR.find(folders[i].trim())
            if (m != null) { seasonIdx = i; season = m.groupValues[1].toInt(); break }
        }
        val seriesName = when {
            seasonIdx > 0 -> folders[seasonIdx - 1]
            seasonIdx == -1 && folders.isNotEmpty() -> folders.last()
            else -> ""
        }.let { NameParser.parse(it).let { f -> if (f.year > 0) "${f.name} (${f.year})" else f.name } }

        val episode = if (p.isSeries) p.episode else EP_NUM.find(base.trim())?.groupValues?.get(1)?.toIntOrNull() ?: 0
        if (p.isSeries) season = if (seasonIdx >= 0 && p.season <= 1) season.coerceAtLeast(p.season) else p.season

        return when {
            seriesName.isNotBlank() && episode > 0 && (seasonIdx >= 0 || p.isSeries || base.trim().matches(Regex("^\\d{1,3}.*"))) ->
                tag + String.format("%s S%02dE%02d %s", seriesName, season.coerceAtLeast(1), episode, p.quality).trim()
            // Película dentro de su propia carpeta: "Avatar (2009)/avatar.mkv" -> usa el año de la carpeta
            !p.isSeries && p.year == 0 && folders.isNotEmpty() &&
                NameParser.parse(folders.last()).let { it.year > 0 && NameParser.key(it.name) == nameKey } ->
                tag + "${folders.last()} ${p.quality}".trim()
            else -> tag + fileName
        }
    }

    /** Escanea todas tus carpetas y agrega lo nuevo. Devuelve cuántos archivos nuevos encontró. */
    suspend fun scanAll(ctx: Context, onProgress: suspend (Int, Int, String) -> Unit): Int {
        Catalog.init(ctx)
        val found = withContext(Dispatchers.IO) {
            folders(ctx).filter { isFolderAvailable(ctx, it) }.flatMap { runCatching { scanFolder(ctx, it) }.getOrDefault(emptyList()) }
        }
        val fresh = found.filter { Catalog.fileByUrl(it.url) == null }
        if (fresh.isEmpty()) return 0
        Importer.runItems(ctx, fresh, onProgress)
        return fresh.size
    }

    /**
     * Limpieza tipo Kodi: quita de la biblioteca los archivos locales que ya no existen.
     * Solo revisa carpetas CONECTADAS, para no borrar lo de una USB desconectada.
     */
    fun cleanMissing(ctx: Context): Int {
        val availableRoots = folders(ctx).filter { isFolderAvailable(ctx, it) }.map {
            runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(it)) }.getOrDefault("")
        }
        var removed = 0
        Catalog.titles().flatMap { Catalog.filesOf(it.id) }.filter { isLocal(it.url) }.forEach { f ->
            val docId = runCatching { DocumentsContract.getDocumentId(Uri.parse(f.url)) }.getOrDefault("")
            val volume = docId.substringBefore(':')
            val inConnected = availableRoots.any { it.substringBefore(':') == volume }
            if (inConnected && !isFileAvailable(ctx, f.url)) {
                Catalog.deleteFile(f.id)
                removed++
            }
        }
        return removed
    }
}
