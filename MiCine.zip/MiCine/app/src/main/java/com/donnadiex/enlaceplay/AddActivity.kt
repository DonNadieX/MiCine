package com.donnadiex.enlaceplay

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddActivity : BaseActivity() {

    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var go: TextView
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), dp(2)) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        top.addView(txt("Agregar contenido", 18f, Col.TEXT, true), lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this)
        val body = vbox(16)

        // ---- Desde el teléfono / USB ----
        body.addView(heading("Desde tu celular o USB", 16f, Col.RED))
        body.addView(txt("Elige una carpeta (memoria interna, tarjeta SD o memoria USB conectada con OTG). La app busca videos también dentro de sus subcarpetas, y se acuerda de ella para encontrar archivos nuevos.", 13f, Col.MUTED)
            .apply { setLineSpacing(0f, 1.2f); setPadding(0, dp(4), 0, dp(10)) })
        val lrow = hbox()
        lrow.addView(pill("Elegir carpeta", true, R.drawable.ic_folder) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_TREE)
        }, lp(0, WRAP, 1f))
        lrow.addView(pill("Archivos sueltos", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("video/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_FILES)
        }, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        body.addView(lrow, lp())
        body.addView(txt("Consejo: si tus series están en carpetas como  Lucifer/Temporada 1/01.mkv  la app entiende la serie, temporada y capítulo solita.", 12f, Col.DIM)
            .apply { setPadding(0, dp(8), 0, dp(4)) })
        body.addView(android.view.View(this).apply { setBackgroundColor(Col.LINE) }, lp(MATCH, dp(1)).apply { setMargins(0, dp(16), 0, dp(16)) })

        // ---- Links ----
        body.addView(heading("Desde links", 16f, Col.RED).apply { setPadding(0, 0, 0, dp(4)) })
        body.addView(txt("Pega uno o muchos links, uno por línea. La app lee el nombre de cada archivo y arma las series (con temporadas y episodios) y las películas.", 14f, Col.MUTED)
            .apply { setLineSpacing(0f, 1.2f) })

        body.addView(txt(
            "Ejemplos que entiende:\n" +
                "https://tuservidor/dl/abc123\n" +
                "Dark S01E03 - https://tuservidor/dl/abc123\n" +
                "Dark S01E04\nhttps://tuservidor/dl/def456\n" +
                "Inception (2010) | https://tuservidor/dl/xyz",
            12f, Col.SOFT
        ).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            background = rounded(Col.CARD, r(1.2f))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }, lp().apply { topMargin = dp(12) })

        body.addView(txt("Si el link no trae el nombre del archivo, escribe el nombre antes del link o en la línea de arriba.", 12f, Col.DIM)
            .apply { setPadding(0, dp(8), 0, 0) })

        input = EditText(this).apply {
            hint = "Pega aquí tus links…"
            setHintTextColor(Col.DIM)
            setTextColor(Col.TEXT)
            textSize = 13f
            gravity = Gravity.TOP
            minLines = 8
            background = rounded(Col.CARD2, r(1.2f), dp(1), Col.LINE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setText(intent.getStringExtra("text").orEmpty())
        }
        body.addView(input, lp().apply { topMargin = dp(14) })

        val row = hbox().apply { setPadding(0, dp(12), 0, 0) }
        row.addView(pill("Pegar", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!clip.isNullOrBlank()) {
                val cur = input.text.toString()
                input.setText(if (cur.isBlank()) clip else cur.trimEnd() + "\n" + clip)
            }
        }, lp(0, WRAP, 1f))
        go = pill("Agregar al catálogo", true, R.drawable.ic_add) { start() }
        row.addView(go, lp(0, WRAP, 2f).apply { leftMargin = dp(10) })
        body.addView(row, lp())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            max = 100
        }
        body.addView(progress, lp().apply { topMargin = dp(16) })
        status = txt("", 13f, Col.MUTED)
        body.addView(status, lp().apply { topMargin = dp(6) })

        body.addView(txt("Portadas y sinopsis desde: ${Meta.sourceName(this)}", 12f, Col.DIM)
            .apply { setPadding(0, dp(14), 0, 0) })

        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    private val REQ_TREE = 21
    private val REQ_FILES = 22

    @Deprecated("API de Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null || running) return
        when (requestCode) {
            REQ_TREE -> {
                val uri = data.data ?: return
                Local.addFolder(this, uri)
                status.text = "Buscando videos en ${Local.folderInfo(this, uri.toString()).name}…"
                importLocal { Local.scanFolder(applicationContext, uri.toString()) }
            }
            REQ_FILES -> {
                val uris = mutableListOf<Uri>()
                data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
                data.data?.let { if (it !in uris) uris.add(it) }
                uris.forEach { Local.keepFile(this, it) }
                importLocal {
                    uris.map { u ->
                        val name = runCatching { Analyzer.localHeaders(applicationContext, u.toString()).fileName }.getOrNull()
                        ImportLine(u.toString(), name ?: "Video")
                    }
                }
            }
        }
    }

    private fun importLocal(find: () -> List<ImportLine>) {
        running = true
        go.alpha = 0.5f
        progress.visibility = View.VISIBLE
        progress.progress = 0
        scope.launch {
            val r = runCatching {
                val items = withContext(Dispatchers.IO) { find() }
                if (items.isEmpty()) error("No encontré videos ahí.")
                status.text = "Encontré ${items.size} videos. Acomodando…"
                Importer.runItems(this@AddActivity, items) { done, total, msg ->
                    progress.progress = if (total > 0) done * 100 / total else 0
                    status.text = "$done / $total  ·  $msg"
                }
            }
            finishRun(r)
        }
    }

    private fun finishRun(r: Result<ImportReport>) {
        running = false
        go.alpha = 1f
        progress.visibility = View.GONE
        r.onSuccess { rep ->
            input.setText("")
            status.setTextColor(Col.TEXT)
            status.text = buildString {
                append("Listo: ${rep.added} archivos agregados")
                if (rep.newTitles > 0) append(" · ${rep.newTitles} títulos nuevos")
                if (rep.matched > 0) append(" · ${rep.matched} con portada y sinopsis")
                if (rep.duplicated > 0) append("\n${rep.duplicated} ya estaban en tu catálogo")
                if (rep.errors.isNotEmpty()) append("\n\nAvisos:\n" + rep.errors.take(5).joinToString("\n"))
            }
            showDone()
            // Si compartes tu lista, se publica sola con lo nuevo.
            scope.launch { withContext(Dispatchers.IO) { runCatching { Share.publishIfChanged(applicationContext) } } }
        }.onFailure { status.setTextColor(Col.RED); status.text = it.message ?: "Error" }
    }

    private fun start() {
        if (running) return
        val text = input.text.toString()
        val n = Importer.parseLines(text).size
        if (n == 0) { status.setTextColor(Col.RED); status.text = "No encontré links (deben empezar con http:// o https://)."; return }
        status.setTextColor(Col.MUTED)
        running = true
        go.alpha = 0.5f
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "Procesando $n links…"
        scope.launch {
            val r = runCatching {
                Importer.run(this@AddActivity, text) { done, total, msg ->
                    progress.progress = if (total > 0) done * 100 / total else 0
                    status.text = "$done / $total  ·  $msg"
                }
            }
            finishRun(r)
        }
    }

    private var doneShown = false
    private fun showDone() {
        if (doneShown) return
        doneShown = true
        val parent = status.parent as LinearLayout
        parent.addView(pill("Ver mi catálogo", true) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        }, lp().apply { topMargin = dp(16) })
    }
}
