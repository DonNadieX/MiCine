package com.donnadiex.enlaceplay

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Arranque de la app:
 *  - Caché de imágenes con límite (no llena tu memoria con pósters).
 *  - En celulares con poca RAM usa imágenes más ligeras.
 *  - Guarda el último error para que puedas enviarlo y se arregle.
 */
class App : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        Themes.load(this)
        Catalog.init(this)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) runCatching { coil.Coil.imageLoader(this).memoryCache?.clear() }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching { coil.Coil.imageLoader(this).memoryCache?.clear() }
    }

    override fun newImageLoader(): ImageLoader {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val lowRam = am.isLowRamDevice || am.memoryClass <= 192 || Tv.enabled(this)
        val mb = ImageCache.limitMb(this)
        return ImageLoader.Builder(this)
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(if (lowRam) 0.12 else 0.2).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(ImageCache.dir(this))
                    .maxSizeBytes(mb * 1024L * 1024L)
                    .build()
            }
            .components { add(LanImageInterceptor()) }   // pósters desde el celular cuando no hay internet
            .allowRgb565(lowRam)
            .crossfade(!lowRam)
            .respectCacheHeaders(false)   // los pósters casi nunca cambian: los guarda aunque el servidor diga lo contrario
            .build()
    }
}

object ImageCache {
    fun dir(ctx: Context): File = File(ctx.cacheDir, "imagenes")
    fun limitMb(ctx: Context): Int = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getInt("cache_mb", 250)
    fun setLimitMb(ctx: Context, mb: Int) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putInt("cache_mb", mb).apply()

    fun sizeBytes(ctx: Context): Long = dir(ctx).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun clear(ctx: Context) {
        runCatching { coil.Coil.imageLoader(ctx).memoryCache?.clear() }
        dir(ctx).deleteRecursively()
    }

    /** Borra carátulas guardadas de archivos que ya no están en tu catálogo. */
    fun cleanOrphanCovers(ctx: Context): Int {
        val used = Catalog.titles().flatMap { Catalog.filesOf(it.id) }.mapNotNull { it.coverPath }.toSet()
        val dir = File(ctx.filesDir, "covers")
        var n = 0
        dir.listFiles()?.forEach { f -> if (f.absolutePath !in used && f.delete()) n++ }
        return n
    }

    fun coversBytes(ctx: Context): Long = File(ctx.filesDir, "covers").walkTopDown().filter { it.isFile }.sumOf { it.length() }
}

object CrashLog {
    private var file: File? = null

    fun install(ctx: Context) {
        file = File(ctx.filesDir, "ultimo_error.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            note("Cierre inesperado (hilo ${t.name})", e)
            prev?.uncaughtException(t, e)
        }
    }

    fun note(where: String, e: Throwable) {
        val f = file ?: return
        runCatching {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val date = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US).format(Date())
            f.writeText(
                "Mi Cine $date\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                    "Dónde: $where\n\n" + sw.toString().take(6000)
            )
        }
    }

    fun read(): String? = file?.takeIf { it.exists() }?.readText()
    fun clear() { file?.delete() }
}
