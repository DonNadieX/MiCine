# Mi Cine

Tu propio "Netflix" privado: un catálogo de series y películas donde cada episodio o
película se reproduce desde su link directo.

## Obtener el APK (GitHub Actions)

1. En github.com crea un repositorio nuevo, por ejemplo `MiCine` (puede ser privado).
2. Descomprime el ZIP y sube **todo el contenido** de la carpeta `MiCine`
   (incluida la carpeta oculta `.github`). Desde el navegador: *Add file → Upload files*.
   - Si `.github` no se sube, créala a mano: *Add file → Create new file*, nombre
     `.github/workflows/build.yml`, y pega el contenido de ese archivo.
3. Abre la pestaña **Actions**: "Compilar APK" arranca sola (unos 5 minutos).
4. Con palomita verde, entra a la ejecución → **Artifacts → MiCine-apk**.
5. Descomprime y toca `app-debug.apk` para instalar (permite "apps desconocidas").

Si sale una X roja, copia el texto del error del paso "Compilar" y pásaselo a Claude.

## Primeros pasos en la app

1. Portadas y sinopsis salen solas y gratis, sin cuenta: series desde **TVmaze**
   y películas desde **iTunes México**. (Opcional: clave de TMDB en Ajustes para todo en español.)
2. **Botón +** → pega todos tus links, uno por línea → "Agregar al catálogo".
3. La app lee el nombre de cada archivo y arma todo sola:
   - `Serie.S01E03.1080p.mkv`, `Serie 1x03`, `Serie Temporada 1 Capitulo 3` → serie, T1 E3
   - `Pelicula (2010) 720p.mp4` → película del 2010
4. Si un link no trae nombre de archivo, escribe el nombre antes del link:
   `Dark S01E03 - https://tuservidor/dl/abc123`
5. También puedes **compartir** links desde Telegram hacia "Mi Cine".

## Novedades v5.3

- NUEVO: Celular y proyector sin internet (como BubbleUPnP). Activa el punto de acceso del celular, conecta el proyector a esa red y en el celular toca Ajustes → "Compartir mi biblioteca". En el proyector: Ajustes → "Buscar mi celular".
- El proyector ve tu catálogo del celular con pósters, sinopsis y temporadas, y reproduce y adelanta sin internet ni gastar datos.
- Lo que veas en el proyector se guarda también en el celular (Seguir viendo).
- Control remoto desde el celular: reproducir, pausa, adelantar, capítulo siguiente, volumen y saltar intro. En cada serie: menú ☰ → "Ver en el proyector".
- Mi Cine también aparece como servidor DLNA: VLC, BubbleUPnP o una Smart TV pueden ver tus videos (Red local).
- Subtítulos externos, pistas recordadas por serie, botón Saltar intro y ventana flotante en el celular.

## Novedades v5.2

- Subtítulos externos: si junto al video hay un .srt/.ass/.vtt con el mismo nombre, se cargan solos.
- En Subtítulos → "Cargar archivo de subtítulos…" para elegir uno a mano (se recuerda para ese capítulo).
- El audio y los subtítulos que elijas se recuerdan para toda la serie.
- Botón "Saltar intro" al empezar cada capítulo (duración ajustable en Ajustes → Reproducción).
- Celular: al salir con Inicio, el video sigue en una ventana flotante.
- Arreglado: la app se cerraba al volver de Ajustes después de cambiar de tema.

## Novedades v5.1

- Reproductor nuevo con el motor de VLC: ahora suenan los videos con audio AC3, E-AC3 y DTS (antes salían sin sonido en el proyector).
- Controles rediseñados: botones grandes, barra de tiempo, anterior/siguiente, audio, subtítulos, velocidad y tamaño de pantalla.
- La barra de navegación de Android ya se oculta bien en el celular.
- Pausar y salir responden al instante con el control.
- Opción de abrir los videos en la app VLC (Ajustes → Reproducción); Mi Cine guarda dónde te quedaste.
- Modo ligero automático en el proyector: menos animaciones y filas, más rápido y sin cierres por memoria.
- Las tareas al abrir la app esperan unos segundos y van una por una.
- La búsqueda de portadas sigue aunque salgas de la pantalla (con notificación) y se retoma al volver a abrir.

## Novedades v5.0

- Modo Proyector/TV: menú lateral, letras grandes y todo se maneja con las flechas del control.
- Aparece en el menú de apps de proyectores y Android TV, con su propio banner.
- Reproductor con control: ◀ ▶ adelantar/regresar, OK pausa, ▲ ▼ controles.
- Busca todos los videos del aparato y memorias USB sin elegir carpetas.
- Envía tus links, listas, clave TMDB y tema del celular al proyector por Wi-Fi.
- Nuevo logo (claqueta).

## Novedades v4.4

- Nueva pantalla de cada serie: banner, póster, botón Continuar, siguiente capítulo, reparto y ficha de datos.
- Limpieza automática: reacomoda capítulos sueltos (01x14…) en su serie, quita duplicados y archivos borrados.
- Links caídos: se marcan y, si siguen caídos al día siguiente, se quitan solos.
- Comparte tu lista en línea: tu conocido la sigue y se actualiza sola.
- La app avisa cuando hay versión nueva y se actualiza con un toque.

## Novedades v4.3

- Ficha de cada serie con el **color de su póster** de fondo.
- Etiqueta de origen con bandera: K-drama, Anime, J-drama, C-drama, Donghua, Cine mexicano…
- **Carrusel de temporadas** con portada propia y anillo de capítulos vistos.
- Sinopsis de cada temporada, botón Continuar y "Marcar temporada vista".
- Filtros: Todos / Sin ver, orden, y vista Lista o Mosaico.
- Capítulo **Siguiente** resaltado y los vistos atenuados con ✓.
- **Reparto con fotos** (o personajes con su actor de voz en anime).

## Novedades v4.2

- Entiende carpetas revueltas: `01x10.mp4`, `E04.mp4` y `Serie S01E13.mp4` juntos se acomodan en orden
  tomando el nombre de la serie de la carpeta (o del link anterior, si son links).
- **Anime**: pósters, banners, sinopsis y géneros desde AniList, y nombres de capítulos desde MyAnimeList.
  Entiende `[Grupo] Nombre - 05 [1080p].mkv`, nombres en romaji y carpetas llamadas "Anime".
- En el lápiz hay opción **Anime** para buscar a mano.

## Novedades v4

- **5 temas** (Ajustes → Apariencia), cada uno con su propia navegación y pantalla de inicio:
  - **Cine** (Netflix): portada gigante, filas deslizables, pestañas arriba.
  - **Estuario** (Kodi): menú lateral con iconos, imágenes panorámicas, ficha con banner.
  - **Muro**: pared de pósters de borde a borde, letra condensada, barra abajo.
  - **Ficha técnica**: lista con póster pequeño, año, géneros, calificación y sinopsis.
  - **Papel**: tema claro tipo revista con portada editorial e índice numerado.
- **Contenido local**: carpetas del celular, tarjeta SD o memoria USB (OTG), y archivos sueltos.
  Entiende carpetas como `Lucifer/Temporada 1/03.mkv`. Busca archivos nuevos al abrir la app.
- **Optimización**: guardado en segundo plano con 3 copias automáticas, caché de imágenes con límite,
  listas que no se alentan con bibliotecas grandes, búfer para links lentos con reintentos,
  limpieza de biblioteca y registro del último error.
- Los links con el nombre en la línea de arriba también se entienden.

## Qué tiene

- **Inicio** con portada destacada, "Seguir viendo", Mi lista, recientes, series,
  películas y filas por género.
- Pestañas **Series / Películas / Mi lista** y **buscador** (por nombre o género).
- **Ficha** de cada título: portada grande, calificación, año, temporadas, episodios,
  géneros, estado, sinopsis y botón Reproducir/Continuar.
- **Temporadas** en carpetas desplegables con cada episodio: imagen, nombre, sinopsis,
  duración, calidad y barra de progreso.
- **Reproductor**: pasa solo al siguiente episodio, recuerda dónde te quedaste,
  marca como visto al terminar, cambia audio, subtítulos y velocidad.
- **Información del archivo** (mantén presionado un episodio o toca ⓘ): carátula y
  metadata completa — códec, resolución, FPS, HDR, pistas de audio e idiomas, subtítulos, tamaño.
- **Corregir** (lápiz): si la app adivinó mal, busca el título correcto en TMDB.
- **Respaldo**: exporta/importa todo el catálogo en un archivo.

## Sobre TeraBox

Los links de compartir de TeraBox abren una página, no el archivo; no se pueden
reproducir directo. Usa links directos al archivo (como los `.../dl/...` de tu bot).
