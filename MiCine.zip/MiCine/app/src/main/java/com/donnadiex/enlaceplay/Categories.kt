package com.donnadiex.enlaceplay

/**
 * Categorías automáticas para no mezclar Rick y Morty con Victoria (2007):
 *   Animadas · Anime · Novelas · Asiáticas (K-dramas, doramas…) · Otras
 * Se deciden por géneros, país de origen y cadena de TV. Si alguna sale mal,
 * en la ficha (menú ☰ → "Cambiar categoría") se elige a mano y se respeta siempre.
 */
enum class Category(val label: String, val plural: String) {
    ANIMATED("Animada", "Animadas"),
    ANIME("Anime", "Anime"),
    NOVELA("Novela", "Novelas"),
    ASIAN("Asiática", "Asiáticas"),
    OTHER("Otra", "Otras");

    companion object {
        private val LATAM = setOf("MX", "CO", "VE", "AR", "PE", "CL", "EC", "UY", "PY", "BO", "CR", "DO", "PR", "GT", "HN", "SV", "NI", "PA", "CU", "BR")
        private val ASIA = setOf("KR", "JP", "CN", "TW", "HK", "TH", "PH", "VN", "ID", "MY", "SG")
        private val NOVELA_TV = listOf("telemundo", "televisa", "las estrellas", "canal de las estrellas", "tv azteca", "azteca",
            "univision", "unimas", "caracol", "rcn", "venevision", "rctv", "telefe", "el trece", "globo", "imagen tv",
            "unicable", "tlnovelas", "pasiones", "america tv", "mega", "canal 13", "tvn", "ecuavisa", "pantaya", "vix")

        private fun has(t: Title, vararg words: String) =
            t.genres.any { g -> val p = NameParser.key(g); words.any { p.contains(it) } }

        /** Categoría automática (sin tomar en cuenta lo elegido a mano). */
        fun auto(t: Title): Category {
            if (t.anime || has(t, "anime")) return ANIME
            if (has(t, "animacion", "animation", "animado", "dibujos", "cartoon")) return ANIMATED
            // Lo asiático va antes que las novelas: un K-drama de la cadena coreana "tvN" no es una telenovela
            if (t.origin.uppercase() in ASIA) return ASIAN
            if (t.kind == Kind.SERIES) {
                val net = NameParser.key(t.network)
                if (has(t, "telenovela", "soap", "novela")) return NOVELA
                if (NOVELA_TV.any { net.contains(it) }) return NOVELA
                if (t.origin.uppercase() in LATAM && (t.genres.isEmpty() || has(t, "drama", "romance", "familia"))) return NOVELA
            }
            return OTHER
        }

        fun of(t: Title): Category = runCatching { valueOf(t.category) }.getOrNull() ?: auto(t)

        /** Las categorías que de verdad hay en esta lista (en orden fijo). */
        fun present(list: List<Title>): List<Pair<Category, Int>> {
            val counts = list.groupingBy { of(it) }.eachCount()
            return values().mapNotNull { c -> counts[c]?.let { c to it } }
        }
    }
}
