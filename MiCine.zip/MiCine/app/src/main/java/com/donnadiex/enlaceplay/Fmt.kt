package com.donnadiex.enlaceplay

import java.util.Locale

/** Convierte números técnicos en texto fácil de leer. */
object Fmt {
    private val ES = Locale("es")

    fun duration(ms: Long): String {
        if (ms <= 0) return "—"
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun bytes(b: Long): String {
        if (b <= 0) return "—"
        val kb = 1024.0
        return when {
            b >= kb * kb * kb -> String.format(Locale.US, "%.2f GB", b / (kb * kb * kb))
            b >= kb * kb -> String.format(Locale.US, "%.1f MB", b / (kb * kb))
            b >= kb -> String.format(Locale.US, "%.0f KB", b / kb)
            else -> "$b B"
        }
    }

    fun bitrate(bps: Long): String {
        if (bps <= 0) return "—"
        return if (bps >= 1_000_000) String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
        else String.format(Locale.US, "%d kbps", bps / 1000)
    }

    fun fps(f: Float): String =
        if (f <= 0f) "—" else String.format(Locale.US, if (f % 1f == 0f) "%.0f fps" else "%.3f fps", f)

    fun channels(n: Int): String = when (n) {
        1 -> "1 (Mono)"
        2 -> "2 (Estéreo)"
        6 -> "6 (5.1 envolvente)"
        8 -> "8 (7.1 envolvente)"
        else -> if (n > 0) "$n" else "—"
    }

    fun sampleRate(hz: Int): String =
        if (hz <= 0) "—" else String.format(Locale.US, "%.1f kHz", hz / 1000.0)

    fun language(code: String?): String {
        if (code.isNullOrBlank() || code == "und") return "Sin especificar"
        val name = Locale.forLanguageTag(code).getDisplayLanguage(ES)
        return if (name.isBlank() || name == code) code
        else name.replaceFirstChar { it.titlecase(ES) } + " ($code)"
    }

    fun resolutionLabel(w: Int, h: Int): String {
        if (w <= 0 || h <= 0) return "—"
        val short = minOf(w, h)
        val tag = when {
            short >= 2100 -> " (4K)"
            short >= 1400 -> " (1440p)"
            short >= 1000 -> " (1080p)"
            short >= 700 -> " (720p)"
            short >= 470 -> " (480p)"
            short >= 350 -> " (360p)"
            else -> ""
        }
        return "${w}×${h}$tag"
    }

    fun codec(mime: String?, codecs: String? = null): String {
        val name = when (mime?.lowercase()) {
            "video/avc" -> "H.264 (AVC)"
            "video/hevc" -> "H.265 (HEVC)"
            "video/x-vnd.on2.vp9" -> "VP9"
            "video/x-vnd.on2.vp8" -> "VP8"
            "video/av01" -> "AV1"
            "video/mp4v-es" -> "MPEG-4 Parte 2"
            "video/mpeg2" -> "MPEG-2"
            "video/3gpp" -> "H.263"
            "video/dolby-vision" -> "Dolby Vision"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MP3"
            "audio/ac3" -> "AC-3 (Dolby Digital)"
            "audio/eac3" -> "E-AC-3 (Dolby Digital Plus)"
            "audio/eac3-joc" -> "Dolby Atmos (E-AC-3 JOC)"
            "audio/ac4" -> "AC-4"
            "audio/true-hd" -> "Dolby TrueHD"
            "audio/vnd.dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            "audio/flac" -> "FLAC"
            "audio/raw" -> "PCM"
            "application/x-subrip" -> "SRT"
            "text/x-ssa" -> "ASS / SSA"
            "text/vtt" -> "WebVTT"
            "application/pgs" -> "PGS (imagen)"
            "application/vobsub" -> "VobSub (imagen)"
            "application/dvbsubs" -> "DVB (imagen)"
            "application/ttml+xml" -> "TTML"
            "application/cea-608", "text/cea-608" -> "CEA-608"
            "application/x-media3-cues" -> "Subtítulo"
            null, "" -> "Desconocido"
            else -> mime
        }
        return if (!codecs.isNullOrBlank() && codecs != mime) "$name · $codecs" else name
    }

    fun container(contentType: String?, fileName: String?, mmrMime: String?): String {
        val ext = fileName?.substringAfterLast('.', "")?.lowercase().orEmpty()
        val src = (mmrMime ?: contentType ?: "").lowercase()
        return when {
            ext == "mkv" || src.contains("matroska") -> "Matroska (MKV)"
            ext == "webm" || src.contains("webm") -> "WebM"
            ext == "mp4" || ext == "m4v" || src.contains("mp4") -> "MPEG-4 (MP4)"
            ext == "mov" || src.contains("quicktime") -> "QuickTime (MOV)"
            ext == "avi" || src.contains("avi") -> "AVI"
            ext == "ts" || src.contains("mp2t") -> "MPEG-TS"
            ext == "flv" || src.contains("flv") -> "Flash Video (FLV)"
            ext == "3gp" || src.contains("3gpp") -> "3GP"
            ext == "m3u8" || src.contains("mpegurl") -> "HLS (streaming)"
            ext.isNotBlank() -> ext.uppercase()
            src.isNotBlank() -> src
            else -> "—"
        }
    }
}
