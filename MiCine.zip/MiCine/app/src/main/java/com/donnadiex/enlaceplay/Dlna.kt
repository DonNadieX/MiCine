package com.donnadiex.enlaceplay

/**
 * Servidor de medios DLNA/UPnP (lo mínimo que piden VLC, BubbleUPnP, Kodi y las Smart TV):
 *   Raíz → Series → (cada serie) → capítulos
 *        → Películas → películas
 * Solo se comparten tus videos locales (los links de internet no).
 */
object Dlna {

    fun description(ip: String, id: String, name: String) = """<?xml version="1.0" encoding="utf-8"?>
<root xmlns="urn:schemas-upnp-org:device-1-0" xmlns:dlna="urn:schemas-dlna-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <URLBase>http://$ip:${LibraryShare.PORT}/</URLBase>
  <device>
    <deviceType>urn:schemas-upnp-org:device:MediaServer:1</deviceType>
    <dlna:X_DLNADOC>DMS-1.50</dlna:X_DLNADOC>
    <friendlyName>${esc(name)}</friendlyName>
    <manufacturer>Mi Cine</manufacturer>
    <modelName>Mi Cine</modelName>
    <modelNumber>5</modelNumber>
    <UDN>uuid:$id</UDN>
    <serviceList>
      <service>
        <serviceType>urn:schemas-upnp-org:service:ContentDirectory:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:ContentDirectory</serviceId>
        <SCPDURL>/dlna/cds.xml</SCPDURL>
        <controlURL>/dlna/cds/control</controlURL>
        <eventSubURL>/dlna/cds/event</eventSubURL>
      </service>
      <service>
        <serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId>
        <SCPDURL>/dlna/cms.xml</SCPDURL>
        <controlURL>/dlna/cms/control</controlURL>
        <eventSubURL>/dlna/cms/event</eventSubURL>
      </service>
    </serviceList>
  </device>
</root>"""

    private fun arg(name: String, dir: String, v: String) =
        "<argument><name>$name</name><direction>$dir</direction><relatedStateVariable>$v</relatedStateVariable></argument>"

    val CDS_SCPD = """<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0"><specVersion><major>1</major><minor>0</minor></specVersion>
<actionList>
<action><name>Browse</name><argumentList>
${arg("ObjectID", "in", "A_ARG_TYPE_ObjectID")}${arg("BrowseFlag", "in", "A_ARG_TYPE_BrowseFlag")}${arg("Filter", "in", "A_ARG_TYPE_Filter")}
${arg("StartingIndex", "in", "A_ARG_TYPE_Index")}${arg("RequestedCount", "in", "A_ARG_TYPE_Count")}${arg("SortCriteria", "in", "A_ARG_TYPE_SortCriteria")}
${arg("Result", "out", "A_ARG_TYPE_Result")}${arg("NumberReturned", "out", "A_ARG_TYPE_Count")}${arg("TotalMatches", "out", "A_ARG_TYPE_Count")}${arg("UpdateID", "out", "A_ARG_TYPE_UpdateID")}
</argumentList></action>
<action><name>GetSearchCapabilities</name><argumentList>${arg("SearchCaps", "out", "SearchCapabilities")}</argumentList></action>
<action><name>GetSortCapabilities</name><argumentList>${arg("SortCaps", "out", "SortCapabilities")}</argumentList></action>
<action><name>GetSystemUpdateID</name><argumentList>${arg("Id", "out", "SystemUpdateID")}</argumentList></action>
</actionList>
<serviceStateTable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_ObjectID</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_BrowseFlag</name><dataType>string</dataType><allowedValueList><allowedValue>BrowseMetadata</allowedValue><allowedValue>BrowseDirectChildren</allowedValue></allowedValueList></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Filter</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Index</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Count</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_SortCriteria</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Result</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_UpdateID</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>SearchCapabilities</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>SortCapabilities</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="yes"><name>SystemUpdateID</name><dataType>ui4</dataType></stateVariable>
</serviceStateTable></scpd>"""

    val CMS_SCPD = """<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0"><specVersion><major>1</major><minor>0</minor></specVersion>
<actionList>
<action><name>GetProtocolInfo</name><argumentList>${arg("Source", "out", "SourceProtocolInfo")}${arg("Sink", "out", "SinkProtocolInfo")}</argumentList></action>
<action><name>GetCurrentConnectionIDs</name><argumentList>${arg("ConnectionIDs", "out", "CurrentConnectionIDs")}</argumentList></action>
</actionList>
<serviceStateTable>
<stateVariable sendEvents="yes"><name>SourceProtocolInfo</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="yes"><name>SinkProtocolInfo</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="yes"><name>CurrentConnectionIDs</name><dataType>string</dataType></stateVariable>
</serviceStateTable></scpd>"""

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun soap(action: String, service: String, inner: String) = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>
<u:${action}Response xmlns:u="urn:schemas-upnp-org:service:$service:1">$inner</u:${action}Response>
</s:Body></s:Envelope>"""

    private fun tag(body: String, name: String) =
        Regex("<(?:\\w+:)?$name[^>]*>([^<]*)</(?:\\w+:)?$name>").find(body)?.groupValues?.get(1)?.trim() ?: ""

    fun connectionManager(req: MiniHttp.Request): String {
        val action = req.header("soapaction")?.substringAfter('#')?.trim('"', ' ') ?: ""
        return when (action) {
            "GetCurrentConnectionIDs" -> soap(action, "ConnectionManager", "<ConnectionIDs>0</ConnectionIDs>")
            else -> soap("GetProtocolInfo", "ConnectionManager",
                "<Source>http-get:*:video/mp4:*,http-get:*:video/x-matroska:*,http-get:*:video/x-msvideo:*,http-get:*:video/mp2t:*,http-get:*:video/webm:*</Source><Sink></Sink>")
        }
    }

    fun contentDirectory(req: MiniHttp.Request, files: List<MediaFile>): String {
        val body = req.bodyText
        val action = req.header("soapaction")?.substringAfter('#')?.trim('"', ' ') ?: ""
        when (action) {
            "GetSearchCapabilities" -> return soap(action, "ContentDirectory", "<SearchCaps></SearchCaps>")
            "GetSortCapabilities" -> return soap(action, "ContentDirectory", "<SortCaps></SortCaps>")
            "GetSystemUpdateID" -> return soap(action, "ContentDirectory", "<Id>1</Id>")
        }
        val id = tag(body, "ObjectID").ifBlank { "0" }
        val meta = tag(body, "BrowseFlag") == "BrowseMetadata"
        val start = tag(body, "StartingIndex").toIntOrNull() ?: 0
        val count = (tag(body, "RequestedCount").toIntOrNull() ?: 0).let { if (it <= 0) Int.MAX_VALUE else it }
        val ip = req.localIp
        val local = files.filter { Local.isLocal(it.url) }
        val byTitle = local.groupBy { it.titleId }
        val series = byTitle.keys.mapNotNull { Catalog.title(it) }.filter { it.kind == Kind.SERIES }.sortedBy { it.name.lowercase() }
        val movies = local.filter { Catalog.title(it.titleId)?.kind != Kind.SERIES }
            .sortedBy { (Catalog.title(it.titleId)?.name ?: it.fileName).lowercase() }

        fun container(cid: String, parent: String, title: String, n: Int, art: String? = null) =
            "<container id=\"${esc(cid)}\" parentID=\"${esc(parent)}\" childCount=\"$n\" restricted=\"1\" searchable=\"0\">" +
                "<dc:title>${esc(title)}</dc:title><upnp:class>object.container.storageFolder</upnp:class>" +
                (art?.let { "<upnp:albumArtURI>${esc(LibraryShare.imgUrl(ip, it))}</upnp:albumArtURI>" } ?: "") + "</container>"

        fun item(f: MediaFile, parent: String): String {
            val t = Catalog.title(f.titleId)
            val name = when {
                f.episode > 0 -> "T${f.season} E${f.episode}" + (f.epName.ifBlank { null }?.let { " · $it" } ?: "")
                else -> t?.name ?: f.fileName
            }
            val art = f.still ?: t?.poster
            val dur = if (f.durationMs > 0) " duration=\"${Fmt.hms(f.durationMs)}\"" else ""
            val mime = LibraryShare.mimeOfFile(f)
            return "<item id=\"f:${f.id}\" parentID=\"${esc(parent)}\" restricted=\"1\">" +
                "<dc:title>${esc(name)}</dc:title><upnp:class>object.item.videoItem</upnp:class>" +
                (art?.let { "<upnp:albumArtURI>${esc(LibraryShare.imgUrl(ip, it))}</upnp:albumArtURI>" } ?: "") +
                (t?.overview?.ifBlank { null }?.let { "<dc:description>${esc(it.take(300))}</dc:description>" } ?: "") +
                "<res protocolInfo=\"http-get:*:$mime:DLNA.ORG_OP=01\"$dur>${esc(LibraryShare.urlFor(ip, f))}</res></item>"
        }

        val entries: List<String>
        if (meta) {
            entries = listOf(when {
                id == "0" -> container("0", "-1", "Mi Cine", 2)
                id == "s" -> container("s", "0", "Series", series.size)
                id == "m" -> container("m", "0", "Películas", movies.size)
                id.startsWith("t:") -> Catalog.title(id.removePrefix("t:"))?.let { container(id, "s", it.name, byTitle[it.id]?.size ?: 0, it.poster) } ?: ""
                id.startsWith("f:") -> Catalog.file(id.removePrefix("f:"))?.let { item(it, if (Catalog.title(it.titleId)?.kind == Kind.SERIES) "t:${it.titleId}" else "m") } ?: ""
                else -> ""
            }).filter { it.isNotBlank() }
        } else {
            entries = when {
                id == "0" -> listOf(container("s", "0", "Series", series.size), container("m", "0", "Películas", movies.size))
                id == "s" -> series.map { container("t:${it.id}", "s", it.name, byTitle[it.id]?.size ?: 0, it.poster) }
                id == "m" -> movies.map { item(it, "m") }
                id.startsWith("t:") -> (byTitle[id.removePrefix("t:")] ?: emptyList()).sortedWith(compareBy({ it.season }, { it.episode })).map { item(it, id) }
                else -> emptyList()
            }
        }
        val page = entries.drop(start).take(count)
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" + page.joinToString("") + "</DIDL-Lite>"
        return soap("Browse", "ContentDirectory",
            "<Result>${esc(didl)}</Result><NumberReturned>${page.size}</NumberReturned><TotalMatches>${entries.size}</TotalMatches><UpdateID>1</UpdateID>")
    }
}
