package com.donnadiex.enlaceplay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class AnalysisResult(
    val title: String,
    val coverPath: String?,
    val durationMs: Long,
    val summary: String,
    val sections: List<InfoSection>
)

data class HeaderInfo(
    val code: Int,
    val finalUrl: String,
    val fileName: String?,
    val size: Long,
    val contentType: String?,
    val acceptRanges: Boolean,
    val server: String?,
    val lastModified: Long
)

private data class MmrInfo(val tags: Map<Int, String>, val coverPath: String?, val coverSource: String?)

private data class ProbeInfo(val tracks: Tracks, val durationMs: Long)

/**
 * Analiza un link en 3 partes al mismo tiempo:
 *  1) cabeceras HTTP (nombre, tamaño, tipo)
 *  2) MediaMetadataRetriever de Android (etiquetas + carátula)
 *  3) ExoPlayer (pistas de video, audio y subtítulos con todos sus detalles)
 */
object Analyzer {

    suspend fun analyze(ctx: Context, id: String, url: String): AnalysisResult = coroutineScope {
        val headersJob = async(Dispatchers.IO) { runCatching { if (Local.isLocal(url)) localHeaders(ctx, url) else fetchHeaders(url) }.getOrNull() }
        val mmrJob = CoroutineScope(Dispatchers.IO).async { runCatching { readMmr(ctx, id, url) }.getOrNull() }
        val probeJob = async { probe(ctx, url) }

        val h = headersJob.await()
        val probe = probeJob.await()
        // La carátula puede tardar más en archivos grandes; damos hasta 60 s.
        val m = withTimeoutOrNull(60_000) { mmrJob.await() }
        if (m == null) mmrJob.cancel()

        build(url, h, m, probe)
    }

    /** Solo las cabeceras (rápido): sirve para saber el nombre real del archivo. */
    fun headers(url: String): HeaderInfo? = runCatching { fetchHeaders(url) }.getOrNull()

    /** Datos de un archivo local (nombre, tamaño, tipo) sin internet. */
    fun localHeaders(ctx: Context, url: String): HeaderInfo {
        val u = Uri.parse(url)
        var name: String? = null
        var size = -1L
        ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0)
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        var modified = 0L
        runCatching {
            ctx.contentResolver.query(u, arrayOf(android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)
                ?.use { c -> if (c.moveToFirst() && !c.isNull(0)) modified = c.getLong(0) }
        }
        return HeaderInfo(
            code = 200, finalUrl = url, fileName = name, size = size,
            contentType = ctx.contentResolver.getType(u), acceptRanges = true,
            server = Local.whereLabel(url), lastModified = modified
        )
    }

    // ---------- 1) Cabeceras HTTP ----------
    private fun fetchHeaders(start: String): HeaderInfo {
        var current = start
        var conn: HttpURLConnection? = null
        repeat(6) {
            conn?.disconnect()
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Range", "bytes=0-0")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return@repeat
                current = URL(URL(current), loc).toString()
                conn = c
            } else {
                conn = c
                return parseHeaders(c, code, current)
            }
        }
        val c = conn ?: throw IllegalStateException("sin respuesta")
        return parseHeaders(c, c.responseCode, current)
    }

    private fun parseHeaders(c: HttpURLConnection, code: Int, finalUrl: String): HeaderInfo {
        val contentRange = c.getHeaderField("Content-Range") // bytes 0-0/123456
        val size = contentRange?.substringAfterLast('/')?.trim()?.toLongOrNull()
            ?: c.getHeaderField("Content-Length")?.toLongOrNull()?.takeIf { code != 206 }
            ?: -1L
        val disp = c.getHeaderField("Content-Disposition")
        val info = HeaderInfo(
            code = code,
            finalUrl = finalUrl,
            fileName = parseFileName(disp),
            size = size,
            contentType = c.contentType,
            acceptRanges = code == 206 || c.getHeaderField("Accept-Ranges")?.contains("bytes") == true,
            server = c.getHeaderField("Server"),
            lastModified = c.lastModified
        )
        c.disconnect()
        return info
    }

    private fun parseFileName(disp: String?): String? {
        if (disp.isNullOrBlank()) return null
        Regex("filename\\*\\s*=\\s*[^']*''([^;]+)", RegexOption.IGNORE_CASE).find(disp)?.let {
            return runCatching { URLDecoder.decode(it.groupValues[1].trim('"', ' '), "UTF-8") }.getOrNull()
        }
        Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(disp)?.let {
            return it.groupValues[1].trim()
        }
        return null
    }

    // ---------- 2) MediaMetadataRetriever (etiquetas + carátula) ----------
    private fun readMmr(ctx: Context, id: String, url: String): MmrInfo {
        val mmr = MediaMetadataRetriever()
        try {
            if (Local.isLocal(url)) mmr.setDataSource(ctx, Uri.parse(url))
            else mmr.setDataSource(url, mapOf("User-Agent" to USER_AGENT))
            val keys = mutableListOf(
                MediaMetadataRetriever.METADATA_KEY_TITLE,
                MediaMetadataRetriever.METADATA_KEY_ARTIST,
                MediaMetadataRetriever.METADATA_KEY_ALBUM,
                MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST,
                MediaMetadataRetriever.METADATA_KEY_AUTHOR,
                MediaMetadataRetriever.METADATA_KEY_COMPOSER,
                MediaMetadataRetriever.METADATA_KEY_WRITER,
                MediaMetadataRetriever.METADATA_KEY_GENRE,
                MediaMetadataRetriever.METADATA_KEY_DATE,
                MediaMetadataRetriever.METADATA_KEY_YEAR,
                MediaMetadataRetriever.METADATA_KEY_LOCATION,
                MediaMetadataRetriever.METADATA_KEY_DURATION,
                MediaMetadataRetriever.METADATA_KEY_BITRATE,
                MediaMetadataRetriever.METADATA_KEY_MIMETYPE,
                MediaMetadataRetriever.METADATA_KEY_NUM_TRACKS,
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH,
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT,
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION,
                MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE,
                MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO,
                MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO
            )
            if (Build.VERSION.SDK_INT >= 28) keys.add(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)
            val tags = mutableMapOf<Int, String>()
            keys.forEach { k -> runCatching { mmr.extractMetadata(k) }.getOrNull()?.takeIf { it.isNotBlank() }?.let { tags[k] = it } }

            // Carátula: primero la incrustada en el archivo; si no hay, un fotograma del video.
            var bmp: Bitmap? = null
            var source: String? = null
            runCatching { mmr.embeddedPicture }.getOrNull()?.let { bytes ->
                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) source = "Carátula incrustada en el archivo"
            }
            if (bmp == null) {
                val durMs: Long = tags[MediaMetadataRetriever.METADATA_KEY_DURATION]?.toLongOrNull() ?: 0L
                val atMs = if (durMs > 0) minOf((durMs * 0.12).toLong(), 90_000L) else 5_000L
                val atUs = atMs * 1000
                bmp = runCatching {
                    if (Build.VERSION.SDK_INT >= 27)
                        mmr.getScaledFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 960, 540)
                    else mmr.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }.getOrNull()
                if (bmp != null) source = "Fotograma del video (${Fmt.duration(atMs)})"
            }
            val path = bmp?.let { saveCover(ctx, id, it) }
            return MmrInfo(tags, path, if (path != null) source else null)
        } finally {
            runCatching { mmr.release() }
        }
    }

    private fun saveCover(ctx: Context, id: String, src: Bitmap): String? = runCatching {
        val maxW = 960
        val bmp = if (src.width > maxW) {
            Bitmap.createScaledBitmap(src, maxW, (src.height * maxW.toFloat() / src.width).toInt().coerceAtLeast(1), true)
        } else src
        val dir = File(ctx.filesDir, "covers").apply { mkdirs() }
        val f = File(dir, "$id.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        f.absolutePath
    }.getOrNull()

    // ---------- 3) ExoPlayer: pistas ----------
    private suspend fun probe(ctx: Context, url: String): ProbeInfo? = withContext(Dispatchers.Main) {
        val player = Players.build(ctx)
        try {
            withTimeoutOrNull(30_000) {
                suspendCancellableCoroutine<ProbeInfo?> { cont ->
                    player.addListener(object : Player.Listener {
                        override fun onTracksChanged(tracks: Tracks) {
                            if (!tracks.isEmpty && cont.isActive) {
                                val d = player.duration
                                cont.resume(ProbeInfo(tracks, if (d == C.TIME_UNSET) 0 else d))
                            }
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            if (cont.isActive) cont.resume(null)
                        }
                    })
                    player.playWhenReady = false
                    player.setMediaItem(MediaItem.fromUri(url))
                    player.prepare()
                }
            }
        } finally {
            player.release()
        }
    }

    // ---------- Armar las secciones ----------
    private fun build(url: String, h: HeaderInfo?, m: MmrInfo?, p: ProbeInfo?): AnalysisResult {
        val tags = m?.tags ?: emptyMap()
        val sections = mutableListOf<InfoSection>()

        val urlName = runCatching {
            Uri.parse(h?.finalUrl ?: url).lastPathSegment?.let { URLDecoder.decode(it, "UTF-8") }
        }.getOrNull()
        val fileName = h?.fileName ?: urlName
        val tagTitle = tags[MediaMetadataRetriever.METADATA_KEY_TITLE]
        val title = tagTitle ?: fileName?.substringBeforeLast('.')?.replace('_', ' ')?.replace('.', ' ')?.trim()
            ?.ifBlank { null } ?: "Video sin nombre"

        val durationMs = tags[MediaMetadataRetriever.METADATA_KEY_DURATION]?.toLongOrNull()?.takeIf { it > 0 }
            ?: p?.durationMs ?: 0L

        // Archivo
        val file = mutableListOf<Pair<String, String>>()
        file += "Nombre" to (fileName ?: "—")
        file += "Tamaño" to Fmt.bytes(h?.size ?: -1)
        file += "Contenedor" to Fmt.container(h?.contentType, fileName, tags[MediaMetadataRetriever.METADATA_KEY_MIMETYPE])
        h?.contentType?.let { file += "Tipo (servidor)" to it }
        if (Local.isLocal(url)) {
            file += "Ubicación" to Local.whereLabel(url)
            file += "Ruta" to (runCatching { android.provider.DocumentsContract.getDocumentId(Uri.parse(url)).substringAfter(':') }.getOrNull() ?: "—")
        } else {
            file += "Servidor" to (Uri.parse(h?.finalUrl ?: url).host ?: "—")
            h?.server?.let { file += "Software servidor" to it }
            h?.let { file += "Permite adelantar" to if (it.acceptRanges) "Sí" else "No (puede fallar al saltar)" }
            h?.let { file += "Respuesta HTTP" to it.code.toString() }
        }
        if ((h?.lastModified ?: 0L) > 0L) {
            file += "Última modificación" to SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es")).format(Date(h!!.lastModified))
        }
        m?.coverSource?.let { file += "Carátula" to it }
        sections += InfoSection("Archivo", file)

        // General
        val general = mutableListOf<Pair<String, String>>()
        general += "Duración" to Fmt.duration(durationMs)
        val bitrate = tags[MediaMetadataRetriever.METADATA_KEY_BITRATE]?.toLongOrNull()
            ?: if ((h?.size ?: 0L) > 0L && durationMs > 0L) h!!.size * 8L * 1000L / durationMs else 0L
        general += "Bitrate total" to Fmt.bitrate(bitrate)
        val groups = p?.tracks?.groups.orEmpty()
        val vCount = groups.count { it.type == C.TRACK_TYPE_VIDEO }
        val aCount = groups.count { it.type == C.TRACK_TYPE_AUDIO }
        val sCount = groups.count { it.type == C.TRACK_TYPE_TEXT }
        if (p != null) general += "Pistas" to "$vCount video · $aCount audio · $sCount subtítulos"
        else tags[MediaMetadataRetriever.METADATA_KEY_NUM_TRACKS]?.let { general += "Pistas" to it }
        tags[MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT]?.let { general += "Fotogramas" to it }
        sections += InfoSection("General", general)

        // Video
        var mainRes = ""
        var vIndex = 0
        groups.filter { it.type == C.TRACK_TYPE_VIDEO }.forEach { g ->
            for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                vIndex++
                val rows = mutableListOf<Pair<String, String>>()
                rows += "Códec" to Fmt.codec(f.sampleMimeType, f.codecs)
                rows += "Resolución" to Fmt.resolutionLabel(f.width, f.height)
                if (mainRes.isEmpty()) mainRes = Fmt.resolutionLabel(f.width, f.height)
                if (f.width > 0 && f.height > 0) rows += "Relación de aspecto" to aspect(f.width, f.height)
                rows += "Cuadros por segundo" to Fmt.fps(f.frameRate)
                if (f.bitrate > 0) rows += "Bitrate" to Fmt.bitrate(f.bitrate.toLong())
                if (f.rotationDegrees != 0) rows += "Rotación" to "${f.rotationDegrees}°"
                rows += "Rango dinámico" to hdr(f)
                f.label?.let { rows += "Etiqueta" to it }
                rows += "Compatible con tu equipo" to support(g, i)
                sections += InfoSection(if (vIndex == 1) "Video" else "Video $vIndex", rows)
            }
        }
        if (vIndex == 0 && tags.containsKey(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)) {
            val w = tags[MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH]?.toIntOrNull() ?: 0
            val hh = tags[MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT]?.toIntOrNull() ?: 0
            mainRes = Fmt.resolutionLabel(w, hh)
            val rows = mutableListOf("Resolución" to mainRes)
            tags[MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION]?.takeIf { it != "0" }?.let { rows += "Rotación" to "$it°" }
            tags[MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE]?.let { rows += "Cuadros por segundo" to it }
            sections += InfoSection("Video", rows)
        }

        // Audio
        var aIndex = 0
        groups.filter { it.type == C.TRACK_TYPE_AUDIO }.forEach { g ->
            for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                aIndex++
                val rows = mutableListOf<Pair<String, String>>()
                rows += "Idioma" to Fmt.language(f.language)
                rows += "Códec" to Fmt.codec(f.sampleMimeType, f.codecs)
                rows += "Canales" to Fmt.channels(f.channelCount)
                rows += "Frecuencia" to Fmt.sampleRate(f.sampleRate)
                if (f.bitrate > 0) rows += "Bitrate" to Fmt.bitrate(f.bitrate.toLong())
                f.label?.let { rows += "Nombre" to it }
                if (f.selectionFlags and C.SELECTION_FLAG_DEFAULT != 0) rows += "Predeterminada" to "Sí"
                rows += "Compatible con tu equipo" to support(g, i)
                sections += InfoSection("Audio $aIndex", rows)
            }
        }

        // Subtítulos
        val subs = mutableListOf<Pair<String, String>>()
        var sIndex = 0
        groups.filter { it.type == C.TRACK_TYPE_TEXT }.forEach { g ->
            for (i in 0 until g.length) {
                val f = g.getTrackFormat(i)
                sIndex++
                val extra = buildList {
                    add(Fmt.codec(f.sampleMimeType ?: f.containerMimeType))
                    f.label?.let { add(it) }
                    if (f.selectionFlags and C.SELECTION_FLAG_FORCED != 0) add("forzado")
                    if (f.selectionFlags and C.SELECTION_FLAG_DEFAULT != 0) add("predeterminado")
                }.joinToString(" · ")
                subs += "Pista $sIndex" to "${Fmt.language(f.language)}\n$extra"
            }
        }
        if (subs.isNotEmpty()) sections += InfoSection("Subtítulos", subs)

        // Etiquetas del archivo
        val tagRows = mutableListOf<Pair<String, String>>()
        mapOf(
            MediaMetadataRetriever.METADATA_KEY_TITLE to "Título",
            MediaMetadataRetriever.METADATA_KEY_ARTIST to "Artista",
            MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST to "Artista del álbum",
            MediaMetadataRetriever.METADATA_KEY_ALBUM to "Álbum / Serie",
            MediaMetadataRetriever.METADATA_KEY_AUTHOR to "Autor",
            MediaMetadataRetriever.METADATA_KEY_COMPOSER to "Compositor",
            MediaMetadataRetriever.METADATA_KEY_WRITER to "Escritor",
            MediaMetadataRetriever.METADATA_KEY_GENRE to "Género",
            MediaMetadataRetriever.METADATA_KEY_YEAR to "Año",
            MediaMetadataRetriever.METADATA_KEY_DATE to "Fecha",
            MediaMetadataRetriever.METADATA_KEY_LOCATION to "Ubicación GPS"
        ).forEach { (k, label) -> tags[k]?.let { tagRows += label to it } }
        if (tagRows.isNotEmpty()) sections += InfoSection("Etiquetas del archivo", tagRows)

        if (p == null && m == null) {
            sections += InfoSection(
                "Aviso",
                listOf("Estado" to "No se pudo leer el contenido del video. Verifica que el link sea directo a un archivo y que siga activo.")
            )
        }

        val summary = listOf(Fmt.duration(durationMs), mainRes.substringBefore(" ("), Fmt.bytes(h?.size ?: -1))
            .filter { it.isNotBlank() && it != "—" }.joinToString(" · ")

        return AnalysisResult(title, m?.coverPath, durationMs, summary, sections)
    }

    private fun aspect(w: Int, h: Int): String {
        fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)
        val g = gcd(w, h)
        val ratio = w.toDouble() / h
        return String.format(Locale.US, "%d:%d (%.2f)", w / g, h / g, ratio)
    }

    private fun hdr(f: Format): String {
        val t = f.colorInfo?.colorTransfer ?: return "SDR"
        return when (t) {
            C.COLOR_TRANSFER_ST2084 -> if (f.sampleMimeType == "video/dolby-vision") "Dolby Vision" else "HDR10 (PQ)"
            C.COLOR_TRANSFER_HLG -> "HLG"
            else -> "SDR"
        }
    }

    private fun support(g: Tracks.Group, i: Int): String = when (g.getTrackSupport(i)) {
        C.FORMAT_HANDLED -> "Sí"
        C.FORMAT_EXCEEDS_CAPABILITIES -> "Quizá no (excede tu equipo)"
        C.FORMAT_UNSUPPORTED_SUBTYPE, C.FORMAT_UNSUPPORTED_TYPE -> "No (usa \"Otra app\")"
        else -> "Desconocido"
    }
}
