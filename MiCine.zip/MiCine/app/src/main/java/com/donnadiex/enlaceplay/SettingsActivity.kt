package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : BaseActivity() {

    private val REQ_EXPORT = 11
    private val REQ_IMPORT = 12
    private lateinit var keyStatus: TextView
    private lateinit var refreshStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), dp(2)) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        top.addView(txt("Ajustes", 18f, Col.TEXT, true), lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this)
        val body = vbox(16)

        // --- TMDB ---
        body.addView(header("Portadas y sinopsis"))
        val card = card()
        card.addView(txt("Sin hacer nada, la app ya baja portadas y sinopsis gratis: series desde TVmaze (textos en inglés) y películas desde iTunes México (en español).", 13f, Col.TEXT)
            .apply { setLineSpacing(0f, 1.2f) })
        card.addView(txt("Opcional: con una clave de TMDB todo sale en español y con más datos. Si la dejas vacía, se usan las fuentes gratis.", 13f, Col.MUTED)
            .apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
        card.addView(txt(
            "Cómo sacar la clave de TMDB (opcional):\n" +
                "1. Crea una cuenta gratis en themoviedb.org\n" +
                "2. Entra a Ajustes → API y solicita una clave (uso personal)\n" +
                "3. Copia la \"Clave API\" o el \"Token de lectura\" y pégala aquí",
            13f, Color.parseColor("#D6D6D6")
        ).apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.2f) })
        card.addView(linkText("Abrir la página de TMDB") {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/settings/api"))) }
        })
        val keyEdit = EditText(this).apply {
            hint = "Clave de TMDB (opcional)"
            setHintTextColor(Col.DIM)
            setTextColor(Col.TEXT)
            textSize = 13f
            setSingleLine()
            background = rounded(Col.CARD2, dpf(8f), dp(1), Col.LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setText(Tmdb.key(this@SettingsActivity))
        }
        card.addView(keyEdit, lp().apply { topMargin = dp(12) })
        card.addView(pill("Guardar y probar", true) {
            Tmdb.setKey(this, keyEdit.text.toString())
            if (keyEdit.text.isBlank()) {
                keyStatus.setTextColor(Col.MUTED)
                keyStatus.text = "Sin clave: se usan TVmaze e iTunes (gratis)."
                return@pill
            }
            keyStatus.text = "Probando…"
            scope.launch {
                val err = withContext(Dispatchers.IO) { Tmdb.test(this@SettingsActivity) }
                keyStatus.setTextColor(if (err == null) Color.parseColor("#46D369") else Col.RED)
                keyStatus.text = err?.let { "No funcionó: $it" } ?: "Clave correcta. Ya puedes actualizar los datos del catálogo."
            }
        }, lp().apply { topMargin = dp(10) })
        keyStatus = txt(if (Tmdb.hasKey(this)) "Usando TMDB." else "Sin clave: se usan TVmaze e iTunes (gratis).", 13f, Col.MUTED).apply { setPadding(0, dp(8), 0, 0) }
        card.addView(keyStatus)
        body.addView(card)

        // --- Actualizar ---
        body.addView(header("Catálogo"))
        val c2 = card()
        c2.addView(pill("Actualizar portadas y datos de todo", false) { refreshAll() }, lp())
        refreshStatus = txt("Busca portadas y sinopsis de los títulos que no las tengan, y los nombres de episodios nuevos.", 12f, Col.MUTED)
            .apply { setPadding(0, dp(8), 0, 0) }
        c2.addView(refreshStatus)
        body.addView(c2)

        // --- Respaldo ---
        body.addView(header("Respaldo"))
        val c3 = card()
        c3.addView(txt("Guarda todo tu catálogo (links, progreso, portadas) en un archivo, para no perderlo o pasarlo a otro celular.", 13f, Col.MUTED))
        c3.addView(pill("Exportar respaldo", false) {
            val name = "mi_cine_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json"
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT)
        }, lp().apply { topMargin = dp(12) })
        c3.addView(pill("Importar respaldo", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*"), REQ_IMPORT)
        }, lp().apply { topMargin = dp(10) })
        body.addView(c3)

        // --- Borrar ---
        body.addView(header("Zona de peligro"))
        val c4 = card()
        c4.addView(pill("Borrar todo el catálogo", false) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("¿Borrar todo?")
                .setMessage("Se quitan todos los links y el progreso. Exporta un respaldo antes si lo quieres conservar.")
                .setPositiveButton("Borrar todo") { _, _ -> Catalog.clearAll(); toast("Catálogo vacío") }
                .setNegativeButton("Cancelar", null).show()
        }.apply { setTextColor(Col.RED) }, lp())
        body.addView(c4)

        val stats = Catalog.titles()
        body.addView(txt("${stats.count { it.kind == Kind.SERIES }} series · ${stats.count { it.kind == Kind.MOVIE }} películas",
            12f, Col.DIM).apply { setPadding(dp(4), dp(20), 0, 0) })

        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun refreshAll() {
        val list = Catalog.titles()
        scope.launch {
            var ok = 0
            list.forEachIndexed { i, t ->
                refreshStatus.text = "${i + 1} / ${list.size} · ${t.name}"
                val good = withContext(Dispatchers.IO) {
                    runCatching {
                        if (t.ext.isBlank()) Meta.autoMatch(this@SettingsActivity, t) else Meta.refresh(this@SettingsActivity, t)
                    }.getOrDefault(false)
                }
                if (good) ok++
            }
            Meta.mergeDuplicates()
            Catalog.save()
            refreshStatus.setTextColor(Col.TEXT)
            refreshStatus.text = "Listo: $ok de ${list.size} títulos actualizados."
        }
    }

    @Deprecated("API de Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_EXPORT -> runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(Catalog.exportJson().toByteArray()) }
                toast("Respaldo guardado")
            }.onFailure { toast("No se pudo guardar: ${it.message}") }
            REQ_IMPORT -> runCatching {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val n = Catalog.importJson(text)
                toast("Importados $n archivos nuevos")
            }.onFailure { toast("Archivo no válido: ${it.message}") }
        }
    }

    private fun header(s: String) = txt(s.uppercase(), 12f, Col.RED, true).apply {
        letterSpacing = 0.08f
        setPadding(dp(4), dp(18), 0, dp(8))
    }

    private fun card(): LinearLayout = vbox().apply {
        background = rounded(Col.CARD, dpf(12f))
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun linkText(s: String, onClick: () -> Unit): View = txt(s, 13f, Col.RED, true).apply {
        setPadding(0, dp(10), 0, dp(4))
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
