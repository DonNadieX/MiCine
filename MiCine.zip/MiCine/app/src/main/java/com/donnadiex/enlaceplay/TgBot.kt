package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * "Mi bot de Telegram": sigue la lista de tu canal que arma Mi Cine Bot.
 * Lo nuevo del canal se agrega solo, con portada y datos (igual que al pegar links).
 */
object TgBot {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun url(ctx: Context): String? = prefs(ctx).getString("bot_lista", null)?.takeIf { it.isNotBlank() }
    fun setUrl(ctx: Context, u: String?) = prefs(ctx).edit().putString("bot_lista", u?.trim()).apply()
    fun lastSync(ctx: Context) = prefs(ctx).getLong("bot_sync", 0)
    fun lastCount(ctx: Context) = prefs(ctx).getInt("bot_total", 0)

    fun isValid(u: String) = u.startsWith("http") && u.contains("/lista") && u.contains("k=")

    /** Baja la lista del bot (el servidor puede tardar unos segundos si estaba dormido). */
    private fun download(u: String): JSONObject {
        var last: Exception? = null
        repeat(2) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 20_000; c.readTimeout = 60_000
                c.setRequestProperty("User-Agent", USER_AGENT)
                try {
                    if (c.responseCode == 403) error("La clave del link no es correcta. Pídele al bot /app otra vez.")
                    if (c.responseCode !in 200..299) error("El bot respondió ${c.responseCode}")
                    return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                } finally { c.disconnect() }
            } catch (e: IllegalStateException) { throw e } catch (e: Exception) { last = e }
        }
        throw last ?: IllegalStateException("No se pudo conectar con el bot")
    }

    /** Agrega lo nuevo del canal. Devuelve cuántos videos nuevos hubo. */
    suspend fun sync(ctx: Context, onProgress: suspend (Int, Int, String) -> Unit = { _, _, _ -> }): Int {
        val u = url(ctx) ?: return 0
        val o = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { download(u) }
        if (o.optInt("micine_bot") != 1) error("Ese link no es de Mi Cine Bot")
        val arr = o.optJSONArray("items") ?: org.json.JSONArray()
        val lines = (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { Catalog.fileByUrl(it.optString("url")) == null }
            .map { ImportLine(it.optString("url"), it.optString("name")) }
        prefs(ctx).edit().putLong("bot_sync", System.currentTimeMillis()).putInt("bot_total", arr.length()).apply()
        if (lines.isEmpty()) return 0
        return Importer.runItems(ctx, lines, onProgress).added
    }

    /** Al abrir la app, como mucho cada 20 minutos. */
    suspend fun syncIfDue(ctx: Context): Int {
        if (url(ctx) == null || System.currentTimeMillis() - lastSync(ctx) < 20 * 60_000L) return 0
        return runCatching { sync(ctx) }.getOrDefault(0)
    }
}
