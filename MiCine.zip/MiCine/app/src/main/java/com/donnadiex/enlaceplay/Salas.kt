package com.donnadiex.enlaceplay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Inicio "Salas" (diseño S2 + S4): cada sección es una sala con la imagen panorámica de uno
 * de sus títulos de fondo, y sus tarjetas tienen su propio estilo:
 *   Películas = boletos de cine · Series = portadas apiladas · Novelas = marco fino y letra elegante
 *   Animadas = redonditas de colores · Anime = franja de manga · Asiáticas = sello con capítulos
 */
enum class Sala(val label: String, val color: Int, val bg: Int, val soft: Int) {
    PELICULAS("Películas", Color.parseColor("#F5A524"), Color.parseColor("#1C160A"), Color.parseColor("#E6D3A6")),
    SERIES("Series", Color.parseColor("#5EA2F5"), Color.parseColor("#0B1424"), Color.parseColor("#B6C9E8")),
    NOVELAS("Novelas", Color.parseColor("#F06AAA"), Color.parseColor("#1E0A16"), Color.parseColor("#E6B3CC")),
    ANIMADAS("Animadas", Color.parseColor("#5ED07E"), Color.parseColor("#0A1A10"), Color.parseColor("#B3DDBF")),
    ANIME("Anime", Color.parseColor("#A987F5"), Color.parseColor("#120D24"), Color.parseColor("#C9BDE8")),
    ASIATICAS("Asiáticas", Color.parseColor("#3FD3C2"), Color.parseColor("#071A19"), Color.parseColor("#A9D9D2"));

    /** Categoría con la que se abre "Ver todas". */
    val category: Category
        get() = when (this) {
            NOVELAS -> Category.NOVELA
            ANIMADAS -> Category.ANIMATED
            ANIME -> Category.ANIME
            ASIATICAS -> Category.ASIAN
            else -> Category.OTHER
        }

    companion object {
        fun of(t: Title): Sala = when (Category.of(t)) {
            Category.NOVELA -> NOVELAS
            Category.ANIMATED -> ANIMADAS
            Category.ANIME -> ANIME
            Category.ASIAN -> ASIATICAS
            Category.OTHER -> if (t.kind == Kind.MOVIE) PELICULAS else SERIES
        }

        /** Cambia cada vez que abres la app (la imagen de fondo de cada sala). */
        val sessionSeed = System.currentTimeMillis()
    }
}

/** Letras de las salas (vienen dentro de la app, licencia OFL en assets/licencias). */
object SalaFonts {
    private val cache = mutableMapOf<String, Typeface>()
    fun get(ctx: Context, file: String): Typeface = cache.getOrPut(file) {
        runCatching { Typeface.createFromAsset(ctx.assets, "fonts/$file") }.getOrDefault(Typeface.DEFAULT_BOLD)
    }
    fun cartelera(c: Context) = get(c, "sala_cartelera.ttf")
    fun novela(c: Context) = get(c, "sala_novela.ttf")
    fun novelaTexto(c: Context) = get(c, "sala_novela_texto.ttf")
    fun animada(c: Context) = get(c, "sala_animada.ttf")
}

/** Línea punteada del boleto. */
private class DashLine(private val color: Int, private val dash: Float, private val gap: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@DashLine.color }
    override fun draw(canvas: Canvas) {
        val b = bounds
        var x = b.left.toFloat()
        while (x < b.right) {
            canvas.drawRect(x, b.top.toFloat(), minOf(x + dash, b.right.toFloat()), b.bottom.toFloat(), p)
            x += dash + gap
        }
    }
    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class SalasHome(
    private val c: Context,
    private val cap: Int,
    private val open: (Title) -> Unit,
    private val seeAll: (Sala) -> Unit
) {
    private fun dp(v: Int) = c.dp(v)
    private fun dpf(v: Float) = c.dpf(v)
    private val white = Color.parseColor("#F3F3F5")

    private fun poster(img: ImageView, t: Title) {
        if (t.poster.isNullOrBlank()) img.show(null, t.localCover()) else img.show(t.poster)
    }

    private fun text(s: CharSequence, size: Float, color: Int, tf: Typeface = Typeface.DEFAULT, lines: Int = 1) =
        c.txt(s, size, color, false, lines).apply { typeface = tf }

    private fun clickable(v: View, t: Title) = v.apply {
        isClickable = true; isFocusable = true
        setOnClickListener { open(t) }
    }

    private fun neverWatched(t: Title) = Catalog.filesOf(t.id).none { it.watchedAt > 0 || it.finished }

    // ---------------- "Lo nuevo": historias con anillo del color de su sala ----------------
    fun stories(all: List<Title>): View {
        val box = c.vbox().apply { setPadding(0, dp(18), 0, 0) }
        box.addView(text("LO NUEVO", 12f, Col.MUTED, Typeface.DEFAULT_BOLD).apply {
            letterSpacing = 0.08f; setPadding(dp(18), 0, 0, dp(10))
        })
        val views = all.take(cap).map { t ->
            val col = c.vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
            val fresh = neverWatched(t)
            val ring = FrameLayout(c).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(3), if (fresh) Sala.of(t).color else Color.parseColor("#3A3A44"))
                }
            }
            val img = ImageView(c).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Col.CARD2) }
                clipToOutline = true
            }
            poster(img, t)
            ring.addView(img, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
            col.addView(ring, LinearLayout.LayoutParams(dp(66), dp(66)))
            col.addView(text(t.name, 11f, if (fresh) white else Col.MUTED).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
            }, LinearLayout.LayoutParams(dp(72), LinearLayout.LayoutParams.WRAP_CONTENT))
            clickable(col, t)
        }
        box.addView(c.hRow(views, 10).apply { setPadding(dp(14), 0, dp(14), 0) })
        return box
    }

    // ---------------- Una sala ----------------
    fun sala(s: Sala, list: List<Title>): View {
        val frame = FrameLayout(c).apply {
            background = rounded(s.bg, dpf(if (s == Sala.ANIMADAS) 28f else 22f))
            clipToOutline = true
        }
        // Imagen panorámica de uno de sus títulos (cambia cada vez que abres la app)
        val withArt = list.filter { it.fanart() != null }
        val back = ImageView(c)
        if (withArt.isNotEmpty()) {
            val pick = withArt[kotlin.random.Random(Sala.sessionSeed + s.ordinal).nextInt(withArt.size)]
            back.show(pick.fanart())
        } else back.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Col.blend(s.color, s.bg, 0.45f), s.bg)))
        frame.addView(back, FrameLayout.LayoutParams(MATCH, dp(230)))
        frame.addView(View(c).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                (s.bg and 0x00FFFFFF) or 0x1A000000, (s.bg and 0x00FFFFFF) or 0xB3000000.toInt(), s.bg))
        }, FrameLayout.LayoutParams(MATCH, dp(232)))
        if (s == Sala.ANIME) frame.addView(text("アニメ", 60f, Color.argb(30, 255, 255, 255), Typeface.DEFAULT_BOLD),
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = dp(36); rightMargin = dp(14) })

        val body = c.vbox().apply { setPadding(0, 0, 0, dp(16)) }
        body.addView(header(s, list), LinearLayout.LayoutParams(MATCH, WRAP).apply { leftMargin = dp(16); rightMargin = dp(10) })
        body.addView(c.hRow(list.take(cap).mapIndexed { i, t -> card(s, t, i) }, 12).apply {
            setPadding(dp(16), dp(12), dp(16), 0)
        })
        frame.addView(body, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(140) })
        frame.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(12); rightMargin = dp(12); topMargin = dp(14)
        }
        return frame
    }

    private fun header(s: Sala, list: List<Title>): View {
        val row = c.hbox().apply { gravity = Gravity.BOTTOM }
        val left = c.vbox()
        val n = list.size
        when (s) {
            Sala.PELICULAS -> {
                left.addView(text("CARTELERA", 42f, s.color, SalaFonts.cartelera(c)).apply { letterSpacing = 0.06f; includeFontPadding = false })
                left.addView(text("Películas · $n títulos", 12f, s.soft))
            }
            Sala.SERIES -> {
                val t = c.hbox()
                t.addView(View(c).apply { background = rounded(Color.parseColor("#3E8CF0"), dpf(3f)) }, LinearLayout.LayoutParams(dp(14), dp(14)))
                t.addView(text("Series", 30f, white, Typeface.create("sans-serif", Typeface.BOLD)).apply { setPadding(dp(10), 0, 0, 0) })
                left.addView(t)
                val sub = c.hbox()
                sub.addView(text("$n títulos", 12f, s.soft))
                val week = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
                val nuevos = list.count { tt -> Catalog.filesOf(tt.id).any { it.addedAt > week && it.watchedAt == 0L && !it.finished } }
                if (nuevos > 0) sub.addView(text("$nuevos con capítulos nuevos", 11f, s.bg, Typeface.DEFAULT_BOLD).apply {
                    background = rounded(s.color, dpf(10f)); setPadding(dp(8), dp(3), dp(8), dp(3))
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
                left.addView(sub, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
            }
            Sala.NOVELAS -> {
                left.addView(text("Novelas", 38f, s.color, SalaFonts.novela(c)).apply { includeFontPadding = false })
                val sub = c.hbox()
                sub.addView(View(c).apply { setBackgroundColor(s.color) }, LinearLayout.LayoutParams(dp(22), dp(1)))
                sub.addView(text("$n historias", 13f, s.soft, SalaFonts.novelaTexto(c)).apply { setPadding(dp(8), 0, 0, 0) })
                left.addView(sub)
            }
            Sala.ANIMADAS -> {
                left.addView(text("¡Animadas!", 32f, s.color, SalaFonts.animada(c)).apply { includeFontPadding = false })
                left.addView(text("$n títulos", 13f, s.soft, SalaFonts.animada(c)))
            }
            Sala.ANIME -> {
                val t = c.hbox().apply { gravity = Gravity.BOTTOM }
                t.addView(text("ANIME", 30f, s.color, Typeface.create("sans-serif", Typeface.BOLD)).apply { letterSpacing = 0.18f })
                t.addView(text("アニメ", 15f, s.soft).apply { setPadding(dp(10), 0, 0, dp(6)) })
                left.addView(t)
                left.addView(text("$n títulos", 12f, s.soft))
            }
            Sala.ASIATICAS -> {
                val t = c.hbox()
                t.addView(text("劇", 20f, s.color, Typeface.DEFAULT_BOLD).apply {
                    gravity = Gravity.CENTER
                    background = rounded(Color.TRANSPARENT, dpf(6f), dp(2), s.color)
                }, LinearLayout.LayoutParams(dp(40), dp(40)))
                val v = c.vbox().apply { setPadding(dp(12), 0, 0, 0) }
                v.addView(text("Asiáticas", 28f, white, Typeface.create("sans-serif-light", Typeface.NORMAL)).apply { letterSpacing = 0.03f })
                v.addView(text("Doramas · $n títulos", 12f, s.soft))
                t.addView(v)
                left.addView(t)
            }
        }
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val more = if (s == Sala.ANIMADAS)
            text("Ver todas", 14f, Color.parseColor("#08210F"), SalaFonts.animada(c)).apply {
                background = rounded(s.color, dpf(22f)); setPadding(dp(16), dp(10), dp(16), dp(10))
            }
        else text(if (s == Sala.ANIME) "Ver todos ›" else "Ver todas ›", 13f, s.color, Typeface.DEFAULT_BOLD).apply {
            setPadding(dp(8), dp(14), dp(8), dp(6))
        }
        more.isClickable = true; more.isFocusable = true
        more.setOnClickListener { seeAll(s) }
        row.addView(more)
        return row
    }

    // ---------------- Tarjetas, una por sala ----------------
    private fun card(s: Sala, t: Title, i: Int): View = clickable(when (s) {
        Sala.PELICULAS -> ticket(s, t)
        Sala.SERIES -> stacked(s, t)
        Sala.NOVELAS -> framed(s, t)
        Sala.ANIMADAS -> roundy(t, i)
        Sala.ANIME -> manga(s, t)
        Sala.ASIATICAS -> dorama(s, t)
    }, t)

    private fun imgBox(t: Title, radius: Float): FrameLayout = FrameLayout(c).apply {
        background = rounded(Col.CARD2, radius)
        clipToOutline = true
        val img = ImageView(c)
        poster(img, t)
        addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Película: boleto de cine con línea punteada y muescas. */
    private fun ticket(s: Sala, t: Title): View {
        val ink = Color.parseColor("#1A1305")
        val card = c.vbox().apply { background = rounded(s.color, dpf(8f)); clipToOutline = true; elevation = dpf(6f) }
        card.addView(imgBox(t, 0f), LinearLayout.LayoutParams(MATCH, dp(132)))
        val stub = FrameLayout(c).apply { clipChildren = false }
        stub.addView(View(c).apply { background = DashLine(ink, dpf(5f), dpf(3f)) }, FrameLayout.LayoutParams(MATCH, dp(2)))
        val dot = { g: Int -> View(c).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(s.bg) } } to g }
        listOf(dot(Gravity.START), dot(Gravity.END)).forEach { (v, g) ->
            stub.addView(v, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.TOP or g).apply {
                topMargin = -dp(5); if (g == Gravity.START) leftMargin = -dp(6) else rightMargin = -dp(6)
            })
        }
        val info = c.vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        info.addView(text(t.name, 12f, ink, Typeface.DEFAULT_BOLD))
        val dur = Catalog.filesOf(t.id).firstOrNull { it.durationMs > 0 }?.durationMs?.let { Fmt.duration(it) }
        info.addView(text(listOfNotNull(dur, t.year.takeIf { it > 0 }?.toString()).joinToString(" · ").ifBlank { "Película" }, 11f, ink))
        stub.addView(info, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
        card.addView(stub, LinearLayout.LayoutParams(MATCH, WRAP))
        card.layoutParams = LinearLayout.LayoutParams(dp(104), WRAP).apply { bottomMargin = dp(8) }
        return card
    }

    /** Serie: portadas apiladas (se nota que son muchos capítulos). */
    private fun stacked(s: Sala, t: Title): View {
        val box = c.vbox()
        val f = FrameLayout(c)
        f.addView(View(c).apply { background = rounded(Col.blend(s.color, s.bg, 0.7f), dpf(8f)) },
            FrameLayout.LayoutParams(dp(92), dp(138)).apply { leftMargin = dp(14) })
        f.addView(View(c).apply { background = rounded(Col.blend(s.color, s.bg, 0.5f), dpf(8f)) },
            FrameLayout.LayoutParams(dp(94), dp(140)).apply { leftMargin = dp(7); topMargin = dp(5) })
        val front = imgBox(t, dpf(8f)).apply { elevation = dpf(6f) }
        val files = Catalog.filesOf(t.id)
        val lastSeason = files.maxOfOrNull { it.season } ?: 0
        val badge = when {
            files.isEmpty() -> null
            lastSeason > 0 -> "T$lastSeason · ${files.count { it.season == lastSeason }}"
            else -> "${files.size} cap."
        }
        if (badge != null) front.addView(text(badge, 11f, white, Typeface.DEFAULT_BOLD).apply {
            background = rounded(Color.parseColor("#3E8CF0"), dpf(4f)); setPadding(dp(6), dp(2), dp(6), dp(2))
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(6); bottomMargin = dp(6) })
        f.addView(front, FrameLayout.LayoutParams(dp(96), dp(140)).apply { topMargin = dp(10) })
        box.addView(f, LinearLayout.LayoutParams(dp(108), dp(152)))
        box.addView(text(t.name, 13f, white, Typeface.DEFAULT_BOLD).apply { setPadding(0, dp(8), 0, 0) },
            LinearLayout.LayoutParams(dp(100), WRAP))
        return box
    }

    /** Novela: marco fino y letra elegante. */
    private fun framed(s: Sala, t: Title): View {
        val box = c.vbox().apply {
            background = rounded((s.bg and 0x00FFFFFF) or 0x99000000.toInt(), dpf(4f), dp(1), s.color)
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        box.addView(imgBox(t, dpf(2f)), LinearLayout.LayoutParams(MATCH, dp(136)))
        box.addView(text(t.name, 13f, white, SalaFonts.novelaTexto(c), 2).apply { setPadding(dp(2), dp(6), dp(2), 0) })
        box.layoutParams = LinearLayout.LayoutParams(dp(110), WRAP)
        return box
    }

    /** Animada: redondita y de colores (cada una de un color). */
    private fun roundy(t: Title, i: Int): View {
        val fills = listOf("#46C26A" to "#08210F", "#F5D33A" to "#2A2205", "#5EA2F5" to "#0A1A30")
        val (fill, ink) = fills[i % fills.size]
        val box = c.vbox().apply { background = rounded(Color.parseColor(fill), dpf(24f)); setPadding(dp(6), dp(6), dp(6), dp(8)) }
        box.addView(imgBox(t, dpf(18f)), LinearLayout.LayoutParams(MATCH, dp(132)))
        box.addView(text(t.name, 14f, Color.parseColor(ink), SalaFonts.animada(c)).apply { gravity = Gravity.CENTER; setPadding(dp(2), dp(6), dp(2), 0) })
        box.layoutParams = LinearLayout.LayoutParams(dp(108), WRAP)
        return box
    }

    /** Anime: franja vertical como en los mangas. */
    private fun manga(s: Sala, t: Title): View {
        val box = c.vbox()
        val card = c.hbox().apply { background = rounded(Col.CARD2, dpf(6f)); clipToOutline = true; elevation = dpf(6f) }
        val strip = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#9B6CF0")) }
        val files = Catalog.filesOf(t.id)
        val label = when {
            t.kind == Kind.MOVIE -> "PELÍCULA"
            files.isEmpty() -> "ANIME"
            else -> { val sn = files.maxOf { it.season }.coerceAtLeast(1); "T$sn · ${files.count { it.season == sn || sn == 1 && it.season == 0 }} EP" }
        }
        strip.addView(text(label, 11f, s.bg, Typeface.DEFAULT_BOLD).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.12f; rotation = 90f
        }, FrameLayout.LayoutParams(dp(166), dp(22), Gravity.CENTER))
        card.addView(strip, LinearLayout.LayoutParams(dp(22), MATCH))
        val img = ImageView(c)
        poster(img, t)
        card.addView(img, LinearLayout.LayoutParams(0, MATCH, 1f))
        box.addView(card, LinearLayout.LayoutParams(dp(112), dp(166)))
        box.addView(text(t.name, 12f, white, Typeface.DEFAULT_BOLD).apply { setPadding(0, dp(8), 0, 0) },
            LinearLayout.LayoutParams(dp(112), WRAP))
        return box
    }

    /** Asiática: línea arriba y sello con el número de episodios, estilo dorama. */
    private fun dorama(s: Sala, t: Title): View {
        val box = c.vbox()
        val f = imgBox(t, dpf(10f)).apply { elevation = dpf(6f) }
        f.addView(View(c).apply { setBackgroundColor(Color.parseColor("#22B8A8")) }, FrameLayout.LayoutParams(MATCH, dp(3), Gravity.TOP))
        val eps = Catalog.filesOf(t.id).size
        if (eps > 0 && t.kind != Kind.MOVIE) {
            val sp = SpannableString("$eps\nEP").apply {
                setSpan(RelativeSizeSpan(0.7f), length - 2, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            f.addView(text(sp, 12f, s.bg, Typeface.DEFAULT_BOLD, 2).apply {
                gravity = Gravity.CENTER; setLineSpacing(0f, 0.85f)
                background = rounded(Color.parseColor("#22B8A8"), dpf(4f))
            }, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        }
        box.addView(f, LinearLayout.LayoutParams(dp(108), dp(154)))
        box.addView(text(t.name, 13f, white).apply { setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(dp(108), WRAP))
        return box
    }
}
