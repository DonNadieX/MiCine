package com.donnadiex.enlaceplay

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.launch

class AddActivity : BaseActivity() {

    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var go: TextView
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), dp(2)) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        top.addView(txt("Agregar contenido", 18f, Col.TEXT, true), lp(0, WRAP, 1f))
        root.addView(top, lp())

        val scroll = ScrollView(this)
        val body = vbox(16)
        body.addView(txt("Pega uno o muchos links, uno por línea. La app lee el nombre de cada archivo y arma las series (con temporadas y episodios) y las películas.", 14f, Col.MUTED)
            .apply { setLineSpacing(0f, 1.2f) })

        body.addView(txt(
            "Ejemplos que entiende:\n" +
                "https://tuservidor/dl/abc123\n" +
                "Dark S01E03 - https://tuservidor/dl/abc123\n" +
                "Inception (2010) | https://tuservidor/dl/xyz",
            12f, Color.parseColor("#C8C8C8")
        ).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            background = rounded(Col.CARD, dpf(10f))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }, lp().apply { topMargin = dp(12) })

        body.addView(txt("Si el link no trae el nombre del archivo, escribe el nombre antes del link (como en los ejemplos).", 12f, Col.DIM)
            .apply { setPadding(0, dp(8), 0, 0) })

        input = EditText(this).apply {
            hint = "Pega aquí tus links…"
            setHintTextColor(Col.DIM)
            setTextColor(Col.TEXT)
            textSize = 13f
            gravity = Gravity.TOP
            minLines = 8
            background = rounded(Col.CARD2, dpf(10f), dp(1), Col.LINE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setText(intent.getStringExtra("text").orEmpty())
        }
        body.addView(input, lp().apply { topMargin = dp(14) })

        val row = hbox().apply { setPadding(0, dp(12), 0, 0) }
        row.addView(pill("Pegar", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!clip.isNullOrBlank()) {
                val cur = input.text.toString()
                input.setText(if (cur.isBlank()) clip else cur.trimEnd() + "\n" + clip)
            }
        }, lp(0, WRAP, 1f))
        go = pill("Agregar al catálogo", true, R.drawable.ic_add) { start() }
        row.addView(go, lp(0, WRAP, 2f).apply { leftMargin = dp(10) })
        body.addView(row, lp())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            max = 100
        }
        body.addView(progress, lp().apply { topMargin = dp(16) })
        status = txt("", 13f, Col.MUTED)
        body.addView(status, lp().apply { topMargin = dp(6) })

        body.addView(txt("Portadas y sinopsis desde: ${Meta.sourceName(this)}", 12f, Col.DIM)
            .apply { setPadding(0, dp(14), 0, 0) })

        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun start() {
        if (running) return
        val text = input.text.toString()
        val n = Importer.parseLines(text).size
        if (n == 0) { status.text = "No encontré links (deben empezar con http:// o https://)."; return }
        running = true
        go.alpha = 0.5f
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "Procesando $n links…"
        scope.launch {
            val r = runCatching {
                Importer.run(this@AddActivity, text) { done, total, msg ->
                    progress.progress = if (total > 0) done * 100 / total else 0
                    status.text = "$done / $total  ·  $msg"
                }
            }
            running = false
            go.alpha = 1f
            progress.visibility = View.GONE
            r.onSuccess { rep ->
                input.setText("")
                status.setTextColor(Col.TEXT)
                status.text = buildString {
                    append("Listo: ${rep.added} archivos agregados")
                    if (rep.newTitles > 0) append(" · ${rep.newTitles} títulos nuevos")
                    if (rep.matched > 0) append(" · ${rep.matched} con portada y sinopsis")
                    if (rep.duplicated > 0) append("\n${rep.duplicated} ya estaban en tu catálogo")
                    if (rep.errors.isNotEmpty()) append("\n\nAvisos:\n" + rep.errors.take(5).joinToString("\n"))
                }
                showDone()
            }.onFailure { status.text = "Error: ${it.message}" }
        }
    }

    private fun showDone() {
        val parent = status.parent as LinearLayout
        parent.addView(pill("Ver mi catálogo", true) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        }, lp().apply { topMargin = dp(16) })
    }
}
