package com.donnadiex.enlaceplay

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.AbsListView
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ScrollView

/**
 * Modo Proyector / TV:
 *  - Se activa solo en Android TV, en aparatos sin pantalla táctil o al detectar el control remoto
 *    (el HY300 usa un Android "de tablet", por eso hay detección extra e interruptor manual).
 *  - Escala la interfaz a 960×540 (el estándar de TV) sin importar la resolución del proyector.
 *  - Hace que TODO lo que se puede tocar se pueda elegir con las flechas del control, con un marco visible.
 */
object Tv {

    enum class Mode(val label: String) { AUTO("Automático"), ON("Siempre"), OFF("Nunca") }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    fun mode(ctx: Context): Mode = runCatching { Mode.valueOf(prefs(ctx).getString("modo_tv", "AUTO")!!) }.getOrDefault(Mode.AUTO)
    fun setMode(ctx: Context, m: Mode) = prefs(ctx).edit().putString("modo_tv", m.name).apply()

    /** ¿El aparato parece TV/proyector por sí mismo? */
    fun looksLikeTv(ctx: Context): Boolean {
        val ui = (ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager)?.currentModeType
        if (ui == Configuration.UI_MODE_TYPE_TELEVISION) return true
        val pm = ctx.packageManager
        if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return true
        if (!pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) return true
        // Ya detectamos el control remoto antes en este aparato
        return prefs(ctx).getBoolean("control_detectado", false)
    }

    fun enabled(ctx: Context): Boolean = when (mode(ctx)) {
        Mode.ON -> true
        Mode.OFF -> false
        Mode.AUTO -> looksLikeTv(ctx)
    }

    /** Se cachea por pantalla: [BaseActivity] lo fija al crearse. */
    @Volatile var on = false

    fun markRemoteDetected(ctx: Context) = prefs(ctx).edit().putBoolean("control_detectado", true).apply()
    fun askedAboutRemote(ctx: Context) = prefs(ctx).getBoolean("pregunta_control", false)
    fun setAskedAboutRemote(ctx: Context) = prefs(ctx).edit().putBoolean("pregunta_control", true).apply()

    /** Contexto con densidad ajustada para que la pantalla mida 960 dp de ancho, como Android TV. */
    fun wrap(base: Context): Context {
        if (!enabled(base)) return base
        val dm = base.resources.displayMetrics
        val longSide = maxOf(dm.widthPixels, dm.heightPixels)
        if (longSide <= 0) return base
        val conf = Configuration(base.resources.configuration)
        conf.densityDpi = (longSide * 160 / 960).coerceIn(120, 640)
        return base.createConfigurationContext(conf)
    }

    // ---------------- Foco visible ----------------

    private const val MARK = "tv_focus"

    private fun focusFrame(v: View): GradientDrawable = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        cornerRadius = v.context.r().coerceAtLeast(v.context.dpf(6f))
        setStroke(v.context.dp(3), Color.WHITE)
    }

    private fun insideList(v: View): Boolean {
        var p = v.parent
        while (p is View) {
            if (p is AbsListView) return true
            p = p.parent
        }
        return false
    }

    /** Recorre la pantalla y prepara cada elemento tocable para el control remoto. */
    fun prepare(v: View) {
        if (v is AbsListView) prepareList(v)
        if (v.tag != MARK && v !is EditText && (v.isClickable || v.hasOnClickListeners()) && !insideList(v)) {
            v.tag = MARK
            v.isFocusable = true
            v.isFocusableInTouchMode = false
            v.setOnFocusChangeListener { view, has ->
                view.foreground = if (has) focusFrame(view) else null
                val s = if (has) 1.05f else 1f
                view.animate().scaleX(s).scaleY(s).setDuration(120).start()
                if (has) {
                    (view.parent as? ViewGroup)?.let { it.clipChildren = false; it.clipToPadding = false }
                    view.translationZ = if (has) 8f else 0f
                } else view.translationZ = 0f
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) prepare(v.getChildAt(i))
    }

    private fun prepareList(l: AbsListView) {
        if (l.tag == MARK) return
        l.tag = MARK
        l.isFocusable = true
        l.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        l.setDrawSelectorOnTop(true)
        l.selector = focusFrame(l)
        l.setOnFocusChangeListener { lv, has -> (lv as AbsListView).selector = if (has) focusFrame(lv) else ColorDrawable(Color.TRANSPARENT) }
    }

    /** Se instala en cada pantalla: vuelve a preparar lo que se dibuje y da el foco inicial. */
    fun install(activity: Activity, root: View) {
        if (!on) return
        root.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                prepare(root)
                if (activity.currentFocus == null || !activity.currentFocus!!.isShown) firstFocus(root)?.requestFocus()
            }
        })
    }

    /** El primer elemento elegible que no sea un campo de texto (para no abrir el teclado solo). */
    fun firstFocus(v: View): View? {
        if (!v.isShown) return null
        if (v.isFocusable && v !is EditText && v !is ScrollView && v !is HorizontalScrollView && v.tag == MARK) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) firstFocus(v.getChildAt(i))?.let { return it }
        return null
    }

    @Suppress("unused")
    fun isAndroidTv() = Build.VERSION.SDK_INT >= 21
}
