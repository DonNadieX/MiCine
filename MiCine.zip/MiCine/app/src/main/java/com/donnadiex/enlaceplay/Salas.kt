package com.donnadiex.enlaceplay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Inicio "Salas" (diseño S2 + S4): cada sección es una sala con la imagen panorámica de uno
 * de sus títulos de fondo, y sus tarjetas tienen su propio estilo:
 *   Películas = boletos de cine · Series = portadas apiladas · Novelas = marco fino y letra elegante
 *   Animadas = redonditas de colores · Anime = franja de manga · Asiáticas = sello con capítulos
 *   Mi lista = fotos instantáneas escritas a mano · Sagas = colecciones en abanico
 */
enum class Sala(val label: String, val color: Int, val bg: Int, val soft: Int) {
    PELICULAS("Películas", Color.parseColor("#F5A524"), Color.parseColor("#1C160A"), Color.parseColor("#E6D3A6")),
    SERIES("Series", Color.parseColor("#5EA2F5"), Color.parseColor("#0B1424"), Color.parseColor("#B6C9E8")),
    NOVELAS("Novelas", Color.parseColor("#F06AAA"), Color.parseColor("#1E0A16"), Color.parseColor("#E6B3CC")),
    ANIMADAS("Animadas", Color.parseColor("#5ED07E"), Color.parseColor("#0A1A10"), Color.parseColor("#B3DDBF")),
    ANIME("Anime", Color.parseColor("#A987F5"), Color.parseColor("#120D24"), Color.parseColor("#C9BDE8")),
    ASIATICAS("Asiáticas", Color.parseColor("#3FD3C2"), Color.parseColor("#071A19"), Color.parseColor("#A9D9D2")),
    MI_LISTA("Mi lista", Color.parseColor("#FF6B7D"), Color.parseColor("#1F0A0E"), Color.parseColor("#F2B8C0")),
    SAGAS("Sagas", Color.parseColor("#C9D3DC"), Color.parseColor("#0E1318"), Color.parseColor("#9FB0BF"));

    /** Categoría con la que se abre "Ver todas". */
    val category: Category?
        get() = when (this) {
            NOVELAS -> Category.NOVELA
            ANIMADAS -> Category.ANIMATED
            ANIME -> Category.ANIME
            ASIATICAS -> Category.ASIAN
            PELICULAS, SERIES -> Category.OTHER
            else -> null
        }

    companion object {
        /** Las salas de contenido, en el orden del inicio. */
        val content = listOf(PELICULAS, SERIES, NOVELAS, ANIMADAS, ANIME, ASIATICAS)

        fun of(t: Title): Sala = when (Category.of(t)) {
            Category.NOVELA -> NOVELAS
            Category.ANIMATED -> ANIMADAS
            Category.ANIME -> ANIME
            Category.ASIAN -> ASIATICAS
            Category.OTHER -> if (t.kind == Kind.MOVIE) PELICULAS else SERIES
        }

        /** La sala de una lista filtrada (pestaña + categoría elegida). */
        fun forScreen(movies: Boolean?, cat: Category?): Sala? = when (cat) {
            Category.NOVELA -> NOVELAS
            Category.ANIMATED -> ANIMADAS
            Category.ANIME -> ANIME
            Category.ASIAN -> ASIATICAS
            else -> when (movies) { true -> PELICULAS; false -> SERIES; null -> null }
        }

        /** Cambia cada vez que abres la app (la imagen de fondo de cada sala). */
        val sessionSeed = System.currentTimeMillis()
    }
}

/** Letras de las salas (vienen dentro de la app, licencia OFL en assets/licencias). */
object SalaFonts {
    private val cache = mutableMapOf<String, Typeface>()
    fun get(ctx: Context, file: String): Typeface = cache.getOrPut(file) {
        runCatching { Typeface.createFromAsset(ctx.assets, "fonts/$file") }.getOrDefault(Typeface.DEFAULT_BOLD)
    }
    fun cartelera(c: Context) = get(c, "sala_cartelera.ttf")
    fun novela(c: Context) = get(c, "sala_novela.ttf")
    fun novelaTexto(c: Context) = get(c, "sala_novela_texto.ttf")
    fun animada(c: Context) = get(c, "sala_animada.ttf")
    fun mano(c: Context) = get(c, "sala_mano.ttf")
}

/** Línea punteada del boleto. */
private class DashLine(private val color: Int, private val dash: Float, private val gap: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@DashLine.color }
    override fun draw(canvas: Canvas) {
        val b = bounds
        var x = b.left.toFloat()
        while (x < b.right) {
            canvas.drawRect(x, b.top.toFloat(), minOf(x + dash, b.right.toFloat()), b.bottom.toFloat(), p)
            x += dash + gap
        }
    }
    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class SalasHome(
    private val c: Context,
    private val cap: Int,
    private val open: (Title) -> Unit
) {
    private fun dp(v: Int) = c.dp(v)
    private fun dpf(v: Float) = c.dpf(v)
    private val white = Color.parseColor("#F3F3F5")

    private fun poster(img: ImageView, t: Title) {
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        if (t.poster.isNullOrBlank()) img.show(null, t.localCover()) else img.show(t.poster)
    }

    private fun text(s: CharSequence, size: Float, color: Int, tf: Typeface = Typeface.DEFAULT, lines: Int = 1) =
        c.txt(s, size, color, false, lines).apply { typeface = tf }

    /** Títulos grandes en dp: no se cortan aunque el celular tenga la letra en grande. */
    private fun display(s: String, sizeDp: Float, color: Int, tf: Typeface, spacing: Float = 0f) = TextView(c).apply {
        text = s; setTextColor(color); typeface = tf; letterSpacing = spacing
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, sizeDp)
        includeFontPadding = false; maxLines = 1
    }

    private fun clickable(v: View, t: Title, onOpen: (Title) -> Unit = open) = v.apply {
        isClickable = true; isFocusable = true
        setOnClickListener { onOpen(t) }
    }

    private fun neverWatched(t: Title) = Catalog.filesOf(t.id).none { it.watchedAt > 0 || it.finished }

    // ---------------- "Lo nuevo": historias con anillo del color de su sala ----------------
    fun stories(all: List<Title>): View {
        val box = c.vbox().apply { setPadding(0, dp(18), 0, 0) }
        box.addView(text("LO NUEVO", 12f, Col.MUTED, Typeface.DEFAULT_BOLD).apply {
            letterSpacing = 0.08f; setPadding(dp(18), 0, 0, dp(10))
        })
        val views = all.take(cap).map { t ->
            val col = c.vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
            val fresh = neverWatched(t)
            val ring = FrameLayout(c).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(3), if (fresh) Sala.of(t).color else Color.parseColor("#3A3A44"))
                }
            }
            val img = ImageView(c).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Col.CARD2) }
                clipToOutline = true
            }
            poster(img, t)
            ring.addView(img, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
            col.addView(ring, LinearLayout.LayoutParams(dp(66), dp(66)))
            col.addView(text(t.name, 11f, if (fresh) white else Col.MUTED).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
            }, LinearLayout.LayoutParams(dp(72), LinearLayout.LayoutParams.WRAP_CONTENT))
            clickable(col, t)
        }
        box.addView(c.hRow(views, 10))
        return box
    }

    // ---------------- Fondo de sala (imagen + degradado) ----------------
    private fun backdrop(frame: FrameLayout, s: Sala, art: List<Title>, h: Int) {
        val withArt = art.filter { it.fanart() != null }
        val back = ImageView(c)
        if (withArt.isNotEmpty()) {
            val pick = withArt[kotlin.random.Random(Sala.sessionSeed + s.ordinal).nextInt(withArt.size)]
            back.show(pick.fanart())
        } else back.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Col.blend(s.color, s.bg, 0.45f), s.bg)))
        frame.addView(back, FrameLayout.LayoutParams(MATCH, h))
        frame.addView(View(c).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                (s.bg and 0x00FFFFFF) or 0x1A000000, (s.bg and 0x00FFFFFF) or 0xB3000000.toInt(), s.bg))
        }, FrameLayout.LayoutParams(MATCH, h + dp(2)))
        if (s == Sala.ANIME) frame.addView(display("アニメ", 60f, Color.argb(30, 255, 255, 255), Typeface.DEFAULT_BOLD),
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = dp(36); rightMargin = dp(14) })
    }

    /** El nombre de la sala, cada uno con su letra. */
    private fun titleView(s: Sala, scale: Float = 1f): View = when (s) {
        Sala.PELICULAS -> display("CARTELERA", 44f * scale, s.color, SalaFonts.cartelera(c), 0.04f)
        Sala.SERIES -> c.hbox().apply {
            addView(View(c).apply { background = rounded(Color.parseColor("#3E8CF0"), dpf(3f)) }, LinearLayout.LayoutParams(dp(14), dp(14)))
            addView(display("Series", 32f * scale, white, Typeface.create("sans-serif", Typeface.BOLD)).apply { setPadding(dp(10), 0, 0, 0) })
        }
        Sala.NOVELAS -> display("Novelas", 40f * scale, s.color, SalaFonts.novela(c))
        Sala.ANIMADAS -> display("¡Animadas!", 34f * scale, s.color, SalaFonts.animada(c))
        Sala.ANIME -> c.hbox().apply {
            gravity = Gravity.BOTTOM
            addView(display("ANIME", 32f * scale, s.color, Typeface.create("sans-serif", Typeface.BOLD), 0.18f))
            addView(display("アニメ", 16f * scale, s.soft, Typeface.DEFAULT).apply { setPadding(dp(10), 0, 0, dp(4)) })
        }
        Sala.ASIATICAS -> c.hbox().apply {
            addView(display("劇", 20f, s.color, Typeface.DEFAULT_BOLD).apply {
                gravity = Gravity.CENTER
                background = rounded(Color.TRANSPARENT, dpf(6f), dp(2), s.color)
            }, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(display("Asiáticas", 30f * scale, white, Typeface.create("sans-serif-light", Typeface.NORMAL), 0.03f)
                .apply { setPadding(dp(12), 0, 0, 0) })
        }
        Sala.MI_LISTA -> c.hbox().apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(display("♥", 30f * scale, s.color, Typeface.DEFAULT_BOLD))
            addView(display("Mi lista", 40f * scale, white, SalaFonts.mano(c)).apply { setPadding(dp(10), dp(6), 0, 0) })
        }
        Sala.SAGAS -> display("SAGAS", 44f * scale, s.color, SalaFonts.cartelera(c), 0.14f)
    }

    private fun subtitle(s: Sala, n: Int, extra: Int = 0): View {
        val tf = when (s) {
            Sala.NOVELAS -> SalaFonts.novelaTexto(c)
            Sala.ANIMADAS -> SalaFonts.animada(c)
            else -> Typeface.DEFAULT
        }
        val label = when (s) {
            Sala.PELICULAS -> "Películas · $n títulos"
            Sala.NOVELAS -> "$n historias"
            Sala.ASIATICAS -> "Doramas · $n títulos"
            Sala.MI_LISTA -> "$n guardados"
            Sala.SAGAS -> "$n colecciones · $extra películas"
            else -> "$n títulos"
        }
        val row = c.hbox()
        if (s == Sala.NOVELAS) row.addView(View(c).apply { setBackgroundColor(s.color) }, LinearLayout.LayoutParams(dp(22), dp(1)).apply { rightMargin = dp(8) })
        row.addView(text(label, if (s == Sala.NOVELAS) 13f else 12f, s.soft, tf))
        if (s == Sala.SERIES && extra > 0) row.addView(text("$extra con capítulos nuevos", 11f, s.bg, Typeface.DEFAULT_BOLD).apply {
            background = rounded(s.color, dpf(10f)); setPadding(dp(8), dp(3), dp(8), dp(3))
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(8) })
        return row
    }

    private fun seeAllButton(s: Sala, onSeeAll: () -> Unit): View {
        val more = if (s == Sala.ANIMADAS)
            text("Ver todas", 14f, Color.parseColor("#08210F"), SalaFonts.animada(c)).apply {
                background = rounded(s.color, dpf(22f)); setPadding(dp(16), dp(8), dp(16), dp(8))
            }
        else text(if (s == Sala.ANIME || s == Sala.MI_LISTA) "Ver todos ›" else "Ver todas ›", 13f, s.color, Typeface.DEFAULT_BOLD).apply {
            setPadding(dp(8), dp(8), dp(4), dp(8))
        }
        more.isClickable = true; more.isFocusable = true
        more.setOnClickListener { onSeeAll() }
        return more
    }

    private fun seriesWithNew(list: List<Title>): Int {
        val week = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        return list.count { tt -> tt.kind == Kind.SERIES && Catalog.filesOf(tt.id).any { it.addedAt > week && it.watchedAt == 0L && !it.finished } }
    }

    /** Encabezado: el nombre en su propia línea (nunca se corta) y abajo los datos + "Ver todas". */
    private fun header(s: Sala, n: Int, extra: Int, onSeeAll: (() -> Unit)?): View {
        val box = c.vbox()
        box.addView(titleView(s), LinearLayout.LayoutParams(MATCH, WRAP))
        val row = c.hbox()
        row.addView(subtitle(s, n, extra), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (onSeeAll != null) row.addView(seeAllButton(s, onSeeAll))
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        return box
    }

    private fun salaFrame(s: Sala): FrameLayout = FrameLayout(c).apply {
        background = rounded(s.bg, dpf(if (s == Sala.ANIMADAS) 28f else 22f))
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { leftMargin = dp(12); rightMargin = dp(12); topMargin = dp(14) }
    }

    // ---------------- Una sala del inicio ----------------
    fun sala(s: Sala, list: List<Title>, onSeeAll: () -> Unit): View {
        val frame = salaFrame(s)
        backdrop(frame, s, list, dp(230))
        val body = c.vbox().apply { setPadding(0, 0, 0, dp(16)) }
        val extra = if (s == Sala.SERIES) seriesWithNew(list) else 0
        body.addView(header(s, list.size, extra, onSeeAll), LinearLayout.LayoutParams(MATCH, WRAP).apply { leftMargin = dp(16); rightMargin = dp(12) })
        body.addView(c.hRow(list.take(cap).mapIndexed { i, t -> card(s, t, i, dp(108)) }, 12).apply {
            setPadding(dp(16), dp(12), dp(16), dp(6))
        })
        frame.addView(body, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(130) })
        return frame
    }

    /** Sala de Sagas en el inicio. */
    fun sagas(list: List<Sagas.Saga>, onOpen: (Sagas.Saga) -> Unit, onSeeAll: () -> Unit): View {
        val s = Sala.SAGAS
        val frame = salaFrame(s)
        backdrop(frame, s, list.flatMap { it.titles }, dp(230))
        val body = c.vbox().apply { setPadding(0, 0, 0, dp(16)) }
        body.addView(header(s, list.size, list.sumOf { it.titles.size }, onSeeAll),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { leftMargin = dp(16); rightMargin = dp(12) })
        body.addView(c.hRow(list.take(cap).map { sg -> sagaCard(sg, dp(124)) { onOpen(sg) } }, 14).apply {
            setPadding(dp(16), dp(12), dp(16), dp(6))
        })
        frame.addView(body, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(130) })
        return frame
    }

    /** Encabezado de una pantalla completa (Películas, Novelas, Mi lista…): imagen + nombre con su letra. */
    fun banner(s: Sala, list: List<Title>, count: Int, extra: Int = 0, label: String? = null): View {
        val frame = FrameLayout(c).apply {
            background = rounded(s.bg, dpf(20f)); clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { leftMargin = dp(12); rightMargin = dp(12); topMargin = dp(8) }
        }
        backdrop(frame, s, list, dp(120))
        val body = c.vbox().apply { setPadding(dp(16), 0, dp(12), dp(12)) }
        if (label != null) {
            body.addView(display(label, 30f, s.color, if (s == Sala.SAGAS) SalaFonts.cartelera(c) else Typeface.DEFAULT_BOLD, 0.02f).apply {
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            body.addView(text("Saga", 12f, s.soft))
        } else {
            body.addView(titleView(s, 0.85f))
            body.addView(subtitle(s, count, if (s == Sala.SERIES) seriesWithNew(list) else extra),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        }
        frame.addView(body, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(56) })
        return frame
    }

    // ---------------- Tarjetas ----------------
    /** Tarjeta de un título con el estilo de [s]; [w] = ancho en px (en listas y en el inicio). */
    fun card(s: Sala, t: Title, i: Int, w: Int, onOpen: (Title) -> Unit = open): View = clickable(when (s) {
        Sala.PELICULAS -> ticket(s, t, w)
        Sala.SERIES -> stacked(s, t, w)
        Sala.NOVELAS -> framed(s, t, w)
        Sala.ANIMADAS -> roundy(t, i, w)
        Sala.ANIME -> manga(s, t, w)
        Sala.ASIATICAS -> dorama(s, t, w)
        Sala.MI_LISTA -> polaroid(s, t, i, w)
        Sala.SAGAS -> ticket(Sala.PELICULAS, t, w)
    }, t, onOpen)

    private fun imgBox(t: Title, radius: Float): FrameLayout = FrameLayout(c).apply {
        background = rounded(Col.CARD2, radius)
        clipToOutline = true
        val img = ImageView(c)
        poster(img, t)
        addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun sized(v: View, w: Int): View = v.apply { layoutParams = LinearLayout.LayoutParams(w, WRAP).apply { bottomMargin = dp(6) } }

    /** Película: boleto de cine con línea punteada y muescas. */
    private fun ticket(s: Sala, t: Title, w: Int): View {
        val ink = Color.parseColor("#1A1305")
        val card = c.vbox().apply { background = rounded(s.color, dpf(8f)); clipToOutline = true; elevation = dpf(4f) }
        card.addView(imgBox(t, 0f), LinearLayout.LayoutParams(MATCH, (w * 1.3f).toInt()))
        val stub = FrameLayout(c).apply { clipChildren = false }
        stub.addView(View(c).apply { background = DashLine(ink, dpf(5f), dpf(3f)) }, FrameLayout.LayoutParams(MATCH, dp(2)))
        listOf(Gravity.START, Gravity.END).forEach { g ->
            stub.addView(View(c).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Col.blend(s.bg, Col.BG, 0.5f)) } },
                FrameLayout.LayoutParams(dp(12), dp(12), Gravity.TOP or g).apply {
                    topMargin = -dp(5); if (g == Gravity.START) leftMargin = -dp(6) else rightMargin = -dp(6)
                })
        }
        val info = c.vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        info.addView(text(t.name, 12f, ink, Typeface.DEFAULT_BOLD))
        val dur = Catalog.filesOf(t.id).firstOrNull { it.durationMs > 0 }?.durationMs?.let { Fmt.duration(it) }
        info.addView(text(listOfNotNull(dur, t.year.takeIf { it > 0 }?.toString()).joinToString(" · ").ifBlank { "Película" }, 11f, ink))
        stub.addView(info, FrameLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(2) })
        card.addView(stub, LinearLayout.LayoutParams(MATCH, WRAP))
        return sized(card, w)
    }

    /** Serie: portadas apiladas (se nota que son muchos capítulos). */
    private fun stacked(s: Sala, t: Title, w: Int): View {
        val box = c.vbox()
        val fw = w - dp(14)
        val fh = (fw * 1.45f).toInt()
        val f = FrameLayout(c)
        f.addView(View(c).apply { background = rounded(Col.blend(s.color, s.bg, 0.7f), dpf(8f)) },
            FrameLayout.LayoutParams(fw - dp(4), fh - dp(2)).apply { leftMargin = dp(14) })
        f.addView(View(c).apply { background = rounded(Col.blend(s.color, s.bg, 0.5f), dpf(8f)) },
            FrameLayout.LayoutParams(fw - dp(2), fh).apply { leftMargin = dp(7); topMargin = dp(5) })
        val front = imgBox(t, dpf(8f)).apply { elevation = dpf(4f) }
        val files = Catalog.filesOf(t.id)
        val lastSeason = files.maxOfOrNull { it.season } ?: 0
        val badge = when {
            files.isEmpty() -> null
            lastSeason > 0 -> "T$lastSeason · ${files.count { it.season == lastSeason }}"
            else -> "${files.size} cap."
        }
        if (badge != null) front.addView(text(badge, 11f, white, Typeface.DEFAULT_BOLD).apply {
            background = rounded(Color.parseColor("#3E8CF0"), dpf(4f)); setPadding(dp(6), dp(2), dp(6), dp(2))
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(6); bottomMargin = dp(6) })
        f.addView(front, FrameLayout.LayoutParams(fw, fh).apply { topMargin = dp(10) })
        box.addView(f, LinearLayout.LayoutParams(w, fh + dp(10)))
        box.addView(text(t.name, 13f, white, Typeface.DEFAULT_BOLD).apply { setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(w, WRAP))
        return sized(box, w)
    }

    /** Novela: marco fino y letra elegante. */
    private fun framed(s: Sala, t: Title, w: Int): View {
        val box = c.vbox().apply {
            background = rounded((s.bg and 0x00FFFFFF) or 0x99000000.toInt(), dpf(4f), dp(1), s.color)
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        box.addView(imgBox(t, dpf(2f)), LinearLayout.LayoutParams(MATCH, ((w - dp(8)) * 1.36f).toInt()))
        box.addView(text(t.name, 13f, white, SalaFonts.novelaTexto(c), 2).apply { setPadding(dp(2), dp(6), dp(2), 0) })
        return sized(box, w)
    }

    /** Animada: redondita y de colores (cada una de un color). */
    private fun roundy(t: Title, i: Int, w: Int): View {
        val fills = listOf("#46C26A" to "#08210F", "#F5D33A" to "#2A2205", "#5EA2F5" to "#0A1A30")
        val (fill, ink) = fills[i % fills.size]
        val box = c.vbox().apply { background = rounded(Color.parseColor(fill), dpf(24f)); setPadding(dp(6), dp(6), dp(6), dp(8)) }
        box.addView(imgBox(t, dpf(18f)), LinearLayout.LayoutParams(MATCH, ((w - dp(12)) * 1.38f).toInt()))
        box.addView(text(t.name, 14f, Color.parseColor(ink), SalaFonts.animada(c)).apply { gravity = Gravity.CENTER; setPadding(dp(2), dp(6), dp(2), 0) })
        return sized(box, w)
    }

    /** Anime: franja vertical como en los mangas. */
    private fun manga(s: Sala, t: Title, w: Int): View {
        val box = c.vbox()
        val h = (w * 1.48f).toInt()
        val card = c.hbox().apply { background = rounded(Col.CARD2, dpf(6f)); clipToOutline = true; elevation = dpf(4f) }
        val strip = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#9B6CF0")) }
        val files = Catalog.filesOf(t.id)
        val label = when {
            t.kind == Kind.MOVIE -> "PELÍCULA"
            files.isEmpty() -> "ANIME"
            else -> { val sn = files.maxOf { it.season }; "T${sn.coerceAtLeast(1)} · ${files.count { it.season == sn }} EP" }
        }
        strip.addView(text(label, 11f, s.bg, Typeface.DEFAULT_BOLD).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.12f; rotation = 90f
        }, FrameLayout.LayoutParams(h, dp(22), Gravity.CENTER))
        card.addView(strip, LinearLayout.LayoutParams(dp(22), MATCH))
        val img = ImageView(c)
        poster(img, t)
        card.addView(img, LinearLayout.LayoutParams(0, MATCH, 1f))
        box.addView(card, LinearLayout.LayoutParams(w, h))
        box.addView(text(t.name, 12f, white, Typeface.DEFAULT_BOLD).apply { setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(w, WRAP))
        return sized(box, w)
    }

    /** Asiática: línea arriba y sello con el número de episodios, estilo dorama. */
    private fun dorama(s: Sala, t: Title, w: Int): View {
        val box = c.vbox()
        val f = imgBox(t, dpf(10f)).apply { elevation = dpf(4f) }
        f.addView(View(c).apply { setBackgroundColor(Color.parseColor("#22B8A8")) }, FrameLayout.LayoutParams(MATCH, dp(3), Gravity.TOP))
        val eps = Catalog.filesOf(t.id).size
        if (eps > 0 && t.kind != Kind.MOVIE) {
            val sp = SpannableString("$eps\nEP").apply {
                setSpan(RelativeSizeSpan(0.7f), length - 2, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            f.addView(text(sp, 12f, s.bg, Typeface.DEFAULT_BOLD, 2).apply {
                gravity = Gravity.CENTER; setLineSpacing(0f, 0.85f)
                background = rounded(Color.parseColor("#22B8A8"), dpf(4f))
            }, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        }
        box.addView(f, LinearLayout.LayoutParams(w, (w * 1.43f).toInt()))
        box.addView(text(t.name, 13f, white).apply { setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(w, WRAP))
        return sized(box, w)
    }

    /** Mi lista: foto instantánea con el nombre escrito a mano, un poco chueca. */
    private fun polaroid(s: Sala, t: Title, i: Int, w: Int): View {
        val holder = FrameLayout(c).apply { setPadding(dp(3), dp(4), dp(3), dp(4)); clipChildren = false }
        val card = c.vbox().apply {
            background = rounded(Color.parseColor("#F7F3EC"), dpf(3f)); elevation = dpf(5f)
            setPadding(dp(6), dp(6), dp(6), dp(4))
            rotation = if (i % 2 == 0) -2.5f else 2f
        }
        val inner = w - dp(6) - dp(12)
        card.addView(imgBox(t, dpf(1f)), LinearLayout.LayoutParams(MATCH, (inner * 1.3f).toInt()))
        card.addView(text(t.name, 17f, Color.parseColor("#2B2B33"), SalaFonts.mano(c)).apply {
            gravity = Gravity.CENTER; setPadding(dp(2), dp(4), dp(2), 0)
        })
        holder.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        holder.addView(text("♥", 14f, s.color, Typeface.DEFAULT_BOLD).apply {
            gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#F7F3EC")) }
            elevation = dpf(6f)
        }, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END))
        return sized(holder, w)
    }

    /** Saga: sus pósters en abanico, con cuántas películas tiene. */
    fun sagaCard(sg: Sagas.Saga, w: Int, onClick: () -> Unit): View {
        val box = c.vbox()
        val pw = (w * 0.68f).toInt()
        val ph = (pw * 1.48f).toInt()
        val fan = FrameLayout(c).apply { clipChildren = false }
        val shown = sg.titles.take(3)
        val order = when (shown.size) { 1 -> listOf(0); 2 -> listOf(1, 0); else -> listOf(1, 2, 0) }
        order.forEach { idx ->
            val t = shown[idx]
            val p = imgBox(t, dpf(6f)).apply {
                elevation = dpf(if (idx == 0) 6f else 3f)
                rotation = when { shown.size == 1 || idx == 0 -> 0f; idx == 1 -> -9f; else -> 9f }
                translationX = when { shown.size == 1 || idx == 0 -> 0f; idx == 1 -> -w * 0.14f; else -> w * 0.14f }
            }
            fan.addView(p, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))
        }
        fan.addView(text("${sg.titles.size} películas", 11f, Sala.SAGAS.bg, Typeface.DEFAULT_BOLD).apply {
            background = rounded(Sala.SAGAS.color, dpf(10f)); setPadding(dp(8), dp(3), dp(8), dp(3)); elevation = dpf(8f)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(2) })
        box.addView(fan, LinearLayout.LayoutParams(w, ph + dp(16)))
        box.addView(text(sg.name, 13f, white, Typeface.DEFAULT_BOLD).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) },
            LinearLayout.LayoutParams(w, WRAP))
        if (sg.years.isNotBlank()) box.addView(text(sg.years, 11f, Sala.SAGAS.soft).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(w, WRAP))
        box.isClickable = true; box.isFocusable = true
        box.setOnClickListener { onClick() }
        return sized(box, w)
    }
}
