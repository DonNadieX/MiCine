package com.donnadiex.enlaceplay

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Nav {
    fun title(c: Context, id: String) =
        c.startActivity(Intent(c, TitleActivity::class.java).putExtra("id", id))

    fun play(c: Context, fileId: String) =
        c.startActivity(Intent(c, PlayerActivity::class.java).putExtra("file", fileId))

    fun info(c: Context, fileId: String) =
        c.startActivity(Intent(c, FileInfoActivity::class.java).putExtra("file", fileId))
}

class MainActivity : BaseActivity() {

    private enum class Tab(val label: String) { HOME("Inicio"), SERIES("Series"), MOVIES("Películas"), MYLIST("Mi lista") }

    private var tab = Tab.HOME
    private var query: String? = null
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var topBar: LinearLayout
    private val tabViews = mutableMapOf<Tab, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox().apply { setBackgroundColor(Col.BG) }

        topBar = hbox().apply { setPadding(dp(14), dp(10), dp(6), dp(4)) }
        root.addView(topBar, lp())
        buildTopBar()

        val tabs = hbox().apply { setPadding(dp(8), 0, dp(8), 0) }
        Tab.values().forEach { t ->
            val tv = txt(t.label, 15f, Col.MUTED, true).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setOnClickListener { tab = t; query = null; buildTopBar(); render() }
            }
            tabViews[t] = tv
            tabs.addView(tv)
        }
        root.addView(tabs, lp())

        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        content = vbox().apply { setPadding(0, 0, 0, dp(32)) }
        scroll.addView(content)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)

        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Si compartes links desde Telegram hacia la app, abre el importador con ellos. */
    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            i.action = null
            startActivity(Intent(this, AddActivity::class.java).putExtra("text", text))
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun buildTopBar() {
        topBar.removeAllViews()
        if (query == null) {
            topBar.addView(txt("MI CINE", 26f, Col.RED, true).apply { letterSpacing = 0.05f }, lp(0, WRAP, 1f))
            topBar.addView(iconButton(R.drawable.ic_search) { query = ""; buildTopBar(); render() })
        } else {
            val edit = EditText(this).apply {
                hint = "Buscar título o género"
                setHintTextColor(Col.DIM)
                setTextColor(Col.TEXT)
                textSize = 17f
                setSingleLine()
                background = rounded(Col.CARD2, dpf(8f))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setText(query)
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; render() }
                })
            }
            topBar.addView(edit, lp(0, WRAP, 1f))
            topBar.addView(iconButton(R.drawable.ic_close, tint = Col.RED) {
                query = null
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(edit.windowToken, 0)
                buildTopBar(); render()
            })
            edit.requestFocus()
            edit.post {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(edit, 0)
            }
        }
        topBar.addView(iconButton(R.drawable.ic_add) { startActivity(Intent(this, AddActivity::class.java)) })
        topBar.addView(iconButton(R.drawable.ic_settings) { startActivity(Intent(this, SettingsActivity::class.java)) })
    }

    private fun render() {
        Tab.values().forEach { t ->
            tabViews[t]?.apply {
                setTextColor(if (t == tab && query == null) Col.RED else Col.MUTED)
                background = if (t == tab && query == null) underline() else null
            }
        }
        content.removeAllViews()
        val all = Catalog.titles()
        val q = query
        when {
            q != null -> {
                val k = NameParser.key(q)
                val res = if (k.isBlank()) all else all.filter { t ->
                    NameParser.key(t.name).contains(k) || t.genres.any { NameParser.key(it).contains(k) }
                }
                if (res.isEmpty() && k.isNotBlank()) empty("Sin resultados para \"$q\"", false) else grid(res)
            }
            all.isEmpty() -> empty("Tu catálogo está vacío", true)
            tab == Tab.SERIES -> grid(all.filter { it.kind == Kind.SERIES }.sortedBy { it.name.lowercase() })
            tab == Tab.MOVIES -> grid(all.filter { it.kind == Kind.MOVIE }.sortedBy { it.name.lowercase() })
            tab == Tab.MYLIST -> {
                val fav = all.filter { it.favorite }
                if (fav.isEmpty()) empty("Toca el corazón en cualquier título para guardarlo aquí", false) else grid(fav)
            }
            else -> home(all)
        }
    }

    // ---------- Inicio ----------
    private fun home(all: List<Title>) {
        val featured = all.firstOrNull { !it.poster.isNullOrBlank() } ?: all.first()
        content.addView(hero(featured))

        val cont = Catalog.continueWatching()
        if (cont.isNotEmpty()) {
            content.addView(sectionTitle("Seguir viendo"))
            content.addView(hRow(cont.mapNotNull { f -> Catalog.title(f.titleId)?.let { continueCard(f, it) } }))
        }
        val fav = all.filter { it.favorite }
        if (fav.isNotEmpty()) posterRow("Mi lista", fav)
        posterRow("Agregados recientemente", all.take(15))
        val series = all.filter { it.kind == Kind.SERIES }
        if (series.isNotEmpty()) posterRow("Series", series)
        val movies = all.filter { it.kind == Kind.MOVIE }
        if (movies.isNotEmpty()) posterRow("Películas", movies)
        Catalog.genres().take(8).forEach { g -> posterRow(g, all.filter { g in it.genres }) }

        if (!Tmdb.hasKey(this)) {
            content.addView(txt("Consejo: agrega tu clave gratuita de TMDB en Ajustes para tener portadas, sinopsis y nombres de episodios automáticos.", 13f, Col.MUTED).apply {
                setPadding(dp(16), dp(24), dp(16), 0)
                setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            })
        }
    }

    private fun hero(t: Title): View {
        val h = (screenW * 1.3f).toInt()
        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(t.poster ?: t.backdrop, Catalog.filesOf(t.id).firstOrNull { it.coverPath != null }?.coverPath)
        frame.addView(View(this).apply { background = fadeBottom() }, FrameLayout.LayoutParams(MATCH, h / 2, Gravity.BOTTOM))

        val info = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), 0, dp(16), dp(18)) }
        info.addView(txt(t.name, 30f, Col.TEXT, true, 2).apply { gravity = Gravity.CENTER })
        val sub = (listOf(if (t.kind == Kind.SERIES) "Serie" else "Película") + t.genres.take(3)).joinToString("  •  ")
        info.addView(txt(sub, 13f, Col.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(14)) })
        val btns = hbox().apply { gravity = Gravity.CENTER }
        btns.addView(pill("Reproducir", true, R.drawable.ic_play) {
            Catalog.nextToWatch(t.id)?.let { Nav.play(this, it.id) }
        }, lp(0, WRAP, 1f))
        btns.addView(pill("Más info", false, R.drawable.ic_info) { Nav.title(this, t.id) },
            lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        info.addView(btns, lp())
        frame.addView(info, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        frame.layoutParams = LinearLayout.LayoutParams(MATCH, h)
        frame.setOnClickListener { Nav.title(this, t.id) }
        return frame
    }

    private fun posterRow(title: String, list: List<Title>) {
        if (list.isEmpty()) return
        content.addView(sectionTitle(title))
        content.addView(hRow(list.map { t -> posterCard(t, 110) { Nav.title(this, t.id) } }))
    }

    private fun continueCard(f: MediaFile, t: Title): View {
        val w = dp(180)
        val box = vbox().apply { background = rounded(Col.CARD, dpf(8f)); clipToOutline = true }
        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        img.show(f.still ?: t.backdrop ?: t.poster, f.coverPath)
        frame.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            background = rounded(Color.parseColor("#99000000"), dpf(22f), dp(2), Col.TEXT)
            setPadding(dp(9), dp(9), dp(9), dp(9))
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        box.addView(frame, LinearLayout.LayoutParams(w, (w * 9f / 16f).toInt()))
        box.addView(progressBar(f.progress))
        val label = if (f.episode > 0) "${t.name} · ${f.code}" else t.name
        box.addView(txt(label, 12f, Col.TEXT, true, 1).apply { setPadding(dp(8), dp(6), dp(8), dp(1)) }, lp(w, WRAP))
        box.addView(txt("Quedan ${Fmt.duration((f.durationMs - f.positionMs).coerceAtLeast(0))}", 11f, Col.MUTED, false, 1)
            .apply { setPadding(dp(8), 0, dp(8), dp(8)) }, lp(w, WRAP))
        box.layoutParams = LinearLayout.LayoutParams(w, WRAP)
        box.setOnClickListener { Nav.play(this, f.id) }
        box.setOnLongClickListener { Nav.title(this, t.id); true }
        return box
    }

    // ---------- Cuadrícula ----------
    private fun grid(list: List<Title>) {
        val cols = 3
        val gap = 8
        val cardW = ((screenW / resources.displayMetrics.density - 28 - gap * (cols - 1)) / cols).toInt()
        val wrap = vbox().apply { setPadding(dp(14), dp(10), dp(14), 0) }
        list.chunked(cols).forEach { rowItems ->
            val row = hbox().apply { gravity = Gravity.TOP }
            rowItems.forEachIndexed { i, t ->
                row.addView(posterCard(t, cardW) { Nav.title(this, t.id) },
                    lp(WRAP, WRAP).apply { if (i > 0) leftMargin = dp(gap) })
            }
            wrap.addView(row, lp().apply { bottomMargin = dp(14) })
        }
        if (list.isEmpty()) wrap.addView(txt("Nada por aquí todavía.", 14f, Col.MUTED))
        content.addView(wrap)
    }

    private fun empty(msg: String, showAdd: Boolean) {
        val box = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(28), dp(80), dp(28), 0) }
        box.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher) }, LinearLayout.LayoutParams(dp(90), dp(90)))
        box.addView(txt(msg, 18f, Col.TEXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) })
        if (showAdd) {
            box.addView(txt("Pega los links de tus archivos y la app arma las series, temporadas y películas por ti.", 14f, Col.MUTED)
                .apply { gravity = Gravity.CENTER })
            box.addView(pill("Agregar links", true, R.drawable.ic_add) {
                startActivity(Intent(this, AddActivity::class.java))
            }, lp(WRAP, WRAP).apply { topMargin = dp(22) })
        }
        content.addView(box)
    }
}
