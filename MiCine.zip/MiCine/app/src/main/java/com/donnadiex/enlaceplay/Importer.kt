package com.donnadiex.enlaceplay

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.URLDecoder

data class ImportLine(val url: String, val label: String)

data class ImportReport(val added: Int, val duplicated: Int, val newTitles: Int, val matched: Int, val errors: List<String>)

/**
 * Convierte un texto con muchos links en series/películas.
 *
 * Cada línea puede ser:
 *   https://servidor/dl/abc123                       -> usa el nombre real del archivo
 *   Dark S01E03 - https://servidor/dl/abc123         -> usa el texto antes del link
 *   Inception (2010) | https://servidor/dl/xyz       -> igual
 */
object Importer {

    private val URL_RE = Regex("https?://[^\\s<>\"']+")

    /**
     * También entiende el nombre en la línea de ARRIBA del link:
     *   Lucifer S01E02
     *   https://servidor/dl/abc
     */
    fun parseLines(text: String): List<ImportLine> {
        val out = mutableListOf<ImportLine>()
        var pending = ""
        text.lines().forEach { raw ->
            val line = raw.trim()
            val matches = URL_RE.findAll(line).toList()
            if (matches.isEmpty()) {
                if (line.isNotBlank()) pending = line.replace(Regex("[\\s\\-–—:|=>,]+$"), "").trim()
                return@forEach
            }
            val first = matches.first()
            var label = line.substring(0, first.range.first)
                .replace(Regex("[\\s\\-–—:|=>,]+$"), "").trim()
            if (label.isBlank() && matches.size == 1 && pending.isNotBlank()) label = pending
            pending = ""
            matches.forEach { m ->
                val url = m.value.trimEnd(')', ']', '.', ',', ';')
                out.add(ImportLine(url, if (matches.size == 1) label else ""))
            }
        }
        return out.distinctBy { it.url }
    }

    suspend fun run(
        ctx: Context,
        text: String,
        onProgress: suspend (done: Int, total: Int, msg: String) -> Unit
    ): ImportReport = runItems(ctx, parseLines(text), onProgress)

    /** Agrega links o archivos locales (content://). Con nombre conocido no consulta el servidor. */
    suspend fun runItems(
        ctx: Context,
        lines: List<ImportLine>,
        onProgress: suspend (done: Int, total: Int, msg: String) -> Unit
    ): ImportReport {
        Catalog.init(ctx)
        val total = lines.size
        var added = 0
        var dup = 0
        var matched = 0
        val errors = mutableListOf<String>()
        val newTitles = mutableListOf<Title>()
        val touched = mutableSetOf<String>()

        val pending = lines.filter { l ->
            val exists = Catalog.fileByUrl(l.url) != null
            if (exists) dup++
            !exists
        }

        // 1) Nombres reales de los archivos (5 a la vez para ir rápido).
        var done = dup
        onProgress(done, total, "Leyendo nombres de archivos…")
        val named = mutableListOf<Pair<ImportLine, String>>()
        pending.chunked(5).forEach { chunk ->
            val res = coroutineScope {
                chunk.map { l ->
                    async(Dispatchers.IO) {
                        val name = if (l.label.isNotBlank()) l.label
                        else Analyzer.headers(l.url)?.fileName ?: urlName(l.url)
                        l to name
                    }
                }.awaitAll()
            }
            named.addAll(res)
            done += chunk.size
            onProgress(done, total, res.last().second)
        }

        // 2) Agrupar en series y películas.
        // Si un archivo no trae nombre ("01x10.mp4"), toma el de la serie del archivo anterior.
        var lastSeries: Parsed? = null
        named.forEach { (l, fileName) ->
            var p = NameParser.parse(fileName)
            if (p.isSeries && !p.hasName && lastSeries != null) {
                val ls = lastSeries!!
                p = p.copy(name = ls.name, year = if (p.year > 0) p.year else ls.year, hasName = true, anime = p.anime || ls.anime)
            }
            if (p.isSeries && p.hasName) lastSeries = p
            val kind = if (p.isSeries) Kind.SERIES else Kind.MOVIE
            val key = NameParser.key(p.name)
            val t = Catalog.findTitle(kind, key) ?: Title(kind = kind, name = p.name, year = p.year, parsedKey = key).also {
                Catalog.addTitle(it)
                newTitles.add(it)
            }
            if (t.year == 0 && p.year > 0) t.year = p.year
            if (p.anime) t.anime = true
            Catalog.addFile(
                MediaFile(
                    titleId = t.id,
                    season = if (p.isSeries) p.season.coerceAtLeast(1) else 0,
                    episode = p.episode,
                    url = l.url,
                    fileName = fileName,
                    quality = p.quality
                )
            )
            touched.add(t.id)
            added++
        }
        Catalog.save()

        // 3) Portadas, sinopsis y episodios (TMDB con clave, o TVmaze/iTunes gratis).
        //    Va en segundo plano: si sales de la pantalla, sigue buscando (con notificación).
        MetaWork.enqueue(ctx, touched)
        val work = MetaWork.start(ctx)
        while (work.isActive) {
            onProgress(MetaWork.done, MetaWork.total, if (MetaWork.current.isBlank()) "Buscando portadas…" else "Buscando portada de \"${MetaWork.current}\"…")
            kotlinx.coroutines.delay(400)
        }
        matched = touched.count { Catalog.title(it)?.ext?.isNotBlank() == true }

        val stillThere = newTitles.count { Catalog.title(it.id) != null }
        return ImportReport(added, dup, stillThere, matched, errors)
    }

    fun urlName(url: String): String = runCatching {
        URLDecoder.decode(Uri.parse(url).lastPathSegment ?: url, "UTF-8")
    }.getOrDefault(url)
}
