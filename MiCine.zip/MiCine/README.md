# Mi Cine

Tu propio "Netflix" privado: un catálogo de series y películas donde cada episodio o
película se reproduce desde su link directo.

## Obtener el APK (GitHub Actions)

1. En github.com crea un repositorio nuevo, por ejemplo `MiCine` (puede ser privado).
2. Descomprime el ZIP y sube **todo el contenido** de la carpeta `MiCine`
   (incluida la carpeta oculta `.github`). Desde el navegador: *Add file → Upload files*.
   - Si `.github` no se sube, créala a mano: *Add file → Create new file*, nombre
     `.github/workflows/build.yml`, y pega el contenido de ese archivo.
3. Abre la pestaña **Actions**: "Compilar APK" arranca sola (unos 5 minutos).
4. Con palomita verde, entra a la ejecución → **Artifacts → MiCine-apk**.
5. Descomprime y toca `app-debug.apk` para instalar (permite "apps desconocidas").

Si sale una X roja, copia el texto del error del paso "Compilar" y pásaselo a Claude.

## Primeros pasos en la app

1. Portadas y sinopsis salen solas y gratis, sin cuenta: series desde **TVmaze**
   y películas desde **iTunes México**. (Opcional: clave de TMDB en Ajustes para todo en español.)
2. **Botón +** → pega todos tus links, uno por línea → "Agregar al catálogo".
3. La app lee el nombre de cada archivo y arma todo sola:
   - `Serie.S01E03.1080p.mkv`, `Serie 1x03`, `Serie Temporada 1 Capitulo 3` → serie, T1 E3
   - `Pelicula (2010) 720p.mp4` → película del 2010
4. Si un link no trae nombre de archivo, escribe el nombre antes del link:
   `Dark S01E03 - https://tuservidor/dl/abc123`
5. También puedes **compartir** links desde Telegram hacia "Mi Cine".

## Qué tiene

- **Inicio** con portada destacada, "Seguir viendo", Mi lista, recientes, series,
  películas y filas por género.
- Pestañas **Series / Películas / Mi lista** y **buscador** (por nombre o género).
- **Ficha** de cada título: portada grande, calificación, año, temporadas, episodios,
  géneros, estado, sinopsis y botón Reproducir/Continuar.
- **Temporadas** en carpetas desplegables con cada episodio: imagen, nombre, sinopsis,
  duración, calidad y barra de progreso.
- **Reproductor**: pasa solo al siguiente episodio, recuerda dónde te quedaste,
  marca como visto al terminar, cambia audio, subtítulos y velocidad.
- **Información del archivo** (mantén presionado un episodio o toca ⓘ): carátula y
  metadata completa — códec, resolución, FPS, HDR, pistas de audio e idiomas, subtítulos, tamaño.
- **Corregir** (lápiz): si la app adivinó mal, busca el título correcto en TMDB.
- **Respaldo**: exporta/importa todo el catálogo en un archivo.

## Sobre TeraBox

Los links de compartir de TeraBox abren una página, no el archivo; no se pueden
reproducir directo. Usa links directos al archivo (como los `.../dl/...` de tu bot).
