package com.donnadiex.enlaceplay

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.URLDecoder

data class ImportLine(val url: String, val label: String)

data class ImportReport(val added: Int, val duplicated: Int, val newTitles: Int, val matched: Int, val errors: List<String>)

/**
 * Convierte un texto con muchos links en series/películas.
 *
 * Cada línea puede ser:
 *   https://servidor/dl/abc123                       -> usa el nombre real del archivo
 *   Dark S01E03 - https://servidor/dl/abc123         -> usa el texto antes del link
 *   Inception (2010) | https://servidor/dl/xyz       -> igual
 */
object Importer {

    private val URL_RE = Regex("https?://[^\\s<>\"']+")

    fun parseLines(text: String): List<ImportLine> {
        val out = mutableListOf<ImportLine>()
        text.lines().forEach { line ->
            val matches = URL_RE.findAll(line).toList()
            if (matches.isEmpty()) return@forEach
            val first = matches.first()
            val label = line.substring(0, first.range.first)
                .replace(Regex("[\\s\\-–—:|=>,]+$"), "").trim()
            matches.forEach { m ->
                val url = m.value.trimEnd(')', ']', '.', ',', ';')
                out.add(ImportLine(url, if (matches.size == 1) label else ""))
            }
        }
        return out.distinctBy { it.url }
    }

    suspend fun run(
        ctx: Context,
        text: String,
        onProgress: suspend (done: Int, total: Int, msg: String) -> Unit
    ): ImportReport {
        Catalog.init(ctx)
        val lines = parseLines(text)
        val total = lines.size
        var added = 0
        var dup = 0
        var matched = 0
        val errors = mutableListOf<String>()
        val newTitles = mutableListOf<Title>()
        val touched = mutableSetOf<String>()

        val pending = lines.filter { l ->
            val exists = Catalog.fileByUrl(l.url) != null
            if (exists) dup++
            !exists
        }

        // 1) Nombres reales de los archivos (5 a la vez para ir rápido).
        var done = dup
        onProgress(done, total, "Leyendo nombres de archivos…")
        val named = mutableListOf<Pair<ImportLine, String>>()
        pending.chunked(5).forEach { chunk ->
            val res = coroutineScope {
                chunk.map { l ->
                    async(Dispatchers.IO) {
                        val name = if (l.label.isNotBlank()) l.label
                        else Analyzer.headers(l.url)?.fileName ?: urlName(l.url)
                        l to name
                    }
                }.awaitAll()
            }
            named.addAll(res)
            done += chunk.size
            onProgress(done, total, res.last().second)
        }

        // 2) Agrupar en series y películas.
        named.forEach { (l, fileName) ->
            val p = NameParser.parse(fileName)
            val kind = if (p.isSeries) Kind.SERIES else Kind.MOVIE
            val key = NameParser.key(p.name)
            val t = Catalog.findTitle(kind, key) ?: Title(kind = kind, name = p.name, year = p.year, parsedKey = key).also {
                Catalog.addTitle(it)
                newTitles.add(it)
            }
            if (t.year == 0 && p.year > 0) t.year = p.year
            Catalog.addFile(
                MediaFile(
                    titleId = t.id,
                    season = if (p.isSeries) p.season.coerceAtLeast(1) else 0,
                    episode = p.episode,
                    url = l.url,
                    fileName = fileName,
                    quality = p.quality
                )
            )
            touched.add(t.id)
            added++
        }
        Catalog.save()

        // 3) Portadas, sinopsis y nombres de episodios desde TMDB.
        if (Tmdb.hasKey(ctx)) {
            val list = touched.mapNotNull { Catalog.title(it) }
            list.forEachIndexed { i, t ->
                onProgress(i, list.size, "Buscando datos de \"${t.name}\"…")
                withContext(Dispatchers.IO) {
                    runCatching {
                        if (t.tmdbId == 0) {
                            if (Tmdb.autoMatch(ctx, t)) matched++
                        } else {
                            Tmdb.fillEpisodes(ctx, t)
                        }
                    }.onFailure { errors.add("${t.name}: ${it.message}") }
                }
                // Si TMDB dijo que es una serie que ya existía con otro nombre, unirlas.
                Catalog.titles().firstOrNull { it.id != t.id && it.tmdbId != 0 && it.tmdbId == t.tmdbId && it.kind == t.kind }
                    ?.let { other -> Catalog.merge(t.id, other.id) }
            }
            Catalog.save()
        }

        val stillThere = newTitles.count { Catalog.title(it.id) != null }
        return ImportReport(added, dup, stillThere, matched, errors)
    }

    fun urlName(url: String): String = runCatching {
        URLDecoder.decode(Uri.parse(url).lastPathSegment ?: url, "UTF-8")
    }.getOrDefault(url)
}
