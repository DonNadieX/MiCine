package com.donnadiex.enlaceplay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File

/**
 * Subtítulos externos (.srt, .ass, .ssa, .vtt):
 *  - Busca solo el archivo que está junto al video con el mismo nombre
 *    ("Lucifer 1x03.mkv" -> "Lucifer 1x03.srt", "Lucifer 1x03.es.srt"…).
 *  - También puedes elegir uno a mano; se recuerda para ese capítulo.
 *  - Se copia a la memoria de la app para que VLC lo lea sin problemas de permisos.
 */
object Subs {
    val EXT = setOf("srt", "ass", "ssa", "vtt", "sub")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("subtitulos", Context.MODE_PRIVATE)

    fun picked(ctx: Context, fileId: String): String? = prefs(ctx).getString(fileId, null)

    fun setPicked(ctx: Context, fileId: String, uri: Uri) {
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        prefs(ctx).edit().putString(fileId, uri.toString()).apply()
    }

    /** Devuelve un archivo listo para VLC, o null si no hay subtítulo. */
    fun find(ctx: Context, f: MediaFile): Uri? {
        picked(ctx, f.id)?.let { p -> copy(ctx, Uri.parse(p), f.id, nameOf(ctx, Uri.parse(p)))?.let { return it } }
        if (!Local.isLocal(f.url)) return null
        val u = Uri.parse(f.url)
        return runCatching {
            when {
                MediaScan.isMediaUri(f.url) -> fromMediaStore(ctx, u, f.id)
                u.scheme == "file" -> fromPath(ctx, u.path ?: return null, f.id)
                else -> fromTree(ctx, u, f.id)
            }
        }.getOrNull()
    }

    private fun base(name: String) = name.substringBeforeLast('.').lowercase()

    /** Entre varios candidatos, prefiere los de español. */
    private fun best(names: List<String>): String? = names.maxByOrNull { n ->
        val l = n.lowercase()
        when {
            listOf(".es.", ".spa.", ".lat.", "español", "espanol", "latino", "spanish").any { l.contains(it) } -> 2
            else -> 1
        }
    }

    private fun matches(subName: String, videoBase: String): Boolean {
        val ext = subName.substringAfterLast('.', "").lowercase()
        return ext in EXT && subName.lowercase().startsWith(videoBase)
    }

    /** Carpetas elegidas en "Carpetas locales y USB". */
    private fun fromTree(ctx: Context, u: Uri, fileId: String): Uri? {
        val docId = DocumentsContract.getDocumentId(u)
        val treeId = DocumentsContract.getTreeDocumentId(u)
        val tree = DocumentsContract.buildTreeDocumentUri(u.authority, treeId)
        val parent = if (docId.contains('/')) docId.substringBeforeLast('/') else docId.substringBefore(':') + ":"
        val videoBase = base(nameOf(ctx, u) ?: docId.substringAfterLast('/'))
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parent)
        val found = mutableMapOf<String, String>()
        ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                if (matches(name, videoBase)) found[name] = id
            }
        }
        val pick = best(found.keys.toList()) ?: return null
        return copy(ctx, DocumentsContract.buildDocumentUriUsingTree(tree, found[pick]), fileId, pick)
    }

    /** Videos encontrados en todo el aparato (funciona en Android 10 o menos, o si el archivo es legible). */
    @Suppress("DEPRECATION")
    private fun fromMediaStore(ctx: Context, u: Uri, fileId: String): Uri? {
        val path = ctx.contentResolver.query(u, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        return fromPath(ctx, path, fileId)
    }

    private fun fromPath(ctx: Context, path: String, fileId: String): Uri? {
        val video = File(path)
        val dir = video.parentFile ?: return null
        val vb = base(video.name)
        val names = dir.list()?.filter { matches(it, vb) } ?: return null
        val pick = best(names) ?: return null
        val src = File(dir, pick)
        if (!src.canRead()) return null
        return copy(ctx, Uri.fromFile(src), fileId, pick)
    }

    fun nameOf(ctx: Context, u: Uri): String? = runCatching {
        if (u.scheme == "file") return u.lastPathSegment
        ctx.contentResolver.query(u, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

    fun copy(ctx: Context, src: Uri, fileId: String, name: String?): Uri? = runCatching {
        val ext = name?.substringAfterLast('.', "")?.lowercase()?.takeIf { it in EXT } ?: "srt"
        val dir = File(ctx.cacheDir, "subs").apply { mkdirs() }
        val out = File(dir, "$fileId.$ext")
        ctx.contentResolver.openInputStream(src)?.use { inp -> out.outputStream().use { inp.copyTo(it) } } ?: return null
        if (out.length() == 0L) return null
        Uri.fromFile(out)
    }.getOrNull()
}

/** Recuerda el audio y los subtítulos que elegiste para cada serie o película. */
object Tracks {
    const val OFF = "__off__"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("pistas", Context.MODE_PRIVATE)

    fun audio(ctx: Context, titleId: String): String? = prefs(ctx).getString("${titleId}_a", null)
    fun subs(ctx: Context, titleId: String): String? = prefs(ctx).getString("${titleId}_s", null)
    fun setAudio(ctx: Context, titleId: String, name: String) = prefs(ctx).edit().putString("${titleId}_a", name).apply()
    fun setSubs(ctx: Context, titleId: String, name: String) = prefs(ctx).edit().putString("${titleId}_s", name).apply()

    /** "Pista 2 - [Español]" -> "español" (para reconocer la misma pista en otro capítulo). */
    fun lang(name: String): String =
        Regex("\\[([^\\]]+)]").find(name)?.groupValues?.get(1)?.lowercase()?.trim()
            ?: name.lowercase().replace(Regex("(pista|track)\\s*\\d+\\s*-?"), "").trim()
}
