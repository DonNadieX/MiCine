package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.util.Rational
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Reproductor de Mi Cine con el motor de VLC:
 *  - Lee cualquier formato y audio (AC3, E-AC3, DTS…) aunque el aparato no los soporte.
 *  - Usa el decodificador de video del aparato cuando puede (rápido en proyectores).
 *  - Pensado para control remoto: ◀ ▶ adelantar, OK pausa, ▲ ▼ menú, Atrás sale.
 *  - Si eliges "App VLC" en Ajustes, abre la app VLC y guarda dónde te quedaste.
 */
class PlayerActivity : BaseActivity() {

    companion object {
        private const val REQ_VLC = 77
        private const val REQ_SUB = 78
        private const val HIDE_MS = 4500L
    }

    private var libVLC: LibVLC? = null
    private var mp: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null
    private lateinit var video: VLCVideoLayout

    private var queue: List<MediaFile> = emptyList()
    private var index = 0
    private var lengthMs = 0L
    private var timeMs = 0L
    private var started = false
    private var external = false

    // Interfaz
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var timeView: TextView
    private lateinit var lengthView: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: ImageView
    private lateinit var prevBtn: View
    private lateinit var nextBtn: View
    private lateinit var spinner: ProgressBar
    private lateinit var flashView: TextView
    private lateinit var nextCard: LinearLayout
    private lateinit var nextText: TextView
    private lateinit var errorCard: LinearLayout
    private lateinit var errorText: TextView
    private var controlsShown = false
    private var seekTarget = -1L
    private var seekRepeat = 0
    private var countdown = 0
    private var scale = 0

    // Saltar intro
    private lateinit var skipBtn: TextView
    private var skipShownFor = -1
    private var skipUntil = 0L
    private var tracksApplied = false
    private var inPip = false
    private var statusTick = 0
    /** Plan B activo para este video (la app trae el video y se lo pasa al reproductor). */
    private var useBridge = false
    private var bridgeTriedFor = ""

    private fun diagnoseLink(f: MediaFile) {
        spinner.visibility = View.VISIBLE
        flash("Revisando el link…")
        scope.launch {
            val r = withContext(Dispatchers.IO) { LinkDoctor.check(f.url) }
            if (queue.getOrNull(index)?.id != f.id) return@launch
            when {
                r is LinkDoctor.Result.Works && bridgeTriedFor != f.id -> {
                    // el link sí responde: probar el plan B automáticamente
                    bridgeTriedFor = f.id
                    useBridge = true
                    flash("Probando otra forma de conexión…")
                    val saved = Catalog.file(f.id)?.let { if (!it.finished && it.positionMs > 5_000) it.positionMs else 0L } ?: 0L
                    playIndex(index, if (timeMs > 0) timeMs else saved)
                }
                r is LinkDoctor.Result.Works -> showError("El link funciona, pero el reproductor no pudo abrir este video " +
                    "(puede ser un formato raro). Prueba \"Abrir en app VLC\", o en Ajustes → Reproducción elige \"App VLC\".")
                r is LinkDoctor.Result.Problem -> showError(r.message)
            }
        }
    }
    private var voutCount = 0
    private var videoFixes = 0

    /** Si se escucha pero la pantalla sigue negra, se vuelve a conectar la imagen. */
    private val videoCheck = object : Runnable {
        override fun run() {
            val p = mp ?: return
            val hasVideo = (p.videoTracks?.count { it.id >= 0 } ?: 0) > 0
            if (!hasVideo || voutCount > 0 || videoFixes >= 3) return
            videoFixes++
            runCatching {
                if (videoFixes >= 2) { p.detachViews(); p.attachViews(video, null, true, false) }
                p.setVideoTrackEnabled(true)
                p.updateVideoSurfaces()
            }
            ui.postDelayed(this, 1200)
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val hideControls = Runnable { setControls(false) }
    private val hideFlash = Runnable { flashView.visibility = View.GONE; seekTarget = -1L; seekRepeat = 0 }
    private val saver = object : Runnable {
        override fun run() { saveCurrent(false); ui.postDelayed(this, 10_000) }
    }
    private val ticker = object : Runnable {
        override fun run() {
            if (controlsShown) updateTime()
            checkSkip()
            if (RemoteLib.currentHost != null && ++statusTick % 2 == 0) sendStatus()
            ui.postDelayed(this, 1000)
        }
    }
    private val countdownTick = object : Runnable {
        override fun run() {
            countdown--
            if (countdown <= 0) { nextCard.visibility = View.GONE; playIndex(index + 1, 0) }
            else { updateNextText(); ui.postDelayed(this, 1000) }
        }
    }

    // ======================= Inicio =======================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val start = intent.getStringExtra("file")?.let { Catalog.file(it) }
        if (start == null) { finish(); return }
        val title = Catalog.title(start.titleId)
        queue = if (title?.kind == Kind.SERIES) Catalog.filesOf(start.titleId) else listOf(start)
        index = queue.indexOfFirst { it.id == start.id }.coerceAtLeast(0)

        // App VLC externa (si así lo elegiste y está instalada)
        if (Players.engine(this) == Engine.VLC_APP && Players.vlcAppInstalled(this)) {
            external = true
            setContentView(FrameLayout(this).apply { setBackgroundColor(Color.BLACK) })
            openInVlcApp()
            return
        }
        buildUi()
        hideBars()
    }

    override fun onStart() {
        super.onStart()
        if (external || queue.isEmpty()) return
        startEngine()
        val f = Catalog.file(queue[index].id) ?: queue[index]
        // Se espera a que la pantalla del video esté lista (si no, VLC apaga la imagen y solo suena el audio)
        video.postDelayed({
            if (mp != null && !external) playIndex(index, if (!f.finished && f.positionMs > 5_000) f.positionMs else 0L)
        }, 150)
        ui.postDelayed(saver, 10_000)
        ui.post(ticker)
        RemoteLib.playerListener = { c -> ui.post { onRemoteCommand(c) } }
    }

    override fun onStop() {
        super.onStop()
        if (external) return
        ui.removeCallbacksAndMessages(null)
        RemoteLib.playerListener = null
        if (RemoteLib.currentHost != null) RemoteLib.reportStatus(this, org.json.JSONObject().put("f", "").put("playing", false).put("title", ""))
        saveCurrent(true)
        releaseEngine()
    }

    override fun onResume() {
        super.onResume()
        hideBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    // ======================= Motor VLC =======================
    private fun startEngine() {
        if (mp != null) return
        val opts = arrayListOf(
            "--audio-time-stretch",                 // velocidad 1.5x sin voz de ardilla
            "--audio-language=es,spa,lat,esp",      // prefiere audio en español si hay varios
            "--no-sub-autodetect-file",
            "--avcodec-skiploopfilter=1",           // decodificación más ligera en aparatos modestos
            "--http-reconnect"
        )
        val lib = LibVLC(this, opts)
        libVLC = lib
        val player = MediaPlayer(lib)
        mp = player
        player.attachViews(video, null, true, false)
        player.setEventListener { e -> ui.post { onVlcEvent(e) } }
    }

    private fun releaseEngine() {
        mp?.let {
            runCatching { it.setEventListener(null) }
            runCatching { it.stop() }
            runCatching { it.detachViews() }
            runCatching { it.release() }
        }
        mp = null
        runCatching { libVLC?.release() }
        libVLC = null
        runCatching { pfd?.close() }
        pfd = null
    }

    private fun playIndex(i: Int, startMs: Long) {
        val player = mp ?: return
        val lib = libVLC ?: return
        if (i !in queue.indices) { finish(); return }
        index = i
        started = false
        tracksApplied = false
        voutCount = 0
        videoFixes = 0
        ui.removeCallbacks(videoCheck)
        if (::skipBtn.isInitialized) skipBtn.visibility = View.GONE
        lengthMs = 0; timeMs = 0
        errorCard.visibility = View.GONE
        nextCard.visibility = View.GONE
        spinner.visibility = View.VISIBLE
        val f = queue[i]
        runCatching { pfd?.close() }
        pfd = null
        val media = runCatching {
            if (Local.isLocal(f.url)) {
                val fd = contentResolver.openFileDescriptor(Uri.parse(f.url), "r") ?: error("sin acceso")
                pfd = fd
                Media(lib, fd.fileDescriptor)
            } else if (RemoteLib.isRemote(f.url)) {
                val u = RemoteLib.resolve(this, f.url) ?: error("sin celular")
                Media(lib, Uri.parse(u))
            } else Media(lib, Uri.parse(if (useBridge) LinkDoctor.bridged(f.url) else f.url))
        }.getOrElse {
            showError(if (RemoteLib.isRemote(f.url)) "No encuentro tu celular. Conecta el proyector a su red y activa \"Compartir mi biblioteca\" en el celular."
                else if (Local.isLocal(f.url)) "No encuentro este archivo. Si está en una memoria USB, conéctala y vuelve a intentar." else "No se pudo abrir el link.")
            return
        }
        media.setHWDecoderEnabled(true, false)
        // Videos del celular por la red de la casa: búfer corto = arranca y adelanta casi al instante
        media.addOption(":network-caching=${if (RemoteLib.isRemote(f.url)) 400 else Players.networkCachingMs(this)}")
        media.addOption(":file-caching=1500")
        media.addOption(":http-user-agent=$USER_AGENT")
        if (startMs > 0) media.addOption(":start-time=${startMs / 1000.0}")
        player.media = media
        media.release()
        player.play()
        loadExternalSubs(player, f)
        updateTitle()
        prevBtn.alpha = if (index > 0) 1f else 0.35f
        nextBtn.alpha = if (index < queue.size - 1) 1f else 0.35f
    }

    private fun onVlcEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Playing -> {
                updatePip()
                spinner.visibility = View.GONE
                playBtn.setImageResource(R.drawable.ic_pause)
                if (!started) {
                    started = true
                    flash(if (lengthMs > 0) Fmt.duration(lengthMs) else "▶")
                    ui.postDelayed({ applyRememberedTracks(); applyRememberedSettings() }, 700)
                    ui.postDelayed({ tracksApplied = false; applyRememberedTracks() }, 2500)   // por si las pistas tardan
                    ui.postDelayed(videoCheck, 1500)
                }
            }
            MediaPlayer.Event.Paused -> {
                updatePip()
                playBtn.setImageResource(R.drawable.ic_play)
                setControls(true, autoHide = false)
            }
            MediaPlayer.Event.Vout -> voutCount = e.voutCount
            MediaPlayer.Event.Buffering -> spinner.visibility = if (e.buffering < 100f) View.VISIBLE else View.GONE
            MediaPlayer.Event.LengthChanged -> { lengthMs = e.lengthChanged; updateTime() }
            MediaPlayer.Event.TimeChanged -> timeMs = e.timeChanged
            MediaPlayer.Event.EndReached -> onEnded()
            MediaPlayer.Event.EncounteredError -> {
                val f = queue.getOrNull(index)
                // Links de internet: averiguar qué pasa y, si el link sí funciona, intentar el plan B
                if (f != null && !Local.isLocal(f.url) && !RemoteLib.isRemote(f.url)) {
                    diagnoseLink(f); return
                }
                showError(when {
                    f != null && Local.isLocal(f.url) && !Local.isFileAvailable(this, f.url) ->
                        "Este archivo está en una memoria que no está conectada (o se movió de carpeta)."
                    f != null && RemoteLib.isRemote(f.url) -> "Se perdió la conexión con tu celular. Revisa que siga compartiendo y que el proyector esté en su red."
                    f != null && !Local.isLocal(f.url) -> "No se pudo reproducir el link. Revisa tu internet o que el link siga activo."
                    else -> "No se pudo reproducir este archivo."
                })
            }
        }
    }

    private fun onEnded() {
        queue.getOrNull(index)?.let { markFinished(it) }
        if (index < queue.size - 1) {
            countdown = 8
            updateNextText()
            nextCard.visibility = View.VISIBLE
            setControls(false)
            (nextCard.getChildAt(nextCard.childCount - 1) as LinearLayout).getChildAt(1).requestFocus()
            ui.postDelayed(countdownTick, 1000)
        } else finish()
    }

    private fun updateNextText() {
        val n = queue.getOrNull(index + 1) ?: return
        val label = listOfNotNull(n.code.ifBlank { null }, n.epName.ifBlank { null }).joinToString(" · ")
        nextText.text = "Siguiente: $label\nEmpieza en $countdown s"
    }

    // ======================= Interfaz =======================
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = VLCVideoLayout(this)
        root.addView(video, FrameLayout.LayoutParams(MATCH, MATCH))

        // Toque en la pantalla: muestra/oculta controles
        root.addView(View(this).apply {
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP) setControls(!controlsShown)
                true
            }
        }, FrameLayout.LayoutParams(MATCH, MATCH))

        spinner = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(spinner, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        flashView = txt("", 30f, Color.WHITE, true).apply {
            background = rounded(Color.parseColor("#B3000000"), dpf(14f))
            setPadding(dp(24), dp(10), dp(24), dp(10))
            visibility = View.GONE
        }
        root.addView(flashView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        // ---- Barra superior ----
        topBar = hbox().apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#CC000000"), Color.TRANSPARENT))
            setPadding(dp(16), dp(14), dp(24), dp(30))
            gravity = Gravity.TOP
        }
        topBar.addView(ctrl(R.drawable.ic_back, "Salir") { finish() })
        val tcol = vbox().apply { setPadding(dp(12), dp(2), 0, 0) }
        titleView = txt("", 20f, Color.WHITE, true, 1)
        subView = txt("", 14f, Color.parseColor("#CCFFFFFF"), false, 1)
        tcol.addView(titleView); tcol.addView(subView)
        topBar.addView(tcol, lp(0, WRAP, 1f))
        root.addView(topBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        // ---- Barra inferior ----
        bottomBar = vbox().apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#E6000000"), Color.TRANSPARENT))
            setPadding(dp(24), dp(40), dp(24), dp(16))
        }
        val timeRow = hbox()
        timeView = txt("0:00", 14f, Color.WHITE, true)
        lengthView = txt("0:00", 14f, Color.parseColor("#CCFFFFFF"))
        seek = SeekBar(this).apply {
            max = 1000
            isFocusable = true
            progressTintList = android.content.res.ColorStateList.valueOf(Col.RED)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && lengthMs > 0) { val t = lengthMs * p / 1000; mp?.setTime(t); timeMs = t; updateTime() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { ui.removeCallbacks(hideControls) }
                override fun onStopTrackingTouch(s: SeekBar?) { scheduleHide() }
            })
            // Con el control, ◀ ▶ sobre la barra adelantan 10 s
            setOnKeyListener { _, code, ev ->
                if (ev.action == KeyEvent.ACTION_DOWN && (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                    seekBy(if (code == KeyEvent.KEYCODE_DPAD_LEFT) -10_000 else 10_000, ev.repeatCount); scheduleHide(); true
                } else false
            }
        }
        timeRow.addView(timeView)
        timeRow.addView(seek, lp(0, WRAP, 1f))
        timeRow.addView(lengthView)
        bottomBar.addView(timeRow, lp())

        val buttons = hbox().apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        prevBtn = ctrl(R.drawable.ic_skip_prev, "Anterior") { if (index > 0) { saveCurrent(true); playIndex(index - 1, 0) } }
        nextBtn = ctrl(R.drawable.ic_skip_next, "Siguiente") { if (index < queue.size - 1) { saveCurrent(true); markFinished(queue[index]); playIndex(index + 1, 0) } }
        playBtn = ctrl(R.drawable.ic_pause, "Pausa", big = true) { togglePlay() }
        buttons.addView(prevBtn)
        buttons.addView(ctrl(R.drawable.ic_replay, "-10 s") { seekBy(-10_000, 0) })
        buttons.addView(playBtn)
        buttons.addView(ctrl(R.drawable.ic_forward, "+10 s") { seekBy(10_000, 0) })
        buttons.addView(nextBtn)
        buttons.addView(View(this), LinearLayout.LayoutParams(dp(28), 1))
        buttons.addView(ctrl(R.drawable.ic_audio, "Audio") { chooseAudio() })
        buttons.addView(ctrl(R.drawable.ic_subtitles, "Subtítulos") { chooseSubs() })
        buttons.addView(ctrl(R.drawable.ic_speed, "Velocidad") { chooseSpeed() })
        buttons.addView(ctrl(R.drawable.ic_aspect, "Pantalla") { cycleScale() })
        buttons.addView(ctrl(R.drawable.ic_settings, "Sincronizar") { chooseSync() })
        if (pipSupported()) buttons.addView(ctrl(R.drawable.ic_pip, "Ventanita") { enterPip(force = true) })
        bottomBar.addView(buttons, lp())
        root.addView(bottomBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // ---- Botón "Saltar intro" ----
        skipBtn = txt("Saltar intro  ⏭", 16f, Color.WHITE, true).apply {
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = rounded(Color.parseColor("#CC141414"), dpf(10f), dp(2), Color.WHITE)
            isFocusable = true
            isClickable = true
            visibility = View.GONE
            setOnFocusChangeListener { v, has ->
                v.background = rounded(if (has) Color.WHITE else Color.parseColor("#CC141414"), dpf(10f), dp(2), Color.WHITE)
                (v as TextView).setTextColor(if (has) Color.BLACK else Color.WHITE)
            }
            setOnClickListener { skipIntro() }
        }
        root.addView(skipBtn, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(32), dp(110)) })

        // ---- Tarjeta "Siguiente capítulo" ----
        nextCard = vbox().apply {
            background = rounded(Color.parseColor("#E6141414"), dpf(14f), dp(1), Color.parseColor("#55FFFFFF"))
            setPadding(dp(18), dp(14), dp(18), dp(14))
            visibility = View.GONE
        }
        nextText = txt("", 16f, Color.WHITE, true)
        nextCard.addView(nextText)
        val nb = hbox().apply { setPadding(0, dp(10), 0, 0) }
        nb.addView(pill("Cancelar", false) { ui.removeCallbacks(countdownTick); finish() })
        nb.addView(pill("Ver ahora", true, R.drawable.ic_play) { ui.removeCallbacks(countdownTick); playIndex(index + 1, 0) },
            lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        nextCard.addView(nb)
        root.addView(nextCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(32), dp(32)) })

        // ---- Tarjeta de error ----
        errorCard = vbox().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.parseColor("#F0141414"), dpf(14f))
            setPadding(dp(24), dp(20), dp(24), dp(20))
            visibility = View.GONE
        }
        errorText = txt("", 16f, Color.WHITE).apply { gravity = Gravity.CENTER }
        errorCard.addView(errorText, lp(dp(420), WRAP))
        val eb = hbox().apply { setPadding(0, dp(14), 0, 0) }
        eb.addView(pill("Salir", false) { finish() })
        eb.addView(pill("Reintentar", false) { playIndex(index, timeMs) }, lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        if (Players.vlcAppInstalled(this)) eb.addView(pill("Abrir en app VLC", true) { saveCurrent(true); external = true; releaseEngine(); openInVlcApp() },
            lp(WRAP, WRAP).apply { leftMargin = dp(10) })
        errorCard.addView(eb)
        root.addView(errorCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        setContentView(root)
        setControls(false)
    }

    /** Botón redondo del reproductor (con marco al elegirlo con el control). */
    private fun ctrl(icon: Int, desc: String, big: Boolean = false, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(icon)
        setColorFilter(Color.WHITE)
        contentDescription = desc
        val size = dp(if (big) 64 else 48)
        val pad = dp(if (big) 14 else 11)
        setPadding(pad, pad, pad, pad)
        layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(dp(6), 0, dp(6), 0) }
        background = rounded(if (big) Color.parseColor("#33FFFFFF") else Color.TRANSPARENT, size / 2f)
        isFocusable = true
        isClickable = true
        setOnFocusChangeListener { v, has ->
            v.background = rounded(if (has) Color.WHITE else if (big) Color.parseColor("#33FFFFFF") else Color.TRANSPARENT, size / 2f)
            (v as ImageView).setColorFilter(if (has) Color.BLACK else Color.WHITE)
        }
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun setControls(show0: Boolean, autoHide: Boolean = true) {
        val show = show0 && !inPip
        controlsShown = show
        val v = if (show) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        ui.removeCallbacks(hideControls)
        if (show) {
            updateTime()
            if (currentFocus == null || currentFocus?.isShown != true) playBtn.requestFocus()
            if (autoHide && mp?.isPlaying == true) scheduleHide()
        } else hideBars()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideControls)
        if (mp?.isPlaying == true) ui.postDelayed(hideControls, HIDE_MS)
    }

    private fun updateTitle() {
        val f = queue.getOrNull(index) ?: return
        val t = Catalog.title(f.titleId)
        titleView.text = t?.name ?: f.fileName
        subView.text = if (f.episode > 0) "${f.code}  ${f.epName.ifBlank { "Capítulo ${f.episode}" }}" else f.quality.uppercase()
    }

    private fun updateTime() {
        val p = mp ?: return
        val t = runCatching { p.time }.getOrDefault(timeMs).coerceAtLeast(0)
        val l = lengthMs.takeIf { it > 0 } ?: runCatching { p.length }.getOrDefault(0)
        timeView.text = Fmt.duration(t).let { if (it == "—") "0:00" else it }
        lengthView.text = if (l > 0) Fmt.duration(l) else "--:--"
        if (l > 0 && !seek.isPressed) seek.progress = (t * 1000 / l).toInt()
    }

    private fun togglePlay() {
        val p = mp ?: return
        if (p.isPlaying) { p.pause(); flash("❚❚") } else { p.play(); flash("▶"); scheduleHide() }
    }

    private fun seekBy(ms: Long, repeat: Int) {
        val p = mp ?: return
        seekRepeat = if (repeat > 0) seekRepeat + 1 else 0
        val step = when { seekRepeat > 20 -> 6; seekRepeat > 8 -> 3; else -> 1 } * ms
        val base = if (seekTarget >= 0) seekTarget else runCatching { p.time }.getOrDefault(timeMs)
        val max = if (lengthMs > 0) lengthMs - 1000 else Long.MAX_VALUE
        seekTarget = (base + step).coerceIn(0, max)
        p.setTime(seekTarget)
        timeMs = seekTarget
        val total = if (lengthMs > 0) " / ${Fmt.duration(lengthMs)}" else ""
        flash((if (ms < 0) "⏪  " else "⏩  ") + Fmt.duration(seekTarget).let { if (it == "—") "0:00" else it } + total)
        updateTime()
    }

    private fun flash(text: String) {
        flashView.text = text
        flashView.visibility = View.VISIBLE
        ui.removeCallbacks(hideFlash)
        ui.postDelayed(hideFlash, 1200)
    }

    private fun showError(msg: String) {
        spinner.visibility = View.GONE
        errorText.text = msg
        errorCard.visibility = View.VISIBLE
        setControls(false)
        (errorCard.getChildAt(1) as LinearLayout).getChildAt(1).requestFocus()
    }

    // ---- Menús ----
    private fun dialogTracks(title: String, tracks: Array<MediaPlayer.TrackDescription>?, current: Int, rename: (String) -> String, pick: (Int) -> Unit) {
        val list = tracks?.toList().orEmpty()
        if (list.isEmpty()) { flash("Sin opciones"); return }
        val names = list.map { rename(it.name ?: "Pista ${it.id}") }.toTypedArray()
        val sel = list.indexOfFirst { it.id == current }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title)
            .setSingleChoiceItems(names, sel) { d, w -> pick(list[w].id); d.dismiss(); hideBars() }
            .setOnDismissListener { hideBars() }
            .show()
    }

    private fun titleId() = queue.getOrNull(index)?.titleId ?: ""

    private fun chooseAudio() {
        val p = mp ?: return
        val list = p.audioTracks?.toList().orEmpty()
        dialogTracks("Audio", p.audioTracks, p.audioTrack, { if (it.equals("Disable", true)) "Sin audio" else it }) { id ->
            p.setAudioTrack(id)
            list.firstOrNull { it.id == id }?.name?.let { if (id >= 0) Tracks.setAudio(this, titleId(), it) }
            flash("Se recordará para los demás capítulos")
        }
    }

    private fun chooseSubs() {
        val p = mp ?: return
        val list = p.spuTracks?.toList().orEmpty()
        val names = list.map { if (it.id < 0 || (it.name ?: "").equals("Disable", true)) "Desactivados" else (it.name ?: "Pista ${it.id}") } +
            "📂  Cargar archivo de subtítulos…"
        val sel = list.indexOfFirst { it.id == p.spuTrack }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Subtítulos")
            .setSingleChoiceItems(names.toTypedArray(), sel) { d, w ->
                d.dismiss(); hideBars()
                if (w == list.size) { pickSubtitleFile(); return@setSingleChoiceItems }
                val t = list[w]
                p.setSpuTrack(t.id)
                Tracks.setSubs(this, titleId(), if (t.id < 0) Tracks.OFF else (t.name ?: ""))
            }
            .setOnDismissListener { hideBars() }
            .show()
    }

    // ---- Sincronizar audio / subtítulos ----
    private fun chooseSync() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Sincronizar")
            .setItems(arrayOf("Audio adelantado o atrasado", "Subtítulos adelantados o atrasados")) { d, w ->
                d.dismiss(); if (w == 0) delayDialog(true) else delayDialog(false)
            }
            .setOnDismissListener { hideBars() }
            .show()
    }

    private fun delayDialog(audio: Boolean) {
        val p = mp ?: return
        var ms = (if (audio) p.audioDelay else p.spuDelay) / 1000
        val box = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(12), dp(16), dp(4)) }
        val value = txt("", 26f, Color.WHITE, true)
        val hint = txt(if (audio) "Si la voz llega DESPUÉS que los labios, usa −. Si llega ANTES, usa +." else "Si el subtítulo sale tarde usa −; si sale antes usa +.", 13f, Color.parseColor("#CCFFFFFF")).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(10)) }
        fun apply() {
            if (audio) p.setAudioDelay(ms * 1000) else p.setSpuDelay(ms * 1000)
            value.text = (if (ms > 0) "+" else "") + "%.2f s".format(ms / 1000.0)
            if (audio) { TitlePrefs.setLong(this, titleId(), "audio_ms", ms); Players.setAudioDelayMs(this, ms) }
            else TitlePrefs.setLong(this, titleId(), "subs_ms", ms)
        }
        val row = hbox().apply { gravity = Gravity.CENTER }
        listOf(-250L, -50L, 50L, 250L).forEach { step ->
            row.addView(pill((if (step > 0) "+" else "−") + "${kotlin.math.abs(step)} ms", false) { ms += step; apply() },
                lp(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        box.addView(value); box.addView(hint); box.addView(row)
        box.addView(pill("Volver a 0", false) { ms = 0; apply() }, lp(WRAP, WRAP).apply { topMargin = dp(10) })
        value.text = (if (ms > 0) "+" else "") + "%.2f s".format(ms / 1000.0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (audio) "Sincronizar audio" else "Sincronizar subtítulos")
            .setView(box)
            .setPositiveButton("Listo", null)
            .setOnDismissListener { hideBars() }
            .show()
    }

    // ---- Subtítulos externos ----
    private fun loadExternalSubs(player: MediaPlayer, f: MediaFile) {
        scope.launch {
            val u = withContext(Dispatchers.IO) { Subs.find(applicationContext, f) } ?: return@launch
            if (mp !== player || queue.getOrNull(index)?.id != f.id) return@launch
            val wantOff = Tracks.subs(this@PlayerActivity, f.titleId) == Tracks.OFF
            runCatching { player.addSlave(0, u, !wantOff) }   // 0 = subtítulo
            if (!wantOff) flash("Subtítulos cargados")
        }
    }

    private fun pickSubtitleFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/x-subrip", "text/*", "application/octet-stream", "*/*"))
        runCatching { startActivityForResult(i, REQ_SUB) }.onFailure { flash("No hay explorador de archivos") }
    }

    private fun onSubtitlePicked(uri: Uri) {
        val f = queue.getOrNull(index) ?: return
        val name = Subs.nameOf(this, uri) ?: ""
        if (name.isNotBlank() && name.substringAfterLast('.', "").lowercase() !in Subs.EXT) {
            Toast.makeText(this, "Ese archivo no es de subtítulos (.srt, .ass, .vtt)", Toast.LENGTH_LONG).show(); return
        }
        Subs.setPicked(this, f.id, uri)
        Tracks.setSubs(this, f.titleId, "")
        scope.launch {
            val u = withContext(Dispatchers.IO) { Subs.copy(applicationContext, uri, f.id, name) } ?: return@launch
            // El reproductor se reinicia al volver del explorador; esperamos a que esté listo.
            ui.postDelayed({ mp?.let { runCatching { it.addSlave(0, u, true) }; flash("Subtítulos cargados") } }, 1200)
        }
    }

    /** Pone el audio/subtítulo que elegiste antes en esta serie. */
    private fun applyRememberedTracks() {
        if (tracksApplied) return
        tracksApplied = true
        val p = mp ?: return
        val tid = titleId()
        Tracks.audio(this, tid)?.let { want ->
            val list = p.audioTracks?.filter { it.id >= 0 }.orEmpty()
            val t = list.firstOrNull { it.name == want } ?: list.firstOrNull { Tracks.lang(it.name ?: "") == Tracks.lang(want) }
            if (t != null && t.id != p.audioTrack) p.setAudioTrack(t.id)
        }
        Tracks.subs(this, tid)?.let { want ->
            if (want == Tracks.OFF) { p.setSpuTrack(-1); return }
            if (want.isBlank()) return
            val list = p.spuTracks?.filter { it.id >= 0 }.orEmpty()
            val t = list.firstOrNull { it.name == want } ?: list.firstOrNull { Tracks.lang(it.name ?: "") == Tracks.lang(want) }
            if (t != null) p.setSpuTrack(t.id)
        }
    }

    // ---- Saltar intro ----
    private fun checkSkip() {
        if (!::skipBtn.isInitialized) return
        val f = queue.getOrNull(index) ?: return
        val now = System.currentTimeMillis()
        if (skipBtn.visibility == View.VISIBLE) {
            if (now > skipUntil || timeMs > 200_000 || inPip) skipBtn.visibility = View.GONE
            return
        }
        if (f.episode <= 0 || !Players.skipIntroEnabled(this) || inPip || skipShownFor == index) return
        if (timeMs in 3_000..150_000) {
            skipShownFor = index
            skipUntil = now + 12_000
            skipBtn.visibility = View.VISIBLE
            if (!controlsShown) skipBtn.requestFocus()
        }
    }

    private fun skipIntro() {
        val p = mp ?: return
        val target = (runCatching { p.time }.getOrDefault(timeMs) + Players.introSec(this) * 1000L)
            .coerceAtMost(if (lengthMs > 0) lengthMs - 5_000 else Long.MAX_VALUE)
        p.setTime(target)
        timeMs = target
        skipBtn.visibility = View.GONE
        flash("⏭  " + Fmt.duration(target))
    }

    private fun chooseSpeed() {
        val p = mp ?: return
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val names = speeds.map { if (it == 1f) "Normal" else "${it}x" }.toTypedArray()
        val sel = speeds.indexOfFirst { kotlin.math.abs(it - p.rate) < 0.01f }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Velocidad")
            .setSingleChoiceItems(names, sel) { d, w -> p.setRate(speeds[w]); TitlePrefs.setFloat(this, titleId(), "velocidad", speeds[w]); d.dismiss(); hideBars() }
            .setOnDismissListener { hideBars() }
            .show()
    }

    private val scaleModes get() = listOf(
        MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FIT_SCREEN, MediaPlayer.ScaleType.SURFACE_FILL,
        MediaPlayer.ScaleType.SURFACE_16_9, MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL)

    /** Tamaño de pantalla, velocidad y sincronía guardados para esta serie/película. */
    private fun applyRememberedSettings() {
        val p = mp ?: return
        val tid = titleId()
        TitlePrefs.getInt(this, tid, "pantalla", 0).let { if (it in scaleModes.indices && it != 0) { scale = it; p.setVideoScale(scaleModes[it]) } }
        TitlePrefs.getFloat(this, tid, "velocidad", 1f).let { if (it != 1f) p.setRate(it) }
        val ad = TitlePrefs.getLong(this, tid, "audio_ms", Long.MIN_VALUE).takeIf { it != Long.MIN_VALUE } ?: Players.audioDelayMs(this)
        if (ad != 0L) p.setAudioDelay(ad * 1000)
        TitlePrefs.getLong(this, tid, "subs_ms", 0).let { if (it != 0L) p.setSpuDelay(it * 1000) }
    }

    private fun cycleScale() {
        val p = mp ?: return
        val modes = listOf(
            MediaPlayer.ScaleType.SURFACE_BEST_FIT to "Ajustar",
            MediaPlayer.ScaleType.SURFACE_FIT_SCREEN to "Llenar pantalla",
            MediaPlayer.ScaleType.SURFACE_FILL to "Estirar",
            MediaPlayer.ScaleType.SURFACE_16_9 to "16:9",
            MediaPlayer.ScaleType.SURFACE_4_3 to "4:3",
            MediaPlayer.ScaleType.SURFACE_ORIGINAL to "Original"
        )
        scale = (scale + 1) % modes.size
        p.setVideoScale(modes[scale].first)
        flash(modes[scale].second)
        TitlePrefs.setInt(this, titleId(), "pantalla", scale)
    }

    // ======================= Control remoto =======================
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (external) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val code = event.keyCode
        // Teclas multimedia: siempre
        when (code) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> { togglePlay(); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(30_000, event.repeatCount); return true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-30_000, event.repeatCount); return true }
            KeyEvent.KEYCODE_MEDIA_NEXT -> { nextBtn.performClick(); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { prevBtn.performClick(); return true }
        }
        if (errorCard.visibility == View.VISIBLE || nextCard.visibility == View.VISIBLE) {
            if (code == KeyEvent.KEYCODE_BACK) { ui.removeCallbacks(countdownTick); finish(); return true }
            return super.dispatchKeyEvent(event)
        }
        if (!controlsShown && skipBtn.visibility == View.VISIBLE &&
            code in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER)) { skipIntro(); return true }
        if (!controlsShown) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(-10_000, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(10_000, event.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_SPACE -> { togglePlay(); return true }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MENU -> { setControls(true); return true }
            }
        } else {
            if (code == KeyEvent.KEYCODE_BACK) { setControls(false); return true }
            scheduleHide()
        }
        return super.dispatchKeyEvent(event)
    }

    // ======================= Órdenes del celular =======================
    private fun sendStatus() {
        val p = mp ?: return
        val f = queue.getOrNull(index) ?: return
        val t = Catalog.title(f.titleId)
        RemoteLib.reportStatus(this, org.json.JSONObject()
            .put("f", f.id).put("title", t?.name ?: f.fileName)
            .put("sub", if (f.episode > 0) "${f.code}  ${f.epName}" else "")
            .put("pos", runCatching { p.time }.getOrDefault(timeMs)).put("len", lengthMs)
            .put("playing", p.isPlaying))
    }

    private fun onRemoteCommand(c: org.json.JSONObject) {
        val p = mp ?: return
        when (c.optString("c")) {
            "toggle" -> togglePlay()
            "pause" -> if (p.isPlaying) togglePlay()
            "resume" -> if (!p.isPlaying) togglePlay()
            "rel" -> seekBy(c.optLong("ms"), 0)
            "seek" -> { val to = c.optLong("to"); p.setTime(to); timeMs = to; flash(Fmt.duration(to)) }
            "next" -> nextBtn.performClick()
            "prev" -> prevBtn.performClick()
            "skip" -> skipIntro()
            "stop" -> finish()
        }
        sendStatus()
    }

    // ======================= Ventana flotante (celular) =======================
    private fun pipSupported(): Boolean = Build.VERSION.SDK_INT >= 26 && !Tv.on &&
        packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun canPip(): Boolean = pipSupported() && !external && mp?.isPlaying == true && Players.pipEnabled(this)

    private fun pipParams(auto: Boolean): PictureInPictureParams {
        val b = PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9))
        // Android 12+: hay que avisar ANTES que el video puede pasar a ventanita al salir con Inicio
        if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(auto).setSeamlessResizeEnabled(true)
        return b.build()
    }

    /** Se llama al reproducir/pausar: deja lista (o quita) la ventanita automática. */
    private fun updatePip() {
        if (!pipSupported()) return
        runCatching { setPictureInPictureParams(pipParams(canPip())) }
    }

    private fun enterPip(force: Boolean = false) {
        if (!pipSupported() || (!force && !canPip())) return
        val ok = runCatching { enterPictureInPictureMode(pipParams(canPip())) }.getOrDefault(false)
        if (!ok && force) Toast.makeText(this, "Activa \"Imagen en imagen\" para Mi Cine en los ajustes de Android (Apps → Mi Cine).", Toast.LENGTH_LONG).show()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // En Android 12+ lo hace el sistema solo (setAutoEnterEnabled); antes, se pide aquí.
        if (Build.VERSION.SDK_INT < 31) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (inPip) {
            setControls(false)
            flashView.visibility = View.GONE
            skipBtn.visibility = View.GONE
            nextCard.visibility = View.GONE
        }
    }

    // ======================= Pantalla completa =======================
    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    // ======================= Progreso =======================
    private fun saveCurrent(persist: Boolean) {
        val p = mp ?: return
        val f = queue.getOrNull(index)?.let { Catalog.file(it.id) } ?: return
        val len = lengthMs.takeIf { it > 0 } ?: runCatching { p.length }.getOrDefault(0)
        if (len > 0) f.durationMs = len
        val pos = runCatching { p.time }.getOrDefault(timeMs)
        if (pos > 0) {
            f.positionMs = pos
            f.watchedAt = System.currentTimeMillis()
            f.finished = f.durationMs > 0 && pos > f.durationMs * 0.93
        }
        if (persist) Catalog.saveNow() else Catalog.save()
        RemoteLib.reportProgress(this, f)
    }

    private fun markFinished(file: MediaFile) {
        val f = Catalog.file(file.id) ?: return
        f.finished = true
        f.positionMs = 0
        f.watchedAt = System.currentTimeMillis()
        Catalog.save()
    }

    // ======================= App VLC externa =======================
    private fun openInVlcApp() {
        val f = queue.getOrNull(index)?.let { Catalog.file(it.id) } ?: run { finish(); return }
        val resume = if (!f.finished && f.positionMs > 5_000) f.positionMs else 0L
        val t = Catalog.title(f.titleId)
        val name = (t?.name ?: f.fileName) + if (f.episode > 0) " · ${f.code}" else ""
        val i = Intent(Intent.ACTION_VIEW)
            .setPackage(Players.VLC_PACKAGE)
            .setDataAndType(Uri.parse(f.url), "video/*")
            .putExtra("title", name)
            .putExtra("position", resume)
            .putExtra("from_start", resume == 0L)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { startActivityForResult(i, REQ_VLC) }.onFailure {
            Toast.makeText(this, "No encontré la app VLC. Cambia el reproductor en Ajustes.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("API de Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SUB) { if (resultCode == RESULT_OK) data?.data?.let { onSubtitlePicked(it) }; return }
        if (requestCode != REQ_VLC) return
        val f = queue.getOrNull(index)?.let { Catalog.file(it.id) }
        val pos = data?.getLongExtra("extra_position", -1L) ?: -1L
        val dur = data?.getLongExtra("extra_duration", -1L) ?: -1L
        if (f != null && pos >= 0) {
            if (dur > 0) f.durationMs = dur
            f.positionMs = pos
            f.watchedAt = System.currentTimeMillis()
            f.finished = f.durationMs > 0 && pos > f.durationMs * 0.93
            Catalog.saveNow()
        }
        finish()
    }
}
