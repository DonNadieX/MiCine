package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class TmdbResult(val id: Int, val kind: Kind, val name: String, val year: Int, val poster: String?, val overview: String, val src: String = "tmdb")

data class TmdbEpisode(val name: String, val overview: String, val still: String?, val runtimeMin: Int)

/**
 * The Movie Database (themoviedb.org): portadas, sinopsis, géneros y nombres de episodios.
 * Acepta la "API Key" corta (v3) o el "Token de acceso de lectura" largo (v4).
 */
object Tmdb {
    private const val API = "https://api.themoviedb.org/3"
    const val IMG_POSTER = "https://image.tmdb.org/t/p/w500"
    const val IMG_BACKDROP = "https://image.tmdb.org/t/p/w1280"
    const val IMG_STILL = "https://image.tmdb.org/t/p/w300"
    private const val LANG = "es-MX"

    fun key(ctx: Context): String =
        ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("tmdb", "")?.trim().orEmpty()

    fun setKey(ctx: Context, k: String) =
        ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putString("tmdb", k.trim()).apply()

    fun hasKey(ctx: Context) = key(ctx).isNotBlank()

    private fun get(ctx: Context, path: String, params: Map<String, String> = emptyMap()): JSONObject {
        val k = key(ctx)
        val bearer = k.length > 40
        val q = StringBuilder()
        (params + ("language" to (params["language"] ?: LANG))).forEach { (a, b) ->
            if (b.isNotBlank()) q.append(if (q.isEmpty()) "?" else "&").append(a).append('=').append(URLEncoder.encode(b, "UTF-8"))
        }
        if (!bearer) q.append(if (q.isEmpty()) "?" else "&").append("api_key=").append(URLEncoder.encode(k, "UTF-8"))
        val c = URL(API + path + q).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 15_000
        c.setRequestProperty("Accept", "application/json")
        if (bearer) c.setRequestProperty("Authorization", "Bearer $k")
        try {
            val code = c.responseCode
            if (code == 401) throw IllegalStateException("Clave de TMDB inválida")
            if (code !in 200..299) throw IllegalStateException("TMDB respondió $code")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Prueba la clave. Devuelve null si funciona, o el mensaje de error. */
    fun test(ctx: Context): String? = runCatching { get(ctx, "/configuration"); null }.getOrElse { it.message ?: "Error" }

    fun search(ctx: Context, query: String, kind: Kind?, year: Int = 0): List<TmdbResult> {
        val out = mutableListOf<TmdbResult>()
        val kinds = if (kind == null) listOf(Kind.SERIES, Kind.MOVIE) else listOf(kind)
        for (k in kinds) {
            val params = mutableMapOf("query" to query, "include_adult" to "false")
            if (year > 0) params[if (k == Kind.SERIES) "first_air_date_year" else "year"] = year.toString()
            var res = runCatching { get(ctx, if (k == Kind.SERIES) "/search/tv" else "/search/movie", params) }.getOrNull()
            // Si con año no encontró nada, reintenta sin año.
            if (year > 0 && (res?.optJSONArray("results")?.length() ?: 0) == 0) {
                params.remove("first_air_date_year"); params.remove("year")
                res = runCatching { get(ctx, if (k == Kind.SERIES) "/search/tv" else "/search/movie", params) }.getOrNull()
            }
            val arr = res?.optJSONArray("results") ?: continue
            for (i in 0 until minOf(arr.length(), 10)) {
                val o = arr.getJSONObject(i)
                val date = o.optString(if (k == Kind.SERIES) "first_air_date" else "release_date")
                out.add(
                    TmdbResult(
                        id = o.optInt("id"),
                        kind = k,
                        name = o.optString(if (k == Kind.SERIES) "name" else "title"),
                        year = date.take(4).toIntOrNull() ?: 0,
                        poster = o.optString("poster_path").takeIf { it.startsWith("/") }?.let { IMG_POSTER + it },
                        overview = o.optString("overview")
                    )
                )
            }
        }
        return out
    }

    /** Llena un título con todos los datos de TMDB. */
    fun applyDetails(ctx: Context, t: Title, id: Int, kind: Kind) {
        val path = if (kind == Kind.SERIES) "/tv/$id" else "/movie/$id"
        val o = get(ctx, path)
        t.tmdbId = id
        t.kind = kind
        t.name = o.optString(if (kind == Kind.SERIES) "name" else "title").ifBlank { t.name }
        t.year = o.optString(if (kind == Kind.SERIES) "first_air_date" else "release_date").take(4).toIntOrNull() ?: t.year
        t.overview = o.optString("overview")
        if (t.overview.isBlank()) {
            t.overview = runCatching { get(ctx, path, mapOf("language" to "en-US")).optString("overview") }.getOrDefault("")
        }
        o.optString("poster_path").takeIf { it.startsWith("/") }?.let { t.poster = IMG_POSTER + it }
        o.optString("backdrop_path").takeIf { it.startsWith("/") }?.let { t.backdrop = IMG_BACKDROP + it }
        val g = o.optJSONArray("genres")
        if (g != null) t.genres = (0 until g.length()).map { g.getJSONObject(it).optString("name") }.filter { it.isNotBlank() }
        t.rating = o.optDouble("vote_average", 0.0)
        t.status = when (o.optString("status")) {
            "Returning Series" -> "En emisión"
            "Ended" -> "Finalizada"
            "Canceled" -> "Cancelada"
            "In Production" -> "En producción"
            "Released" -> "Estrenada"
            "Post Production" -> "Postproducción"
            "Planned" -> "Planeada"
            else -> o.optString("status")
        }
        if (kind == Kind.SERIES) {
            t.totalSeasons = o.optInt("number_of_seasons")
            t.totalEpisodes = o.optInt("number_of_episodes")
        }
    }

    /** Nombres e imágenes de los episodios de una temporada. */
    fun season(ctx: Context, tvId: Int, season: Int): Map<Int, TmdbEpisode> {
        val o = runCatching { get(ctx, "/tv/$tvId/season/$season") }.getOrNull() ?: return emptyMap()
        val arr = o.optJSONArray("episodes") ?: return emptyMap()
        val map = mutableMapOf<Int, TmdbEpisode>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            map[e.optInt("episode_number")] = TmdbEpisode(
                name = e.optString("name"),
                overview = e.optString("overview"),
                still = e.optString("still_path").takeIf { it.startsWith("/") }?.let { IMG_STILL + it },
                runtimeMin = e.optInt("runtime")
            )
        }
        return map
    }

    /** Pone nombres, sinopsis e imagen a todos los episodios de una serie. */
    fun fillEpisodes(ctx: Context, t: Title) {
        if (t.kind != Kind.SERIES || t.tmdbId == 0) return
        val files = Catalog.filesOf(t.id)
        files.map { it.season }.distinct().forEach { s ->
            val eps = season(ctx, t.tmdbId, s)
            files.filter { it.season == s }.forEach { f ->
                eps[f.episode]?.let { e ->
                    if (e.name.isNotBlank()) f.epName = e.name
                    f.epOverview = e.overview
                    f.still = e.still
                    if (f.durationMs == 0L && e.runtimeMin > 0) f.durationMs = e.runtimeMin * 60_000L
                }
            }
        }
    }

    /** Busca por código de IMDb (tt1234567). */
    fun findImdb(ctx: Context, imdb: String): TmdbResult? {
        val o = get(ctx, "/find/$imdb", mapOf("external_source" to "imdb_id"))
        o.optJSONArray("tv_results")?.optJSONObject(0)?.let { s ->
            return TmdbResult(s.optInt("id"), Kind.SERIES, s.optString("name"),
                s.optString("first_air_date").take(4).toIntOrNull() ?: 0, null, s.optString("overview"))
        }
        o.optJSONArray("movie_results")?.optJSONObject(0)?.let { m ->
            return TmdbResult(m.optInt("id"), Kind.MOVIE, m.optString("title"),
                m.optString("release_date").take(4).toIntOrNull() ?: 0, null, m.optString("overview"))
        }
        return null
    }

    /** Busca automáticamente el mejor resultado y lo aplica. */
    fun autoMatch(ctx: Context, t: Title): Boolean {
        val results = search(ctx, t.name, t.kind, t.year)
        val key = NameParser.key(t.name)
        val best = results.firstOrNull { NameParser.key(it.name) == key && (t.year == 0 || it.year == t.year) }
            ?: results.firstOrNull { NameParser.key(it.name) == key }
            ?: results.firstOrNull()
            ?: return false
        applyDetails(ctx, t, best.id, best.kind)
        fillEpisodes(ctx, t)
        return true
    }
}
