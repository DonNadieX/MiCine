package com.donnadiex.enlaceplay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Detalles visuales de la ficha: color de cada serie, origen, anillos de progreso, reparto. */
object Look {

    // ---------------- Color principal del póster ----------------

    /** Busca el color más vivo y representativo de una imagen. */
    fun dominant(bmp: Bitmap): Int {
        val small = Bitmap.createScaledBitmap(bmp, 48, 72, true)
        val buckets = HashMap<Int, FloatArray>()   // hue/15 → [peso, r, g, b]
        val hsv = FloatArray(3)
        for (x in 0 until small.width) for (y in 0 until small.height) {
            val c = small.getPixel(x, y)
            Color.colorToHSV(c, hsv)
            val s = hsv[1]; val v = hsv[2]
            if (v < 0.18f || v > 0.97f && s < 0.1f) continue
            val w = s * s * (0.4f + v) + 0.02f
            val k = (hsv[0] / 15f).toInt()
            val b = buckets.getOrPut(k) { FloatArray(4) }
            b[0] += w; b[1] += Color.red(c) * w; b[2] += Color.green(c) * w; b[3] += Color.blue(c) * w
        }
        val best = buckets.values.maxByOrNull { it[0] } ?: return Color.rgb(90, 30, 40)
        return Color.rgb((best[1] / best[0]).toInt(), (best[2] / best[0]).toInt(), (best[3] / best[0]).toInt())
    }

    /** Descarga (o lee de caché) el póster y calcula su color. */
    suspend fun computeTint(ctx: Context, t: Title): Int? {
        val bmp: Bitmap? = withContext(Dispatchers.IO) {
            val local = t.localCover()
            when {
                !t.poster.isNullOrBlank() -> {
                    val req = ImageRequest.Builder(ctx).data(t.poster).allowHardware(false).size(160).build()
                    ((coil.Coil.imageLoader(ctx).execute(req) as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
                }
                local != null && File(local).exists() -> BitmapFactory.decodeFile(local, BitmapFactory.Options().apply { inSampleSize = 8 })
                else -> null
            }
        }
        return bmp?.let { withContext(Dispatchers.Default) { dominant(it) } }
    }

    /** Ajusta el brillo y la saturación de un color (para fondos oscuros o claros). */
    fun tone(c: Int, value: Float, satMul: Float = 1f): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = (hsv[1] * satMul).coerceIn(0f, 1f)
        hsv[2] = value
        return Color.HSVToColor(hsv)
    }

    /** Fondo degradado con el color de la serie, que se funde con el fondo del tema. */
    fun ambient(tint: Int): GradientDrawable {
        val bg = Col.BG
        val top: Int
        val mid: Int
        if (Themes.cur.light) {
            top = Col.blend(tone(tint, 0.95f, 0.35f), bg, 0.15f)
            mid = Col.blend(top, bg, 0.6f)
        } else {
            top = tone(tint, 0.36f, 0.85f)
            mid = Col.blend(tone(tint, 0.16f, 0.9f), bg, 0.3f)
        }
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, mid, bg, bg))
    }

    fun topColor(tint: Int): Int =
        if (Themes.cur.light) Col.blend(tone(tint, 0.95f, 0.35f), Col.BG, 0.15f) else tone(tint, 0.36f, 0.85f)

    /** Un color claro de la serie para textos de acento sobre el fondo. */
    fun soft(tint: Int): Int = if (Themes.cur.light) tone(tint, 0.45f, 1f) else tone(tint, 0.95f, 0.45f)

    // ---------------- Origen ----------------

    fun flag(code: String): String {
        if (code.length != 2) return ""
        val a = Character.toChars(0x1F1E6 + (code[0].uppercaseChar() - 'A'))
        val b = Character.toChars(0x1F1E6 + (code[1].uppercaseChar() - 'A'))
        return String(a) + String(b)
    }

    /** "K-drama", "Anime", "Serie" … según el país y el tipo. */
    fun originLabel(t: Title): String {
        val o = t.origin.uppercase()
        val series = t.kind == Kind.SERIES
        if (t.anime) return when (o) {
            "CN" -> "Donghua"
            "KR" -> "Animación coreana"
            else -> if (series) "Anime" else "Película anime"
        }
        if (!series) return when (o) {
            "KR" -> "Cine coreano"; "JP" -> "Cine japonés"; "CN", "HK", "TW" -> "Cine chino"
            "MX" -> "Cine mexicano"; "ES" -> "Cine español"; "IN" -> "Bollywood"
            else -> "Película"
        }
        return when (o) {
            "KR" -> "K-drama"; "JP" -> "J-drama"; "CN" -> "C-drama"; "TW" -> "Drama taiwanés"
            "TH" -> "Drama tailandés"; "TR" -> "Serie turca"; "MX", "CO", "AR", "VE" -> "Telenovela / serie latina"
            "ES" -> "Serie española"; "GB" -> "Serie británica"
            else -> "Serie"
        }
    }

    // ---------------- Anillo de progreso ----------------

    class Ring(ctx: Context, private val done: Int, private val total: Int, private val accent: Int) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B3000000") }
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        private val box = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val stroke = w * 0.09f
            p.strokeWidth = stroke
            box.set(stroke, stroke, w - stroke, w - stroke)
            c.drawCircle(w / 2, w / 2, w / 2 - stroke / 2, fill)
            p.color = Color.parseColor("#55FFFFFF")
            c.drawArc(box, 0f, 360f, false, p)
            if (total > 0 && done > 0) {
                p.color = accent
                p.strokeCap = Paint.Cap.ROUND
                c.drawArc(box, -90f, 360f * done / total, false, p)
            }
            val label = if (done >= total && total > 0) "✓" else "$done/$total"
            tp.textSize = w * if (label.length > 4) 0.22f else 0.27f
            c.drawText(label, w / 2, w / 2 - (tp.descent() + tp.ascent()) / 2, tp)
        }
    }
}

// ---------------- Piezas reutilizables ----------------

/** Etiqueta de origen con bandera: "🇰🇷 K-drama". */
fun Context.originTag(t: Title, tint: Int): TextView {
    val label = (Look.flag(t.origin).let { if (it.isNotBlank()) "$it " else "" }) + Look.originLabel(t)
    val c = if (tint != 0) Look.soft(tint) else Col.RED
    return txt(label, 12f, c, true).apply {
        background = rounded((c and 0x00FFFFFF) or 0x26000000, dpf(12f), dp(1), (c and 0x00FFFFFF) or 0x80000000.toInt())
        setPadding(dp(10), dp(4), dp(10), dp(4))
    }
}

/** Tarjeta de una persona del reparto: foto redonda, nombre y personaje. */
fun Context.castCard(c: CastMember): View {
    val w = dp(84)
    val box = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL }
    val photo = FrameLayout(this).apply {
        background = rounded(Col.CARD2, dpf(42f))
        clipToOutline = true
    }
    val img = ImageView(this)
    photo.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    if (c.photo != null) img.show(c.photo) else {
        val initials = c.name.split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1) }.uppercase()
        photo.addView(txt(initials, 22f, Col.MUTED, true).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
    }
    box.addView(photo, LinearLayout.LayoutParams(dp(72), dp(72)))
    box.addView(txt(c.name, 12f, Col.TEXT, true, 2).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }, LinearLayout.LayoutParams(w, WRAP))
    if (c.role.isNotBlank()) box.addView(txt(c.role, 11f, Col.MUTED, false, 2).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(w, WRAP))
    box.layoutParams = LinearLayout.LayoutParams(w, WRAP)
    return box
}
