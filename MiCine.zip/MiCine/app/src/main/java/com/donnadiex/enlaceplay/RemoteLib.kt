package com.donnadiex.enlaceplay

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import coil.intercept.Interceptor
import coil.request.ErrorResult
import coil.request.ImageResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.net.URLEncoder

/**
 * "Mi celular" (lado del proyector):
 *  - Encuentra el celular que comparte su biblioteca (en su punto de acceso o en el mismo Wi-Fi).
 *  - Copia su catálogo con pósters y datos; los videos se ven directo desde el celular.
 *  - Escucha las órdenes del celular (reproducir, pausa, adelantar, volumen…).
 *  - Avisa al celular hasta dónde viste.
 */
object RemoteLib {
    data class Host(val ip: String, val id: String, val name: String)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private val main = Handler(Looper.getMainLooper())

    /** IP actual del celular (si ya se encontró). */
    @Volatile var currentHost: String? = null

    /** El reproductor abierto recibe aquí las órdenes. */
    @Volatile var playerListener: ((JSONObject) -> Unit)? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("mi_celular", Context.MODE_PRIVATE)
    fun savedId(ctx: Context) = prefs(ctx).getString("id", null)
    fun savedName(ctx: Context) = prefs(ctx).getString("name", null)
    private fun savedIp(ctx: Context) = prefs(ctx).getString("ip", null)
    fun hasDevice(ctx: Context) = savedId(ctx) != null

    fun forget(ctx: Context) {
        val id = savedId(ctx)
        prefs(ctx).edit().clear().apply()
        currentHost = null
        loop?.cancel(); loop = null
        if (id != null) {
            Catalog.allFiles().filter { it.source == "red:$id" }.forEach { Catalog.deleteFile(it.id) }
            Catalog.dropEmptyTitles()
            Catalog.save()
        }
    }

    fun isRemote(url: String) = url.startsWith("micine://")

    /** micine://<celular>/<archivo> → http://ip:8766/micine/v/<archivo> */
    fun resolve(ctx: Context, url: String): String? {
        if (!isRemote(url)) return url
        val host = currentHost ?: savedIp(ctx) ?: return null
        val fileId = url.removePrefix("micine://").substringAfter('/')
        return "http://$host:${LibraryShare.PORT}/micine/v/$fileId"
    }

    // ======================= Encontrar el celular =======================
    private fun get(url: String, timeout: Int = 2500, readTimeout: Int = timeout): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = readTimeout
        try { if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null } finally { c.disconnect() }
    }.getOrNull()

    private fun post(url: String, body: String) = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 2500; c.readTimeout = 4000
        c.setRequestProperty("Content-Type", "application/json")
        try { c.outputStream.use { it.write(body.toByteArray()) }; c.responseCode } finally { c.disconnect() }
    }

    private fun probe(ip: String): Host? {
        val txt = get("http://$ip:${LibraryShare.PORT}/micine/info", 1500) ?: return null
        val o = runCatching { JSONObject(txt) }.getOrNull() ?: return null
        if (o.optString("app") != "micine") return null
        return Host(ip, o.optString("id"), o.optString("name"))
    }

    /** La puerta de enlace: si el proyector está en el punto de acceso del celular, es el celular. */
    @Suppress("DEPRECATION")
    private fun gateway(ctx: Context): String? = runCatching {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: 0
        if (g == 0) null else "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
    }.getOrNull()

    /** Pregunta por la red "¿hay algún Mi Cine compartiendo?" (SSDP). */
    private fun ssdp(): List<String> {
        val found = mutableListOf<String>()
        runCatching {
            DatagramSocket().use { s ->
                s.soTimeout = 700
                s.broadcast = true
                val m = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ${LibraryShare.ST_MICINE}\r\n\r\n".toByteArray()
                s.send(DatagramPacket(m, m.size, InetAddress.getByName("239.255.255.250"), 1900))
                runCatching { s.send(DatagramPacket(m, m.size, InetAddress.getByName("255.255.255.255"), 1900)) }
                val buf = ByteArray(2048)
                val end = System.currentTimeMillis() + 2500
                while (System.currentTimeMillis() < end) {
                    val pk = DatagramPacket(buf, buf.size)
                    try { s.receive(pk) } catch (_: java.net.SocketTimeoutException) { continue }
                    val msg = String(pk.data, 0, pk.length)
                    if (!msg.contains(LibraryShare.ST_MICINE)) continue
                    Regex("(?im)^LOCATION:\\s*http://([^:/]+)").find(msg)?.groupValues?.get(1)?.let { if (it !in found) found += it }
                }
            }
        }
        return found
    }

    /** Busca el celular: el último conocido, la puerta de enlace y luego la red. */
    suspend fun discover(ctx: Context): Host? = withContext(Dispatchers.IO) {
        val tried = mutableSetOf<String>()
        listOfNotNull(currentHost, savedIp(ctx), gateway(ctx)).forEach { ip ->
            if (tried.add(ip)) probe(ip)?.let { return@withContext it }
        }
        ssdp().forEach { ip -> if (tried.add(ip)) probe(ip)?.let { return@withContext it } }
        null
    }

    suspend fun connect(ctx: Context, h: Host) {
        currentHost = h.ip
        prefs(ctx).edit().putString("id", h.id).putString("name", h.name).putString("ip", h.ip).apply()
    }

    // ======================= Copiar el catálogo =======================
    data class SyncResult(val titles: Int, val files: Int, val removed: Int)

    suspend fun sync(ctx: Context, h: Host, onProgress: (String) -> Unit = {}): SyncResult = withContext(Dispatchers.IO) {
        val txt = get("http://${h.ip}:${LibraryShare.PORT}/micine/catalog?n=" + URLEncoder.encode(myName(), "UTF-8"), 4000, 60_000)
            ?: error("El celular no respondió")
        val o = JSONObject(txt)
        val dev = o.optString("id")
        val tArr = o.optJSONArray("titles") ?: org.json.JSONArray()
        val fArr = o.optJSONArray("files") ?: org.json.JSONArray()
        val idMap = mutableMapOf<String, String>()
        var newTitles = 0
        for (i in 0 until tArr.length()) {
            val rt = Catalog.titleFrom(tArr.getJSONObject(i))
            val mine = Catalog.title(rt.id) ?: Catalog.findTitle(rt.kind, rt.parsedKey)
            if (mine == null) {
                rt.tint = 0
                Catalog.addTitle(rt); newTitles++
                idMap[rt.id] = rt.id
            } else {
                idMap[rt.id] = mine.id
                // Si en el proyector le faltan datos, se toman los del celular
                if (mine.ext.isBlank() && rt.ext.isNotBlank()) {
                    mine.ext = rt.ext; mine.tmdbId = rt.tmdbId; mine.name = rt.name; mine.year = rt.year
                    mine.poster = rt.poster; mine.backdrop = rt.backdrop; mine.overview = rt.overview
                    mine.genres = rt.genres; mine.rating = rt.rating; mine.status = rt.status
                    mine.totalSeasons = rt.totalSeasons; mine.totalEpisodes = rt.totalEpisodes
                    mine.origin = rt.origin; mine.network = rt.network; mine.seasons = rt.seasons
                    mine.cast = rt.cast; mine.anime = rt.anime
                }
                if (mine.saga.isBlank() && rt.saga.isNotBlank()) { mine.saga = rt.saga
                }
            }
        }
        val remoteIds = mutableSetOf<String>()
        var added = 0
        val coversDir = File(ctx.filesDir, "covers").apply { mkdirs() }
        for (i in 0 until fArr.length()) {
            val jo = fArr.getJSONObject(i)
            val hasCover = jo.optString("cover") == "1"
            jo.put("cover", "")
            val rf = Catalog.fileFrom(jo)
            remoteIds += rf.id
            val tid = idMap[rf.titleId] ?: rf.titleId
            val existing = Catalog.file(rf.id)
            if (existing != null) {
                if (rf.watchedAt > existing.watchedAt) {
                    existing.positionMs = rf.positionMs; existing.finished = rf.finished; existing.watchedAt = rf.watchedAt
                }
                if (rf.durationMs > 0) existing.durationMs = rf.durationMs
                existing.epName = rf.epName.ifBlank { existing.epName }; existing.still = rf.still ?: existing.still
                continue
            }
            // Un link de internet que el proyector ya tiene: no se repite
            if (!isRemote(rf.url) && Catalog.fileByUrl(rf.url) != null) continue
            val nf = MediaFile(
                id = rf.id, titleId = tid, season = rf.season, episode = rf.episode, url = rf.url,
                fileName = rf.fileName, quality = rf.quality, epName = rf.epName, epOverview = rf.epOverview,
                still = rf.still, durationMs = rf.durationMs, positionMs = rf.positionMs, watchedAt = rf.watchedAt,
                finished = rf.finished, addedAt = rf.addedAt, source = "red:$dev"
            )
            if (hasCover) {
                val out = File(coversDir, "red_${rf.id}.jpg")
                if (!out.exists()) runCatching {
                    val c = URL("http://${h.ip}:${LibraryShare.PORT}/micine/cover/${rf.id}").openConnection() as HttpURLConnection
                    c.connectTimeout = 3000; c.readTimeout = 10_000
                    if (c.responseCode == 200) c.inputStream.use { inp -> out.outputStream().use { inp.copyTo(it) } }
                    c.disconnect()
                }
                if (out.exists() && out.length() > 0) nf.coverPath = out.absolutePath
            }
            Catalog.addFile(nf)
            added++
            if (added % 50 == 0) onProgress("$added videos…")
        }
        // Lo que ya no está en el celular se quita del proyector
        val gone = Catalog.allFiles().filter { it.source == "red:$dev" && it.id !in remoteIds }
        gone.forEach { Catalog.deleteFile(it.id) }
        Catalog.dropEmptyTitles()
        Catalog.save()
        SyncResult(newTitles, added, gone.size)
    }

    private fun myName() = (Build.MANUFACTURER + " " + Build.MODEL).trim()

    // ======================= Avisos al celular =======================
    fun reportProgress(ctx: Context, f: MediaFile) {
        if (!isRemote(f.url)) return
        val host = currentHost ?: savedIp(ctx) ?: return
        val body = JSONObject().put("f", f.id).put("pos", f.positionMs).put("dur", f.durationMs)
            .put("done", f.finished).put("watched", f.watchedAt).toString()
        scope.launch { post("http://$host:${LibraryShare.PORT}/micine/progress", body) }
    }

    fun reportStatus(ctx: Context, o: JSONObject) {
        val host = currentHost ?: return
        scope.launch { post("http://$host:${LibraryShare.PORT}/micine/status?n=" + URLEncoder.encode(myName(), "UTF-8"), o.toString()) }
    }

    // ======================= Escuchar órdenes =======================
    /** Mientras la app esté abierta, espera órdenes del celular (y lo vuelve a buscar si cambia de IP). */
    fun ensureLoop(ctx: Context) {
        if (loop?.isActive == true || !hasDevice(ctx)) return
        val app = ctx.applicationContext
        loop = scope.launch {
            var fails = 0
            while (isActive && hasDevice(app)) {
                val host = currentHost ?: run {
                    val h = discover(app)
                    if (h != null && h.id == savedId(app)) { connect(app, h); h.ip } else null
                }
                if (host == null) { delay(if (fails++ < 3) 5_000 else 20_000); continue }
                val txt = get("http://$host:${LibraryShare.PORT}/micine/cmd?wait=20&n=" + URLEncoder.encode(myName(), "UTF-8"), 3000, 26_000)
                if (txt == null) {
                    fails++
                    if (fails >= 2) currentHost = null
                    delay(3_000)
                    continue
                }
                fails = 0
                val cmd = runCatching { JSONObject(txt) }.getOrNull() ?: continue
                if (cmd.length() == 0) continue
                main.post { handle(app, cmd) }
            }
        }
    }

    private fun handle(ctx: Context, cmd: JSONObject) {
        when (cmd.optString("c")) {
            "play" -> {
                val fid = cmd.optString("f")
                val start = { f: MediaFile ->
                    if (cmd.has("pos")) { f.positionMs = cmd.optLong("pos"); f.finished = false }
                    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("file", f.id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                }
                val f = Catalog.file(fid)
                if (f != null) start(f)
                else scope.launch {
                    // Algo nuevo en el celular: primero se copia el catálogo
                    val h = currentHost?.let { probe(it) }
                    if (h != null) runCatching { sync(ctx, h) }
                    main.post { Catalog.file(fid)?.let(start) }
                }
            }
            "vol" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    if (cmd.optInt("d") > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            }
            "bye" -> currentHost = null
            else -> playerListener?.invoke(cmd)
        }
    }
}

/**
 * Pósters sin internet: si una imagen no se puede bajar, se pide al celular
 * (que ya la tiene guardada) y queda guardada en el proyector con el mismo nombre.
 */
class LanImageInterceptor : Interceptor {
    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
        val result = chain.proceed(chain.request)
        val data = chain.request.data
        if (result !is ErrorResult || data !is String || !data.startsWith("http")) return result
        val host = RemoteLib.currentHost ?: return result
        if (data.contains(":${LibraryShare.PORT}/")) return result
        val alt = chain.request.newBuilder()
            .data("http://$host:${LibraryShare.PORT}/micine/img?u=" + URLEncoder.encode(data, "UTF-8"))
            .diskCacheKey(data)
            .memoryCacheKey(data)
            .build()
        return chain.proceed(alt)
    }
}
