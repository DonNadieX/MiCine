package com.donnadiex.enlaceplay

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

data class CleanReport(
    val repaired: Int = 0,
    val duplicates: Int = 0,
    val missing: Int = 0,
    val deadMarked: Int = 0,
    val deadRemoved: Int = 0,
    val serverDown: List<String> = emptyList()
) {
    val total get() = repaired + duplicates + missing + deadRemoved
    fun summary(): String = buildList {
        if (repaired > 0) add("$repaired capítulos reacomodados en su serie")
        if (duplicates > 0) add("$duplicates duplicados quitados")
        if (missing > 0) add("$missing archivos que ya no están, quitados")
        if (deadMarked > 0) add("$deadMarked links caídos marcados")
        if (deadRemoved > 0) add("$deadRemoved links caídos quitados")
        serverDown.forEach { add("El servidor $it no responde: no se borró nada de ahí") }
    }.joinToString("\n").ifBlank { "Todo en orden." }
}

/**
 * Mantenimiento automático tipo Kodi ("Limpiar biblioteca"):
 *  1. Repara series mal armadas (ej. una "serie" llamada "01x14") usando la carpeta del archivo.
 *  2. Quita duplicados del mismo archivo.
 *  3. Quita archivos locales que ya no están (solo en memorias conectadas).
 *  4. Revisa links: si el servidor dice que ya no existe, lo marca; si sigue así al día siguiente, lo quita.
 */
object Maintenance {

    private const val DAY = 24L * 60 * 60 * 1000

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    /** Ruta legible de un archivo local: "Download/K dramas/You're Beautiful/01x14.mp4". */
    fun localPath(ctx: Context, url: String): String? {
        if (MediaScan.isMediaUri(url)) return MediaScan.pathOf(ctx, url)
        return runCatching {
            val id = DocumentsContract.getDocumentId(Uri.parse(url))
            if (!id.contains(':')) null else id.substringAfter(':')
        }.getOrNull()
    }

    /** Clave para saber si dos entradas son el mismo archivo (aunque se agregaran de formas distintas). */
    private fun docKey(ctx: Context, url: String): String? = localPath(ctx, url)?.lowercase()

    // ---------------- 1. Reparar series mal armadas ----------------
    fun repairBareTitles(ctx: Context): Int {
        var moved = 0
        val bare = Catalog.titles().filter { t -> !NameParser.parse(t.name).hasName || t.name.matches(Regex("(?i)\\s*\\d{1,2}\\s*x\\s*\\d{1,3}\\s*")) }
        for (t in bare) {
            for (f in Catalog.filesOf(t.id)) {
                val path = if (Local.isLocal(f.url)) localPath(ctx, f.url) else null
                val label = if (path != null) {
                    val parts = path.split('/').filter { it.isNotBlank() }
                    Local.labelFor(parts.dropLast(1), parts.lastOrNull() ?: f.fileName)
                } else continue
                val p = NameParser.parse(label)
                if (!p.hasName) continue
                val kind = if (p.isSeries) Kind.SERIES else Kind.MOVIE
                val key = NameParser.key(p.name)
                val target = Catalog.findTitle(kind, key) ?: Title(kind = kind, name = p.name, year = p.year, parsedKey = key, anime = p.anime)
                    .also { Catalog.addTitle(it) }
                if (target.id == t.id) continue
                // Si la serie destino ya tiene ese mismo capítulo, el de la serie rota sobra.
                val same = Catalog.filesOf(target.id).firstOrNull { it.season == p.season && it.episode == p.episode && docKey(ctx, it.url) == docKey(ctx, f.url) }
                if (same != null) { Catalog.deleteFile(f.id); moved++; continue }
                f.season = if (p.isSeries) p.season.coerceAtLeast(1) else 0
                f.episode = p.episode
                if (f.quality.isBlank()) f.quality = p.quality
                Catalog.moveFile(f.id, target.id)
                moved++
            }
        }
        Catalog.dropEmptyTitles()
        return moved
    }

    // ---------------- 2. Duplicados ----------------
    /** El mismo archivo agregado dos veces (por ejemplo, al volver a elegir la carpeta). Se queda el que tiene más avance. */
    fun removeDuplicates(ctx: Context): Int {
        var n = 0
        Catalog.allFiles().filter { Local.isLocal(it.url) }.groupBy { docKey(ctx, it.url) ?: it.url }.values
            .filter { it.size > 1 }
            .forEach { group ->
                val keep = group.maxWith(compareBy<MediaFile>({ it.watchedAt }, { if (NameParser.parse(Catalog.title(it.titleId)?.name ?: "").hasName) 1 else 0 }))
                group.filter { it.id != keep.id }.forEach { Catalog.deleteFile(it.id); n++ }
            }
        return n
    }

    // ---------------- 4. Links caídos ----------------
    /**
     * Revisa hasta [max] links (los que llevan más tiempo sin revisar).
     * Protección: si casi todos los links de un mismo servidor fallan a la vez, se asume que el servidor
     * está caído y NO se marca ninguno (para no borrar tu biblioteca por una falla temporal).
     */
    suspend fun checkLinks(max: Int = 40): Triple<Int, Int, List<String>> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val links = Catalog.allFiles().filter { !Local.isLocal(it.url) && !RemoteLib.isRemote(it.url) && now - it.checkedAt > DAY / 2 }
            .sortedBy { it.checkedAt }.take(max)
        if (links.isEmpty()) return@withContext Triple(0, 0, emptyList())
        val results = mutableListOf<Pair<MediaFile, Int?>>()   // código HTTP o null si no hubo conexión
        links.chunked(5).forEach { chunk ->
            results += coroutineScope {
                chunk.map { f -> async { f to Analyzer.headers(f.url)?.code } }.awaitAll()
            }
        }
        val gone = { c: Int? -> c == 404 || c == 410 }
        val downHosts = results.groupBy { Uri.parse(it.first.url).host ?: "" }
            .filter { (_, r) -> r.size >= 3 && r.count { gone(it.second) } >= r.size * 0.8 }
            .keys
        var marked = 0
        var removed = 0
        for ((f, code) in results) {
            if (code == null) continue                       // sin internet: no se decide nada
            f.checkedAt = now
            val host = Uri.parse(f.url).host ?: ""
            if (gone(code) && host !in downHosts) {
                if (f.deadSince == 0L) { f.deadSince = now; marked++ }
                // Los de una lista compartida solo se marcan: los quita quien publica la lista.
                else if (f.source.isEmpty() && now - f.deadSince >= DAY * 20 / 24) { Catalog.deleteFile(f.id); removed++ }
            } else if (code in 200..399) f.deadSince = 0
        }
        Triple(marked, removed, downHosts.toList())
    }

    // ---------------- Todo junto ----------------
    suspend fun runAll(ctx: Context, checkLinks: Boolean): CleanReport {
        val (rep, dup, miss) = withContext(Dispatchers.IO) {
            Triple(
                runCatching { repairBareTitles(ctx) }.getOrDefault(0),
                runCatching { removeDuplicates(ctx) }.getOrDefault(0),
                runCatching { Local.cleanMissing(ctx) }.getOrDefault(0) + runCatching { MediaScan.cleanMissing(ctx) }.getOrDefault(0)
            )
        }
        val (marked, removed, down) = if (checkLinks) runCatching { checkLinks(if (Tv.lite) 15 else 40) }.getOrDefault(Triple(0, 0, emptyList()))
        else Triple(0, 0, emptyList())
        withContext(Dispatchers.IO) { ImageCache.cleanOrphanCovers(ctx) }
        Catalog.save()
        return CleanReport(rep, dup, miss, marked, removed, down)
    }

    /** Al abrir la app: siempre repara lo local; los links se revisan una vez al día. */
    suspend fun onAppOpen(ctx: Context): CleanReport? {
        val now = System.currentTimeMillis()
        // Como mucho cada 6 horas (abrir y cerrar la app no la vuelve a correr)
        if (now - prefs(ctx).getLong("limpieza_auto", 0) < 6 * 3_600_000L) return null
        prefs(ctx).edit().putLong("limpieza_auto", now).apply()
        val last = prefs(ctx).getLong("links_revisados", 0)
        val doLinks = now - last > (if (Tv.lite) 7 * DAY else DAY)
        val r = runAll(ctx, doLinks)
        if (doLinks) prefs(ctx).edit().putLong("links_revisados", System.currentTimeMillis()).apply()
        return r
    }
}
