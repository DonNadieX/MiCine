package com.donnadiex.enlaceplay

/**
 * Sagas: junta las películas de una misma saga (Madagascar 1, 2 y 3…) en orden.
 *  - Con clave de TMDB usa la colección oficial ("Madagascar - Colección").
 *  - Sin clave, las reconoce por el nombre: "Madagascar", "Madagascar 2: Escape a África", "Madagascar 3"…
 */
object Sagas {
    class Saga(val key: String, val name: String, val titles: List<Title>) {
        val poster: String? get() = titles.firstOrNull { !it.poster.isNullOrBlank() }?.poster
        val years: String get() {
            val y = titles.map { it.year }.filter { it > 0 }
            return if (y.isEmpty()) "" else if (y.min() == y.max()) "${y.min()}" else "${y.min()}–${y.max()}"
        }
    }

    private val roman = "ii|iii|iv|v|vi|vii|viii|ix|x"

    /** "Madagascar 2: Escape a África (2008)" → "madagascar" */
    fun baseKey(name: String): String {
        var n = name.lowercase()
        n = n.replace(Regex("\\(\\d{4}\\)"), " ")
        n = n.substringBefore(":").substringBefore(" - ").substringBefore("–")
        n = n.replace(Regex("\\b(parte|part|cap[ií]tulo|chapter|vol\\.?|volumen|episodio)\\s*\\w+\\s*$"), " ")
        n = n.replace(Regex("\\s+(\\d{1,2}|$roman)\\s*$"), " ")
        return NameParser.key(n.trim())
    }

    /** "Madagascar - Colección" → "Madagascar" */
    fun cleanName(s: String): String = s
        .replace(Regex("(?i)\\s*[-–:]?\\s*(colecci[oó]n|collection|saga|trilog[ií]a|trilogy)\\s*$"), "")
        .replace(Regex("(?i)^\\s*(colecci[oó]n|saga|trilog[ií]a)\\s+(de\\s+)?"), "")
        .trim()

    private fun prettyBase(t: Title): String {
        var n = t.name.replace(Regex("\\(\\d{4}\\)"), "").substringBefore(":").substringBefore(" - ").trim()
        n = n.replace(Regex("(?i)\\s+(\\d{1,2}|$roman)\\s*$"), "").trim()
        return n.ifBlank { t.name }
    }

    @Volatile private var cache: Pair<Int, List<Saga>>? = null

    fun all(): List<Saga> {
        val movies = Catalog.titles().filter { it.kind == Kind.MOVIE }
        val stamp = movies.sumOf { (it.id.hashCode() + it.saga.hashCode() + it.name.hashCode()) * 31 } + movies.size
        cache?.let { if (it.first == stamp) return it.second }
        // Las películas con colección oficial "enseñan" su nombre a las demás de su misma base
        val official = mutableMapOf<String, String>()    // base → colección
        movies.filter { it.saga.isNotBlank() }.forEach { official[baseKey(it.name)] = NameParser.key(cleanName(it.saga)) }
        val groups = movies.groupBy { t ->
            when {
                t.saga.isNotBlank() -> "c:" + NameParser.key(cleanName(t.saga))
                else -> official[baseKey(t.name)]?.let { "c:$it" } ?: "h:" + baseKey(t.name)
            }
        }
        val out = groups.filter { (k, v) -> v.size >= 2 && k.length > 4 }.map { (k, v) ->
            val sorted = v.sortedWith(compareBy({ if (it.year > 0) it.year else 9999 }, { it.name.lowercase() }))
            val name = sorted.firstOrNull { it.saga.isNotBlank() }?.let { cleanName(it.saga) } ?: prettyBase(sorted.first())
            Saga(k, name, sorted)
        }.sortedBy { it.name.lowercase() }
        cache = stamp to out
        return out
    }

    fun byKey(key: String): Saga? = all().firstOrNull { it.key == key }
    fun of(t: Title): Saga? = if (t.kind != Kind.MOVIE) null else all().firstOrNull { s -> s.titles.any { it.id == t.id } }

    /** Tarjeta "falsa" para mostrar la saga con el mismo diseño de póster. */
    fun asCard(s: Saga) = Title(id = "saga:" + s.key, kind = Kind.MOVIE, name = "${s.name} (${s.titles.size})", poster = s.poster)
}
