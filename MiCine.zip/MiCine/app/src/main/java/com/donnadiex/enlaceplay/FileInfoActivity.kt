package com.donnadiex.enlaceplay

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Toast
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Metadata detallada + carátula de un archivo (episodio o película). */
class FileInfoActivity : BaseActivity() {

    private lateinit var f: MediaFile
    private lateinit var body: LinearLayout
    private var job: Job? = null
    private var analyzing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val found = intent.getStringExtra("file")?.let { Catalog.file(it) }
        if (found == null) { finish(); return }
        f = found
        val root = vbox().apply { setBackgroundColor(Col.BG) }
        val top = hbox().apply { setPadding(dp(4), dp(6), dp(8), dp(2)) }
        top.addView(iconButton(R.drawable.ic_back) { finish() })
        top.addView(txt("Información del archivo", 18f, Col.TEXT, true), lp(0, WRAP, 1f))
        root.addView(top, lp())
        val scroll = ScrollView(this)
        body = vbox().apply { val cp = columnPad(760); setPadding(cp, 0, cp, dp(32)) }
        scroll.addView(body)
        root.addView(scroll, lp(MATCH, 0, 1f))
        setContentView(root)
        render()
        if (f.info.isEmpty()) analyze()
    }

    private fun analyze() {
        if (job?.isActive == true) return
        analyzing = true
        render()
        job = scope.launch {
            val r = Analyzer.analyze(applicationContext, f.id, f.url)
            Catalog.file(f.id)?.let { cur ->
                if (r.coverPath != null) cur.coverPath = r.coverPath
                if (r.durationMs > 0) cur.durationMs = r.durationMs
                cur.info = r.sections
                if (cur.fileName.isBlank() || cur.fileName.startsWith("http")) cur.fileName = r.title
                f = cur
            }
            Catalog.save()
            analyzing = false
            render()
        }
    }

    private fun render() {
        body.removeAllViews()
        val t = Catalog.title(f.titleId)

        val frame = FrameLayout(this)
        val img = ImageView(this)
        frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        // Carátula del propio archivo primero; si no hay, la imagen de TMDB.
        if (f.coverPath != null) img.show(null, f.coverPath) else img.show(f.still ?: t?.backdrop ?: t?.poster)
        frame.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            background = rounded(Color.parseColor("#99000000"), dpf(30f), dp(2), Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER))
        frame.setOnClickListener { Nav.play(this, f.id) }
        body.addView(frame, lp(MATCH, minOf((screenW * 9f / 16f).toInt(), (screenH * 0.5f).toInt())))

        val card = vbox(16)
        val heading = buildString {
            append(t?.name ?: "")
            if (f.episode > 0) append(" · ${f.code}")
        }
        card.addView(txt(heading, 20f, Col.TEXT, true))
        if (f.epName.isNotBlank()) card.addView(txt(f.epName, 15f, Col.MUTED).apply { setPadding(0, dp(2), 0, 0) })
        card.addView(txt(f.fileName, 12f, Col.DIM).apply { setPadding(0, dp(6), 0, 0); setTextIsSelectable(true) })
        card.addView(txt("Origen: " + Local.whereLabel(f.url), 12f, Col.RED).apply { setPadding(0, dp(4), 0, 0) })

        val actions = hbox().apply { setPadding(0, dp(14), 0, 0) }
        actions.addView(pill("Reproducir", true, R.drawable.ic_play) { Nav.play(this, f.id) }, lp(0, WRAP, 1f))
        actions.addView(pill("Otra app", false) {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(f.url), "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            runCatching { startActivity(Intent.createChooser(i, "Abrir con…")) }
                .onFailure { toast("No hay otra app de video instalada") }
        }, lp(0, WRAP, 1f).apply { leftMargin = dp(10) })
        card.addView(actions, lp())

        val small = hbox().apply { setPadding(0, dp(10), 0, 0) }
        small.addView(link(if (Local.isLocal(f.url)) "Copiar ruta" else "Copiar link") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", f.url))
            toast("Link copiado")
        }, lp(0, WRAP, 1f))
        small.addView(link("Re-analizar") { analyze() }, lp(0, WRAP, 1f))
        small.addView(link(if (f.finished) "Marcar no visto" else "Marcar visto") {
            f.finished = !f.finished
            if (f.finished) { f.positionMs = 0; f.watchedAt = System.currentTimeMillis() }
            Catalog.save(); render()
        }, lp(0, WRAP, 1f))
        small.addView(link("Quitar") {
            AlertDialog.Builder(this, dialogTheme())
                .setTitle("¿Quitar este archivo?")
                .setMessage("Solo se quita el link de la app.")
                .setPositiveButton("Quitar") { _, _ -> Catalog.deleteFile(f.id); finish() }
                .setNegativeButton("Cancelar", null).show()
        }, lp(0, WRAP, 1f))
        card.addView(small, lp())

        if (analyzing) {
            val row = hbox().apply { setPadding(0, dp(18), 0, 0) }
            row.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(24), dp(24)))
            row.addView(txt("Leyendo el archivo… (puede tardar en archivos grandes)", 13f, Col.MUTED).apply { setPadding(dp(10), 0, 0, 0) })
            card.addView(row)
        }
        body.addView(card)

        val wrap = vbox().apply { setPadding(dp(16), 0, dp(16), 0) }
        f.info.forEach { s -> wrap.addView(sectionView(s)) }
        body.addView(wrap)
    }

    private fun link(s: String, onClick: () -> Unit) = txt(s, 13f, Col.RED, true).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, dp(8))
        setOnClickListener { onClick() }
    }

    private fun sectionView(s: InfoSection): View {
        val wrap = vbox()
        wrap.addView(txt(s.title.uppercase(), 12f, Col.RED, true).apply {
            letterSpacing = 0.08f
            setPadding(dp(4), dp(18), 0, dp(6))
        })
        val card = vbox().apply {
            background = rounded(Col.CARD, r(1.5f))
            setPadding(dp(14), dp(4), dp(14), dp(4))
        }
        s.rows.forEachIndexed { i, (k, v) ->
            val row = hbox().apply { gravity = Gravity.TOP; setPadding(0, dp(9), 0, dp(9)) }
            row.addView(txt(k, 13f, Col.MUTED), lp(0, WRAP, 0.42f))
            row.addView(txt(v, 13f, Col.TEXT).apply { setTextIsSelectable(true) }, lp(0, WRAP, 0.58f))
            card.addView(row)
            if (i < s.rows.size - 1) card.addView(View(this).apply { setBackgroundColor(Col.LINE) }, lp(MATCH, 1))
        }
        wrap.addView(card)
        return wrap
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
