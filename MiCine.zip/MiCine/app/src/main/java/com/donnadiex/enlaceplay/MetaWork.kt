package com.donnadiex.enlaceplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Búsqueda de portadas y datos que NO se cancela al salir de la pantalla:
 *  - La lista de pendientes se guarda; si cierras la app, sigue donde se quedó al volver a abrirla.
 *  - Mientras trabaja muestra una notificación con el avance.
 */
object MetaWork {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    @Volatile var done = 0
    @Volatile var total = 0
    @Volatile var current = ""

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("meta_cola", Context.MODE_PRIVATE)

    fun pending(ctx: Context): Set<String> = prefs(ctx).getStringSet("ids", emptySet()) ?: emptySet()

    private fun setPending(ctx: Context, ids: Set<String>) =
        prefs(ctx).edit().putStringSet("ids", HashSet(ids)).apply()

    fun enqueue(ctx: Context, ids: Collection<String>) {
        if (ids.isEmpty()) return
        val all = pending(ctx) + ids
        setPending(ctx, all)
        if (job?.isActive == true) total = done + all.size
    }

    val running: Boolean get() = job?.isActive == true

    /** Arranca (o devuelve el trabajo que ya va corriendo). */
    fun start(context: Context): Job {
        job?.let { if (it.isActive) return it }
        val ctx = context.applicationContext
        done = 0
        total = pending(ctx).size
        val j = scope.launch {
            if (total == 0) return@launch
            MetaService.start(ctx)
            try {
                while (true) {
                    val id = pending(ctx).firstOrNull() ?: break
                    val t = Catalog.title(id)
                    if (t != null) {
                        current = t.name
                        MetaService.update(ctx, "${done + 1} de $total · ${t.name}")
                        withContext(Dispatchers.IO) {
                            runCatching { if (t.ext.isBlank()) Meta.autoMatch(ctx, t) else Meta.refresh(ctx, t) }
                        }
                    }
                    setPending(ctx, pending(ctx) - id)
                    done++
                    if (done % 10 == 0) Catalog.save()
                }
                Meta.mergeDuplicates()
                Catalog.save()
            } finally {
                current = ""
                MetaService.stop(ctx)
            }
        }
        job = j
        return j
    }

    /** Al abrir la app: si quedó trabajo pendiente, lo retoma. */
    fun resume(ctx: Context) {
        if (pending(ctx).isNotEmpty()) start(ctx)
    }
}

/** Mantiene viva la búsqueda con la app en segundo plano y muestra el avance. */
class MetaService : Service() {

    companion object {
        private const val CH = "busqueda"
        private const val ID = 4107

        fun start(ctx: Context) {
            runCatching {
                val i = Intent(ctx, MetaService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            }
        }

        fun stop(ctx: Context) {
            runCatching { ctx.stopService(Intent(ctx, MetaService::class.java)) }
        }

        fun update(ctx: Context, text: String) {
            runCatching {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(ID, build(ctx, text))
            }
        }

        private fun build(ctx: Context, text: String): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val b = if (Build.VERSION.SDK_INT >= 26) {
                if (nm.getNotificationChannel(CH) == null)
                    nm.createNotificationChannel(NotificationChannel(CH, "Búsqueda de portadas", NotificationManager.IMPORTANCE_LOW))
                Notification.Builder(ctx, CH)
            } else @Suppress("DEPRECATION") Notification.Builder(ctx)
            val open = PendingIntent.getActivity(ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE)
            return b.setSmallIcon(R.drawable.ic_refresh)
                .setContentTitle("Mi Cine: buscando portadas y datos")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .build()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = build(this, "Preparando…")
        runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(ID, n)
        }
        // Si Android cerró la app y la volvió a abrir solo para este servicio, retoma la lista.
        Catalog.init(applicationContext)
        if (!MetaWork.running) {
            if (MetaWork.pending(this).isEmpty()) stopSelf() else MetaWork.start(this)
        }
        return START_NOT_STICKY
    }
}
