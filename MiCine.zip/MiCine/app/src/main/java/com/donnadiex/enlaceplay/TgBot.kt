package com.donnadiex.enlaceplay

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * "Mi bot de Telegram": sigue la lista de tu canal que arma Mi Cine Bot.
 * Lo nuevo del canal se agrega solo, con portada y datos (igual que al pegar links).
 */
object TgBot {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun url(ctx: Context): String? = prefs(ctx).getString("bot_lista", null)?.takeIf { it.isNotBlank() }
    fun setUrl(ctx: Context, u: String?) = prefs(ctx).edit().putString("bot_lista", u?.trim()).apply()
    fun lastSync(ctx: Context) = prefs(ctx).getLong("bot_sync", 0)
    fun lastCount(ctx: Context) = prefs(ctx).getInt("bot_total", 0)

    /** ".../v/123/Nombre.mp4?k=…" → "123" (el número del mensaje en tu canal). */
    private fun msgId(url: String): String? = Regex("/v/(\\d+)/").find(url)?.groupValues?.get(1)

    fun isValid(u: String) = u.startsWith("http") && u.contains("/lista") && u.contains("k=")

    /** Baja la lista del bot (el servidor puede tardar unos segundos si estaba dormido). */
    private fun download(u: String): JSONObject {
        var last: Exception? = null
        repeat(2) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 20_000; c.readTimeout = 60_000
                c.setRequestProperty("User-Agent", USER_AGENT)
                try {
                    if (c.responseCode == 403) error("La clave del link no es correcta. Pídele al bot /app otra vez.")
                    if (c.responseCode !in 200..299) error("El bot respondió ${c.responseCode}")
                    return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                } finally { c.disconnect() }
            } catch (e: IllegalStateException) { throw e } catch (e: Exception) { last = e }
        }
        throw last ?: IllegalStateException("No se pudo conectar con el bot")
    }

    /** Agrega lo nuevo del canal. Devuelve cuántos videos nuevos hubo.
     *  Todo el trabajo pesado va en segundo plano (con 1000+ videos la pantalla se congelaba);
     *  solo los avisos de avance vuelven a la pantalla. */
    suspend fun sync(ctx: Context, onProgress: suspend (Int, Int, String) -> Unit = { _, _, _ -> }): Int {
        val u = url(ctx) ?: return 0
        val ui: suspend (Int, Int, String) -> Unit = { d, t, m ->
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { runCatching { onProgress(d, t, m) } }
        }
        val o = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { download(u) }
        if (o.optInt("micine_bot") != 1) error("Ese link no es de Mi Cine Bot")
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { apply(ctx, u, o, ui) }
    }

    private suspend fun apply(ctx: Context, u: String, o: JSONObject, onProgress: suspend (Int, Int, String) -> Unit): Int {
        val arr = o.optJSONArray("items") ?: org.json.JSONArray()
        val items = (0 until arr.length()).map { arr.getJSONObject(it) }
        val host = runCatching { java.net.URI(u).host }.getOrNull() ?: ""
        onProgress(0, items.size, "Revisando ${items.size} videos del canal…")

        // Si un video ya estaba con otro nombre (ej. el nombre del archivo), se reemplaza por el nuevo
        // conservando dónde te quedaste. (Índice por número de mensaje: rápido aunque haya miles.)
        val kept = mutableMapOf<String, MediaFile>()   // url nueva → archivo viejo (para su progreso)
        val mineById = Catalog.allFiles()
            .filter { runCatching { java.net.URI(it.url).host }.getOrNull() == host }
            .groupBy { msgId(it.url) }
        var removed = false
        items.forEach { it0 ->
            val url = it0.optString("url")
            val id = msgId(url) ?: return@forEach
            mineById[id]?.filter { it.url != url }?.forEach { old ->
                kept[url] = old
                Catalog.deleteFile(old.id)
                removed = true
            }
        }
        if (removed) Catalog.dropEmptyTitles()

        val lines = items.filter { Catalog.fileByUrl(it.optString("url")) == null }
            .map { ImportLine(it.optString("url"), it.optString("name")) }
        prefs(ctx).edit().putLong("bot_sync", System.currentTimeMillis()).putInt("bot_total", arr.length()).apply()
        if (lines.isEmpty()) { Catalog.save(); return 0 }
        val added = Importer.runItems(ctx, lines, onProgress).added
        kept.forEach { (url, old) ->
            Catalog.fileByUrl(url)?.let { nf ->
                nf.positionMs = old.positionMs; nf.durationMs = old.durationMs
                nf.finished = old.finished; nf.watchedAt = old.watchedAt
            }
        }
        Catalog.save()
        return added - kept.size.coerceAtMost(added)
    }

    /** Al abrir la app, como mucho cada 20 minutos. */
    suspend fun syncIfDue(ctx: Context): Int {
        if (url(ctx) == null || System.currentTimeMillis() - lastSync(ctx) < 20 * 60_000L) return 0
        return runCatching { sync(ctx) }.getOrDefault(0)
    }
}
