package com.donnadiex.enlaceplay

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy

const val USER_AGENT =
    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36 MiCine/4.0"

/** Cuánto video se descarga por adelantado (como el "cache" de Kodi). */
enum class BufferMode(val label: String, val desc: String, val minMs: Int, val maxMs: Int, val startMs: Int, val rebufferMs: Int) {
    NORMAL("Normal", "Arranca rápido. Para buen internet o archivos locales.", 15_000, 50_000, 2_500, 5_000),
    GRANDE("Grande", "Guarda ~2 minutos por adelantado. Menos pausas con links lentos.", 30_000, 120_000, 3_000, 8_000),
    MAXIMO("Máximo", "Guarda ~5 minutos. Para internet muy inestable (usa más RAM).", 60_000, 300_000, 4_000, 12_000)
}

/** Con qué se reproducen los videos. */
enum class Engine(val label: String, val desc: String) {
    VLC("Integrado (motor VLC)", "Reproductor de Mi Cine con el motor de VLC: lee todos los formatos y audios (AC3, DTS…)."),
    VLC_APP("App VLC", "Abre la app VLC instalada; Mi Cine guarda dónde te quedaste.")
}

object Players {

    const val VLC_PACKAGE = "org.videolan.vlc"

    fun engine(ctx: Context): Engine = runCatching {
        Engine.valueOf(ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("motor", Engine.VLC.name)!!)
    }.getOrDefault(Engine.VLC)

    fun setEngine(ctx: Context, e: Engine) =
        ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putString("motor", e.name).apply()

    fun vlcAppInstalled(ctx: Context) = ctx.packageManager.getLaunchIntentForPackage(VLC_PACKAGE) != null

    /** Milisegundos de video que VLC guarda por adelantado en links de internet. */
    fun networkCachingMs(ctx: Context) = when (bufferMode(ctx)) {
        BufferMode.NORMAL -> 1500
        BufferMode.GRANDE -> 5000
        BufferMode.MAXIMO -> 12000
    }

    fun bufferMode(ctx: Context): BufferMode {
        val n = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("bufer", BufferMode.GRANDE.name)
        return BufferMode.values().firstOrNull { it.name == n } ?: BufferMode.GRANDE
    }

    fun setBufferMode(ctx: Context, m: BufferMode) =
        ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putString("bufer", m.name).apply()

    /**
     * ExoPlayer preparado para links lentos o que se cortan:
     *  - sigue redirecciones (http↔https)
     *  - búfer configurable
     *  - reintenta varias veces antes de mostrar error
     */
    @OptIn(UnstableApi::class)
    fun build(ctx: Context): ExoPlayer {
        val m = bufferMode(ctx)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)
        val dataSource = DefaultDataSource.Factory(ctx, http)
        val sources = DefaultMediaSourceFactory(dataSource)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(6))
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(m.minMs, m.maxMs, m.startMs, m.rebufferMs)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        return ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(sources)
            .setLoadControl(load)
            .build()
    }
}
