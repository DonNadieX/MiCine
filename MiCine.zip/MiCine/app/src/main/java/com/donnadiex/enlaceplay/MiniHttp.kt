package com.donnadiex.enlaceplay

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.util.concurrent.Executors

/**
 * Servidor web muy pequeño para la red local (sin internet):
 *  - Varios clientes a la vez (VLC abre 2-3 conexiones por video).
 *  - Soporta "Range" para poder adelantar y regresar dentro del video.
 */
class MiniHttp(private val port: Int, private val handler: (Request, Response) -> Unit) {

    class Request(
        val method: String,
        val path: String,
        val query: Map<String, String>,
        val headers: Map<String, String>,
        val body: ByteArray,
        /** IP del celular por la que llegó la petición (para armar links que el otro aparato pueda abrir). */
        val localIp: String,
        val remoteIp: String
    ) {
        fun header(name: String) = headers[name.lowercase()]
        val bodyText: String get() = String(body, Charsets.UTF_8)
    }

    class Response(private val out: OutputStream, private val isHead: Boolean) {
        var sent = false
            private set

        fun send(code: Int, type: String, data: ByteArray, extra: Map<String, String> = emptyMap()) {
            if (sent) return
            sent = true
            val h = StringBuilder("HTTP/1.1 $code ${reason(code)}\r\n")
            h.append("Content-Type: $type\r\nContent-Length: ${data.size}\r\nConnection: close\r\n")
            h.append("Access-Control-Allow-Origin: *\r\n")
            extra.forEach { (k, v) -> h.append("$k: $v\r\n") }
            h.append("\r\n")
            out.write(h.toString().toByteArray())
            if (!isHead) out.write(data)
            out.flush()
        }

        fun text(code: Int, s: String, type: String = "text/plain; charset=utf-8") = send(code, type, s.toByteArray())
        fun json(s: String) = send(200, "application/json; charset=utf-8", s.toByteArray())
        fun xml(s: String, extra: Map<String, String> = emptyMap()) = send(200, "text/xml; charset=\"utf-8\"", s.toByteArray(), extra)

        /** Manda un archivo grande respetando "Range: bytes=inicio-fin". */
        fun stream(req: Request, length: Long, type: String, open: (offset: Long) -> InputStream, extra: Map<String, String> = emptyMap()) {
            if (sent) return
            sent = true
            val range = req.header("range")
            var start = 0L
            var end = length - 1
            var partial = false
            if (range != null && range.startsWith("bytes=") && length > 0) {
                val r = range.removePrefix("bytes=").substringBefore(',').trim()
                val a = r.substringBefore('-').trim()
                val b = r.substringAfter('-', "").trim()
                if (a.isEmpty() && b.isNotEmpty()) { start = (length - (b.toLongOrNull() ?: 0)).coerceAtLeast(0) }
                else {
                    start = a.toLongOrNull() ?: 0
                    if (b.isNotEmpty()) end = (b.toLongOrNull() ?: end).coerceAtMost(length - 1)
                }
                partial = true
                if (start >= length) {
                    out.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$length\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    out.flush(); return
                }
            }
            val count = if (length > 0) end - start + 1 else -1
            val h = StringBuilder(if (partial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
            h.append("Content-Type: $type\r\nAccept-Ranges: bytes\r\nConnection: close\r\n")
            if (count >= 0) h.append("Content-Length: $count\r\n")
            if (partial) h.append("Content-Range: bytes $start-$end/$length\r\n")
            extra.forEach { (k, v) -> h.append("$k: $v\r\n") }
            h.append("\r\n")
            out.write(h.toString().toByteArray())
            if (isHead) { out.flush(); return }
            open(start).use { inp ->
                val buf = ByteArray(256 * 1024)
                var left = if (count >= 0) count else Long.MAX_VALUE
                while (left > 0) {
                    val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) break
                    out.write(buf, 0, n)
                    left -= n
                }
            }
            out.flush()
        }

        companion object {
            fun reason(code: Int) = when (code) {
                200 -> "OK"; 204 -> "No Content"; 206 -> "Partial Content"; 400 -> "Bad Request"
                403 -> "Forbidden"; 404 -> "Not Found"; 500 -> "Internal Server Error"; else -> "OK"
            }
        }
    }

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    val isRunning get() = running

    fun start() {
        if (running) return
        running = true
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        s.soTimeout = 1000
        server = s
        Thread({
            while (running) {
                val sock = try { s.accept() } catch (_: SocketTimeoutException) { continue } catch (_: Exception) { break }
                runCatching { pool.execute { serve(sock) } }
            }
            runCatching { s.close() }
        }, "MiCine-servidor").start()
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        runCatching { pool.shutdownNow() }
    }

    private fun serve(sock: Socket) = runCatching {
        sock.use { c ->
            c.soTimeout = 60_000
            c.tcpNoDelay = true
            val input = BufferedInputStream(c.getInputStream())
            val head = ByteArrayOutputStream()
            var last4 = 0
            while (true) {
                val b = input.read()
                if (b < 0) break
                head.write(b)
                last4 = (last4 shl 8) or b
                if (last4 == 0x0D0A0D0A || head.size() > 32_000) break
            }
            val lines = head.toString("UTF-8").split("\r\n")
            val first = lines.firstOrNull()?.split(" ") ?: return@use
            if (first.size < 2) return@use
            val method = first[0].uppercase()
            val target = first[1]
            val headers = lines.drop(1).filter { it.contains(':') }
                .associate { it.substringBefore(':').trim().lowercase() to it.substringAfter(':').trim() }
            val len = headers["content-length"]?.toIntOrNull() ?: 0
            val body = ByteArray(len.coerceIn(0, 5_000_000))
            var read = 0
            while (read < body.size) {
                val n = input.read(body, read, body.size - read)
                if (n < 0) break
                read += n
            }
            val path = URLDecoder.decode(target.substringBefore('?'), "UTF-8")
            val query = target.substringAfter('?', "").split('&').filter { it.contains('=') }.associate {
                URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8")
            }
            val local = (c.localAddress as? InetAddress)?.hostAddress?.substringBefore('%') ?: (Link.localIp() ?: "")
            val req = Request(method, path, query, headers, body.copyOf(read), local, c.inetAddress?.hostAddress ?: "")
            val res = Response(c.getOutputStream(), method == "HEAD")
            try { handler(req, res) } catch (e: Exception) { if (!res.sent) res.text(500, e.message ?: "Error") }
            if (!res.sent) res.text(404, "No encontrado")
        }
    }
}
