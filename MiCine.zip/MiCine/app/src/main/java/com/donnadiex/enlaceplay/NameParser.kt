package com.donnadiex.enlaceplay

import java.text.Normalizer
import java.util.Locale

/**
 * Lee el nombre de un archivo (o el texto que escribas antes del link) y adivina
 * si es serie o película, su nombre, año, temporada, episodio y calidad.
 *
 *   "The.Office.S02E05.1080p.WEB-DL.mkv"      -> Serie "The Office" T2 E5 · 1080p
 *   "Dark 1x03 Latino.mp4"                    -> Serie "Dark" T1 E3
 *   "Breaking Bad Temporada 3 Capitulo 7"     -> Serie "Breaking Bad" T3 E7
 *   "Inception (2010) 720p.mp4"               -> Película "Inception" (2010) · 720p
 */
data class Parsed(
    val name: String,
    val year: Int,
    val season: Int,
    val episode: Int,
    val quality: String,
    val isSeries: Boolean
)

object NameParser {

    private val EXT = Regex("\\.(mkv|mp4|m4v|avi|webm|mov|ts|flv|wmv|3gp|m3u8)$", RegexOption.IGNORE_CASE)

    private val EP_PATTERNS = listOf(
        // S01E02, S1E2, S01 E02, S01.E02, s01e02e03
        Regex("\\bS(\\d{1,2})\\s*[ ._-]?\\s*E[Pp]?(\\d{1,3})", RegexOption.IGNORE_CASE),
        // 1x02, 01x02
        Regex("\\b(\\d{1,2})x(\\d{2,3})\\b", RegexOption.IGNORE_CASE),
        // Temporada 1 Capitulo 2 / Temp 1 Cap 2 / T1 E2 / T01 C02 / Season 1 Episode 2
        Regex(
            "\\b(?:temporada|temp|season|t)\\s*[ ._-]?\\s*(\\d{1,2})\\s*[ ._,-]*\\s*" +
                "(?:cap[ií]tulo|capitulo|cap|episodio|episode|ep|e|c)\\s*[ ._-]?\\s*(\\d{1,3})\\b",
            RegexOption.IGNORE_CASE
        )
    )

    // Solo episodio: "Capitulo 5", "Episodio 12", "Ep 3", "E05"
    private val EP_ONLY = Regex(
        "\\b(?:cap[ií]tulo|capitulo|cap|episodio|episode|ep)\\s*[ ._-]?\\s*(\\d{1,3})\\b",
        RegexOption.IGNORE_CASE
    )

    private val YEAR = Regex("(?<!\\d)(19[2-9]\\d|20[0-4]\\d)(?!\\d)")
    private val QUALITY = Regex("\\b(2160p|4k|uhd|1440p|1080p|720p|576p|480p|360p)\\b", RegexOption.IGNORE_CASE)

    // Palabras técnicas: el nombre termina antes de la primera que aparezca.
    private val JUNK = Regex(
        "\\b(2160p|4k|uhd|1440p|1080p|720p|576p|480p|360p|web[ -]?dl|webrip|web|bluray|blu[ -]?ray|brrip|bdrip|hdrip|" +
            "dvdrip|hdtv|hdcam|cam|x264|x265|h264|h265|hevc|avc|aac|ac3|dts|ddp?5 ?1|10bit|hdr|remux|" +
            "latino|castellano|espa[nñ]ol|spanish|dual|multi|subs?|subtitulado|vose|lat|esp|eng|" +
            "proper|repack|extended|unrated|imax|complet[ao])\\b",
        RegexOption.IGNORE_CASE
    )

    fun parse(raw: String): Parsed {
        var s = raw.trim()
        s = EXT.replace(s, "")
        // Quitar etiquetas de grupo al inicio: "[Grupo] Nombre"
        s = s.replace(Regex("^\\s*\\[[^\\]]*\\]\\s*"), "")
        s = s.replace('_', ' ').replace('.', ' ').replace(Regex("\\s+"), " ").trim()

        val quality = QUALITY.find(s)?.value?.lowercase()?.let {
            when (it) { "4k", "uhd", "2160p" -> "4K"; else -> it }
        } ?: ""

        var season = 0
        var episode = 0
        var cut = s.length

        for (p in EP_PATTERNS) {
            val m = p.find(s) ?: continue
            season = m.groupValues[1].toInt()
            episode = m.groupValues[2].toInt()
            cut = m.range.first
            break
        }
        if (episode == 0) {
            EP_ONLY.find(s)?.let { m ->
                season = 1
                episode = m.groupValues[1].toInt()
                cut = m.range.first
            }
        }
        val isSeries = episode > 0

        val years = YEAR.findAll(s).toList()
        // Año: el primero que no sea el inicio del nombre (ej. "2012" la película).
        val yearMatch = years.firstOrNull { it.range.first > 0 } ?: years.firstOrNull()
        val year = yearMatch?.value?.toInt() ?: 0
        if (!isSeries && yearMatch != null && yearMatch.range.first > 0) cut = minOf(cut, yearMatch.range.first)
        if (isSeries && yearMatch != null && yearMatch.range.first in 1 until cut) cut = yearMatch.range.first

        JUNK.find(s)?.let { if (it.range.first in 1 until cut) cut = it.range.first }

        var name = s.substring(0, cut)
        name = name.replace(Regex("[\\(\\[\\{][^\\)\\]\\}]*$"), "")   // paréntesis sin cerrar al final
            .replace(Regex("[\\(\\)\\[\\]\\{\\}]"), " ")
            .replace(Regex("[\\s\\-–—:|,]+$"), "")
            .replace(Regex("^[\\s\\-–—:|,]+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (name.isBlank()) name = s.substring(0, minOf(s.length, 40)).trim().ifBlank { "Sin nombre" }
        name = prettify(name)

        return Parsed(name, year, season, episode, quality, isSeries)
    }

    /** Si viene todo en minúsculas o MAYÚSCULAS lo pone tipo título. */
    private fun prettify(n: String): String {
        val letters = n.filter { it.isLetter() }
        if (letters.isEmpty()) return n
        val allLower = letters.all { it.isLowerCase() }
        val allUpper = letters.all { it.isUpperCase() } && letters.length > 4
        if (!allLower && !allUpper) return n
        return n.lowercase().split(' ').joinToString(" ") { w ->
            w.replaceFirstChar { it.titlecase(Locale.ROOT) }
        }
    }

    /** Clave para agrupar: sin acentos, minúsculas, sin signos. */
    fun key(name: String): String {
        val noAccents = Normalizer.normalize(name, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return noAccents.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
    }
}
