package com.donnadiex.enlaceplay

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : BaseActivity() {

    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var overlay: LinearLayout
    private var queue: List<MediaFile> = emptyList()
    private var startIndex = 0
    private var lastIndex = -1
    private val handler = Handler(Looper.getMainLooper())
    private val saver = object : Runnable {
        override fun run() {
            saveCurrent(false)
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val start = intent.getStringExtra("file")?.let { Catalog.file(it) }
        if (start == null) { finish(); return }
        val all = Catalog.filesOf(start.titleId)
        val title = Catalog.title(start.titleId)
        // Series: la lista sigue con los episodios siguientes. Películas: solo ese archivo.
        queue = if (title?.kind == Kind.SERIES) all else listOf(start)
        startIndex = queue.indexOfFirst { it.id == start.id }.coerceAtLeast(0)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        view = PlayerView(this).apply {
            setShowSubtitleButton(true)
            setShowNextButton(queue.size > 1)
            setShowPreviousButton(queue.size > 1)
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            setKeepContentOnPlayerReset(true)
        }
        root.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))

        overlay = vbox().apply {
            setPadding(dp(56), dp(16), dp(56), dp(16))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#AA000000"), Color.TRANSPARENT)
            )
        }
        titleView = txt("", 17f, Col.TEXT, true, 1)
        subView = txt("", 13f, Col.MUTED, false, 1)
        overlay.addView(titleView); overlay.addView(subView)
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        root.addView(iconButton(R.drawable.ic_back) { finish() }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.START).apply {
            setMargins(dp(4), dp(8), 0, 0)
        })
        val back = root.getChildAt(root.childCount - 1)
        view.setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
            override fun onVisibilityChanged(visibility: Int) {
                overlay.visibility = visibility
                back.visibility = visibility
                if (visibility != View.VISIBLE) hideBars()
            }
        })
        setContentView(root)
        hideBars()
    }

    override fun onStart() {
        super.onStart()
        if (queue.isEmpty()) return
        val p = Players.build(this)
        player = p
        view.player = p
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val f = queue.getOrNull(p.currentMediaItemIndex)
                val msg = when {
                    f != null && Local.isLocal(f.url) && !Local.isFileAvailable(this@PlayerActivity, f.url) ->
                        "Este archivo está en una memoria que no está conectada (o se movió de carpeta). Conéctala y vuelve a intentar."
                    Local.isLocal(f?.url ?: "") ->
                        "Tu celular no puede leer este formato (${error.errorCodeName}). Prueba \"Otra app\" en la info del archivo."
                    else ->
                        "No se pudo reproducir (${error.errorCodeName}). Revisa que el link siga activo o usa \"Otra app\" en la info del archivo."
                }
                Toast.makeText(this@PlayerActivity, msg, Toast.LENGTH_LONG).show()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // El anterior terminó (pasó solo al siguiente) → marcarlo como visto.
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && lastIndex >= 0) {
                    queue.getOrNull(lastIndex)?.let { markFinished(it) }
                }
                lastIndex = p.currentMediaItemIndex
                updateTitle()
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) queue.getOrNull(p.currentMediaItemIndex)?.let { markFinished(it) }
            }
        })
        val items = queue.map { f ->
            MediaItem.Builder()
                .setUri(f.url)
                .setMediaId(f.id)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(f.epName.ifBlank { f.fileName }).build())
                .build()
        }
        val current = Catalog.file(queue[startIndex].id) ?: queue[startIndex]
        val resume = if (!current.finished && current.positionMs > 5_000) current.positionMs else 0L
        p.setMediaItems(items, startIndex, resume)
        lastIndex = startIndex
        p.prepare()
        p.playWhenReady = true
        updateTitle()
        handler.postDelayed(saver, 10_000)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saver)
        saveCurrent(true)
        player?.release()
        player = null
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun updateTitle() {
        val p = player ?: return
        val f = queue.getOrNull(p.currentMediaItemIndex) ?: return
        val t = Catalog.title(f.titleId)
        titleView.text = t?.name ?: f.fileName
        subView.text = if (f.episode > 0) "${f.code}  ${f.epName.ifBlank { "Episodio ${f.episode}" }}" else f.quality.uppercase()
    }

    private fun saveCurrent(persist: Boolean) {
        val p = player ?: return
        val f = queue.getOrNull(p.currentMediaItemIndex)?.let { Catalog.file(it.id) } ?: return
        val dur = p.duration
        if (dur != C.TIME_UNSET && dur > 0) f.durationMs = dur
        val pos = p.currentPosition
        if (pos > 0) {
            f.positionMs = pos
            f.watchedAt = System.currentTimeMillis()
            // Si ya viste más del 93 % (créditos), cuenta como visto.
            f.finished = f.durationMs > 0 && pos > f.durationMs * 0.93
        }
        if (persist) Catalog.save() else Thread { Catalog.save() }.start()
    }

    private fun markFinished(file: MediaFile) {
        val f = Catalog.file(file.id) ?: return
        f.finished = true
        f.positionMs = 0
        f.watchedAt = System.currentTimeMillis()
        Thread { Catalog.save() }.start()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
