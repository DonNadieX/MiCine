package com.donnadiex.enlaceplay

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Busca TODOS los videos del aparato y de memorias USB/SD conectadas, sin elegir carpetas.
 * Ideal para proyectores y TV (donde el selector de carpetas a veces no existe).
 * Usa la carpeta de cada video para acomodar series y temporadas, igual que "Elegir carpeta".
 */
object MediaScan {

    /** Carpetas que no son películas ni series (cámara, WhatsApp, grabaciones…). */
    private val SKIP = listOf("dcim", "camera", "screenshots", "screenrecord", "whatsapp", "recordings",
        "pictures", "snapchat", "instagram", "tiktok", "android/data", "android/media", "notifications", "ringtones")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    fun autoEnabled(ctx: Context) = prefs(ctx).getBoolean("media_auto", false)
    fun setAuto(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("media_auto", on).apply()

    val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasPermission(ctx: Context) = ctx.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    fun requestPermission(a: Activity, code: Int) = a.requestPermissions(arrayOf(permission), code)

    fun isMediaUri(url: String) = url.startsWith("content://media/")

    /** "external_primary" = memoria interna; cualquier otro nombre = SD o USB. */
    fun volumeOf(url: String): String = Uri.parse(url).pathSegments.firstOrNull() ?: ""

    private fun volumes(ctx: Context): List<String> =
        if (Build.VERSION.SDK_INT >= 29) MediaStore.getExternalVolumeNames(ctx).toList() else listOf("external")

    /** Todos los videos encontrados, con la etiqueta que entiende el lector de nombres. */
    fun find(ctx: Context): List<ImportLine> {
        val out = mutableListOf<ImportLine>()
        for (vol in volumes(ctx)) {
            val base = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(vol) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val cols = if (Build.VERSION.SDK_INT >= 29)
                arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.RELATIVE_PATH)
            else @Suppress("DEPRECATION") arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATA)
            runCatching {
                ctx.contentResolver.query(base, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val name = c.getString(1) ?: continue
                        var path = c.getString(2) ?: ""
                        if (Build.VERSION.SDK_INT < 29) path = path.substringBeforeLast('/').substringAfter("/storage/").substringAfter('/')
                        val low = path.lowercase()
                        if (SKIP.any { low.contains(it) } || name.lowercase().contains("sample")) continue
                        val folders = path.split('/').filter { it.isNotBlank() }
                        out += ImportLine(ContentUris.withAppendedId(base, id).toString(), Local.labelFor(folders, name))
                    }
                }
            }
        }
        return out
    }

    /** Agrega los videos nuevos. Devuelve cuántos. */
    suspend fun scan(ctx: Context, onProgress: suspend (Int, Int, String) -> Unit): Int {
        if (!hasPermission(ctx)) return 0
        val found = withContext(Dispatchers.IO) { find(ctx) }
        val fresh = found.filter { Catalog.fileByUrl(it.url) == null }
        if (fresh.isEmpty()) return 0
        Importer.runItems(ctx, fresh, onProgress)
        return fresh.size
    }

    /** Ruta "Download/Serie/01x05.mp4" de un video del sistema (para reparar y quitar duplicados). */
    fun pathOf(ctx: Context, url: String): String? {
        if (!isMediaUri(url) || Build.VERSION.SDK_INT < 29) return null
        return runCatching {
            ctx.contentResolver.query(Uri.parse(url), arrayOf(MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) (c.getString(0) ?: "") + (c.getString(1) ?: "") else null }
        }.getOrNull()
    }

    /** Quita videos que ya no existen; si su memoria USB no está conectada, no toca nada. */
    fun cleanMissing(ctx: Context): Int {
        if (!hasPermission(ctx)) return 0
        val vols = volumes(ctx).toSet()
        var n = 0
        Catalog.allFiles().filter { isMediaUri(it.url) && volumeOf(it.url) in vols }.forEach { f ->
            val exists = runCatching {
                ctx.contentResolver.query(Uri.parse(f.url), arrayOf(MediaStore.Video.Media._ID), null, null, null)?.use { it.moveToFirst() } ?: false
            }.getOrDefault(true)
            if (!exists) { Catalog.deleteFile(f.id); n++ }
        }
        return n
    }
}
