package com.donnadiex.enlaceplay

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.io.File
import java.util.Locale

/** Base de todas las pantallas: tema, catálogo listo y tareas que se cancelan al salir. */
abstract class BaseActivity : Activity() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var themeId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        Themes.load(applicationContext)
        themeId = Themes.cur.id
        super.onCreate(savedInstanceState)
        Catalog.init(applicationContext)
        applyBars()
    }

    override fun onResume() {
        super.onResume()
        // Si cambiaste de tema en Ajustes, esta pantalla se redibuja con el nuevo.
        if (themeId != Themes.cur.id) recreate()
    }

    @Suppress("DEPRECATION")
    private fun applyBars() {
        window.setBackgroundDrawable(ColorDrawable(Col.BG))
        window.statusBarColor = Col.BG
        window.navigationBarColor = Col.BG
        var flags = window.decorView.systemUiVisibility
        flags = if (Themes.cur.light) flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        else flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        if (Build.VERSION.SDK_INT >= 26) {
            flags = if (Themes.cur.light) flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            else flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        window.decorView.systemUiVisibility = flags
    }

    fun dialogTheme(): Int =
        if (Themes.cur.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Dialog_Alert

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
val Context.screenW: Int get() = resources.displayMetrics.widthPixels
val Context.screenWdp: Float get() = resources.displayMetrics.widthPixels / resources.displayMetrics.density

/** Radio de esquinas del tema (multiplicado: 1 = tarjetas normales). */
fun Context.r(mult: Float = 1f): Float = dpf(Themes.cur.radius * mult)

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = radius
    if (stroke > 0) setStroke(stroke, strokeColor)
}

fun Context.txt(
    s: CharSequence,
    size: Float = 14f,
    color: Int = Col.TEXT,
    bold: Boolean = false,
    lines: Int = 0
): TextView = TextView(this).apply {
    text = s
    textSize = size
    setTextColor(color)
    typeface = if (bold) Themes.cur.titleFont else Themes.cur.font
    if (lines > 0) {
        maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
    }
}

/** Título "de tema": respeta mayúsculas y espaciado del tema activo. */
fun Context.heading(s: String, size: Float, color: Int = Col.TEXT, lines: Int = 0): TextView =
    txt(if (Themes.cur.upperTitles) s.uppercase(Locale.getDefault()) else s, size, color, true, lines).apply {
        letterSpacing = Themes.cur.letterSpacing
    }

fun Context.vbox(pad: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    if (pad > 0) setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
    LinearLayout.LayoutParams(w, h, weight)

const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

/** Botón principal (relleno con el acento) o secundario. */
fun Context.pill(label: String, filled: Boolean, icon: Int = 0, onClick: () -> Unit): TextView = TextView(this).apply {
    text = if (Themes.cur.upperTitles) label.uppercase(Locale.getDefault()) else label
    textSize = 15f
    typeface = Themes.cur.titleFont
    letterSpacing = Themes.cur.letterSpacing
    gravity = Gravity.CENTER
    val fg = if (filled) Col.ON_ACCENT else Col.TEXT
    setTextColor(fg)
    background = if (filled) rounded(Col.RED, r(0.8f).coerceAtLeast(dpf(2f)))
    else rounded(Col.CARD2, r(0.8f).coerceAtLeast(dpf(2f)), if (Themes.cur.light) dp(1) else 0, Col.LINE)
    setPadding(dp(16), dp(11), dp(16), dp(11))
    if (icon != 0) {
        val d = resources.getDrawable(icon, theme).mutate()
        d.setTint(fg)
        d.setBounds(0, 0, dp(20), dp(20))
        setCompoundDrawables(d, null, null, null)
        compoundDrawablePadding = dp(8)
    }
    isClickable = true
    setOnClickListener { onClick() }
}

/** Etiqueta pequeña con borde (año, género, temporadas…). */
fun Context.chip(label: String, highlight: Boolean = false): TextView = TextView(this).apply {
    text = label
    textSize = 13f
    typeface = Themes.cur.font
    setTextColor(Col.TEXT)
    val rad = if (Themes.cur.radius == 0f) 0f else dpf(8f)
    background = if (highlight) rounded(Col.ACCENT_SOFT, rad, dp(1), Col.RED)
    else rounded(Color.TRANSPARENT, rad, dp(1), Col.LINE)
    setPadding(dp(12), dp(6), dp(12), dp(6))
}

fun Context.chipRow(items: List<TextView>): HorizontalScrollView = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false
    val row = hbox()
    items.forEachIndexed { i, v -> row.addView(v, lp(WRAP, WRAP).apply { if (i > 0) leftMargin = dp(8) }) }
    addView(row)
}

fun Context.iconButton(res: Int, size: Int = 44, tint: Int = Col.TEXT, onClick: () -> Unit): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    val p = dp(10)
    setPadding(p, p, p, p)
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    isClickable = true
    setOnClickListener { onClick() }
}

/** Carga una imagen de internet (o de un archivo local) con caché. */
fun ImageView.show(url: String?, fallbackFile: String? = null) {
    scaleType = ImageView.ScaleType.CENTER_CROP
    when {
        !url.isNullOrBlank() -> load(url)
        fallbackFile != null && File(fallbackFile).exists() -> load(File(fallbackFile))
        else -> setImageDrawable(null)
    }
}

/** Degradado del color de fondo desde abajo, para que el texto se lea sobre la imagen. */
fun fadeBottom(): GradientDrawable =
    GradientDrawable(
        GradientDrawable.Orientation.BOTTOM_TOP,
        intArrayOf(Col.BG, (Col.BG and 0x00FFFFFF) or 0x99000000.toInt(), Color.TRANSPARENT)
    )

fun fadeLeft(): GradientDrawable =
    GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Col.BG, (Col.BG and 0x00FFFFFF) or 0xAA000000.toInt(), Color.TRANSPARENT)
    )

// ---------------- Imágenes de un título ----------------
fun Title.localCover(): String? = Catalog.filesOf(id).firstOrNull { it.coverPath != null }?.coverPath
fun Title.fanart(): String? = backdrop ?: Catalog.filesOf(id).firstOrNull { it.still != null }?.still ?: poster

fun Title.metaLine(): String = listOfNotNull(
    if (year > 0) year.toString() else null,
    if (kind == Kind.SERIES) "Serie" else "Película",
    genres.take(2).joinToString(", ").ifBlank { null }
).joinToString(" · ")

// ---------------- Tarjetas (una por tipo de tema) ----------------

/** Póster 2:3 con nombre debajo (Cine). Con [wall] = sin espacios ni texto debajo (Muro). */
fun Context.posterCard(t: Title, widthPx: Int, wall: Boolean = false, onClick: () -> Unit): View {
    val w = widthPx
    val box = vbox()
    val frame = FrameLayout(this).apply {
        background = rounded(Col.CARD, if (wall) 0f else r())
        clipToOutline = true
    }
    val img = ImageView(this)
    frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    if (t.poster.isNullOrBlank()) {
        val cover = t.localCover()
        if (cover != null) img.show(null, cover)
        frame.addView(heading(t.name, 13f, Color.WHITE, 4).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(if (cover != null) Color.parseColor("#88000000") else Col.CARD2)
            if (cover == null) setTextColor(Col.TEXT)
        }, FrameLayout.LayoutParams(MATCH, MATCH))
    } else img.show(t.poster)

    if (wall) {
        // Muro: franja inferior con nombre y año sobre la imagen
        val strip = vbox().apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.parseColor("#E6000000"), Color.TRANSPARENT))
            setPadding(dp(6), dp(18), dp(6), dp(5))
        }
        strip.addView(heading(t.name, 11f, Color.WHITE, 1))
        if (t.year > 0) strip.addView(txt(t.year.toString(), 10f, Color.parseColor("#CCFFFFFF")))
        frame.addView(strip, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        if (t.kind == Kind.SERIES) frame.addView(View(this).apply { setBackgroundColor(Col.RED) },
            FrameLayout.LayoutParams(dp(3), MATCH, Gravity.START))
        box.addView(frame, LinearLayout.LayoutParams(w, (w * 1.5f).toInt()))
    } else {
        val badgeTxt = if (t.kind == Kind.SERIES) "SERIE" else Catalog.filesOf(t.id).firstOrNull { it.quality.isNotBlank() }?.quality?.uppercase()
        if (!badgeTxt.isNullOrBlank()) {
            frame.addView(txt(badgeTxt, 10f, if (t.kind == Kind.SERIES) Col.ON_ACCENT else Color.WHITE, true).apply {
                background = rounded(if (t.kind == Kind.SERIES) Col.RED else Color.parseColor("#CC000000"), dpf(4f))
                setPadding(dp(5), dp(1), dp(5), dp(1))
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { setMargins(dp(5), dp(5), 0, 0) })
        }
        box.addView(frame, LinearLayout.LayoutParams(w, (w * 1.5f).toInt()))
        box.addView(txt(t.name + if (t.year > 0) " (${t.year})" else "", 12f, Col.MUTED, false, 2).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        }, LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dp(6) })
    }
    box.isClickable = true
    box.setOnClickListener { onClick() }
    return box
}

/** Imagen panorámica 16:9 (fanart) con nombre debajo (Estuario). */
fun Context.landscapeCard(t: Title, widthPx: Int, sub: String? = null, progress: Float = 0f, onClick: () -> Unit): View {
    val box = vbox()
    val frame = FrameLayout(this).apply { background = rounded(Col.CARD, r()); clipToOutline = true }
    val img = ImageView(this)
    frame.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    img.show(t.fanart(), t.localCover())
    if (t.fanart() == null && t.localCover() == null) {
        frame.addView(heading(t.name, 14f, Col.TEXT, 2).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(MATCH, MATCH))
    }
    // Logo de tipo, abajo a la derecha
    frame.addView(txt(if (t.kind == Kind.SERIES) "SERIE" else "PELÍCULA", 9f, Color.WHITE, true).apply {
        background = rounded(Color.parseColor("#B3000000"), dpf(2f))
        setPadding(dp(5), dp(1), dp(5), dp(1))
    }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(5), dp(5)) })
    box.addView(frame, LinearLayout.LayoutParams(widthPx, (widthPx * 9f / 16f).toInt()))
    if (progress > 0f) box.addView(progressBar(progress).apply { layoutParams = LinearLayout.LayoutParams(widthPx, dp(3)) })
    box.addView(txt(t.name, 13f, Col.TEXT, true, 1), LinearLayout.LayoutParams(widthPx, WRAP).apply { topMargin = dp(6) })
    box.addView(txt(sub ?: t.metaLine(), 11f, Col.MUTED, false, 1), LinearLayout.LayoutParams(widthPx, WRAP))
    box.isClickable = true
    box.setOnClickListener { onClick() }
    return box
}

/** Fila con póster pequeño + datos + sinopsis (Ficha técnica). */
fun Context.mediaRow(t: Title, onClick: () -> Unit): View {
    val row = hbox().apply {
        gravity = Gravity.TOP
        background = rounded(Col.CARD, r())
        setPadding(dp(10), dp(10), dp(12), dp(10))
    }
    val pw = dp(74)
    val poster = FrameLayout(this).apply { background = rounded(Col.CARD2, r(0.6f)); clipToOutline = true }
    val img = ImageView(this)
    poster.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    img.show(t.poster, t.localCover())
    row.addView(poster, LinearLayout.LayoutParams(pw, (pw * 1.5f).toInt()))

    val col = vbox().apply { setPadding(dp(12), 0, 0, 0) }
    val head = hbox().apply { gravity = Gravity.TOP }
    head.addView(txt(t.name, 16f, Col.TEXT, true, 2), lp(0, WRAP, 1f))
    if (t.rating > 0) head.addView(txt(String.format(Locale.US, "%.1f", t.rating), 12f, Col.ON_ACCENT, true).apply {
        background = rounded(Col.RED, dpf(10f))
        setPadding(dp(7), dp(2), dp(7), dp(2))
    })
    col.addView(head)
    col.addView(txt(t.metaLine(), 12f, Col.RED).apply {
        typeface = Typeface.MONOSPACE
        setPadding(0, dp(3), 0, 0)
    })
    val files = Catalog.filesOf(t.id)
    val stats = if (t.kind == Kind.SERIES) {
        val seen = files.count { it.finished }
        "${Catalog.seasonsOf(t.id).size} temp. · ${files.size} ep." + if (seen > 0) " · $seen vistos" else ""
    } else listOfNotNull(
        files.firstOrNull { it.durationMs > 0 }?.let { Fmt.duration(it.durationMs) },
        files.firstOrNull { it.quality.isNotBlank() }?.quality?.uppercase()
    ).joinToString(" · ")
    if (stats.isNotBlank()) col.addView(txt(stats, 11f, Col.DIM).apply { typeface = Typeface.MONOSPACE; setPadding(0, dp(2), 0, 0) })
    if (t.overview.isNotBlank()) col.addView(txt(t.overview, 12f, Col.MUTED, false, 3).apply { setPadding(0, dp(6), 0, 0) })
    row.addView(col, lp(0, WRAP, 1f))
    row.isClickable = true
    row.setOnClickListener { onClick() }
    return row
}

/** Fila de índice de revista: número grande, título y línea fina (Papel). */
fun Context.indexRow(t: Title, n: Int, onClick: () -> Unit): View {
    val wrap = vbox()
    val row = hbox().apply { gravity = Gravity.TOP; setPadding(0, dp(14), 0, dp(14)) }
    row.addView(txt(String.format(Locale.US, "%02d", n), 28f, Col.RED, true).apply { setPadding(0, 0, dp(14), 0) },
        LinearLayout.LayoutParams(dp(56), WRAP))
    val col = vbox()
    col.addView(txt(t.name, 19f, Col.TEXT, true, 2))
    col.addView(txt(t.metaLine(), 13f, Col.MUTED).apply { setTypeface(Themes.cur.font, Typeface.ITALIC); setPadding(0, dp(2), 0, 0) })
    if (t.overview.isNotBlank()) col.addView(txt(t.overview, 13f, Col.SOFT, false, 2).apply { setPadding(0, dp(6), 0, 0); setLineSpacing(0f, 1.15f) })
    row.addView(col, lp(0, WRAP, 1f))
    val thumb = FrameLayout(this).apply { background = rounded(Col.CARD2, 0f); clipToOutline = true }
    val img = ImageView(this)
    thumb.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
    img.show(t.poster, t.localCover())
    row.addView(thumb, LinearLayout.LayoutParams(dp(54), dp(80)).apply { leftMargin = dp(12) })
    wrap.addView(row)
    wrap.addView(View(this).apply { setBackgroundColor(Col.LINE) }, lp(MATCH, dp(1)))
    wrap.isClickable = true
    wrap.setOnClickListener { onClick() }
    return wrap
}

/** Barra de progreso fina. */
fun Context.progressBar(fraction: Float, heightDp: Int = 3): FrameLayout = FrameLayout(this).apply {
    setBackgroundColor(if (Themes.cur.light) Col.LINE else Color.parseColor("#55FFFFFF"))
    val bar = View(context).apply { setBackgroundColor(Col.RED) }
    addView(bar, FrameLayout.LayoutParams(0, MATCH))
    layoutParams = LinearLayout.LayoutParams(MATCH, dp(heightDp))
    post { bar.layoutParams = FrameLayout.LayoutParams((width * fraction).toInt(), MATCH) }
}

fun Context.sectionTitle(s: String): TextView = heading(s, 18f).apply {
    setPadding(dp(14), dp(18), dp(14), dp(8))
}

/** Fila horizontal deslizable de cualquier vista. */
fun Context.hRow(views: List<View>, gapDp: Int = 8): HorizontalScrollView = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false
    clipToPadding = false
    setPadding(dp(14), 0, dp(14), 0)
    val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
    views.forEachIndexed { i, v ->
        val p = (v.layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(WRAP, WRAP)
        if (i > 0) p.leftMargin = dp(gapDp)
        row.addView(v, p)
    }
    addView(row)
}

/** Rayita de acento debajo de la pestaña seleccionada. */
fun Context.underline(insetDp: Int = 10): LayerDrawable =
    LayerDrawable(arrayOf(ColorDrawable(Color.TRANSPARENT), ColorDrawable(Col.RED))).apply {
        setLayerGravity(1, Gravity.BOTTOM or Gravity.FILL_HORIZONTAL)
        setLayerHeight(1, dp(3))
        setLayerInsetLeft(1, dp(insetDp))
        setLayerInsetRight(1, dp(insetDp))
    }
